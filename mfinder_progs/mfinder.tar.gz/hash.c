#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "common.h"
#include "list.h"
#include "hash.h"
#include "arguments.h"

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//qsort compare
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int compare( const void *arg1, const void *arg2 )
{
   //compare ints
   return ( *(int*)arg1 > *(int*)arg2 );
}



#ifdef ENABLE_PROFILE
extern calls_to_hash_insert;
#endif


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void hash_init(Hash*hash,int size,int bckt_sz)
{
	int i;

	hash->size=size;
	hash->bckt_sz=bckt_sz;
	hash->h=(list**)mycalloc((size),sizeof(list*));
	for(i=0;i<hash->size;i++)												//ss - this was not initialized originally  <<<
		hash->h[i]=NULL;														//ss - this was not initialized originally  <<<

	if (DEBUG_LEVEL >=9)
		fprintf(arg_get_fp("log_fp"),"function:hash_init : hash->h allocated at %x\n",hash->h);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Hash* multi_hash_init(int hash_tbl_num)
{
	int i;
	Hash* multi_hash;

	multi_hash = (Hash*)mycalloc(hash_tbl_num+1,sizeof(Hash));
	if (DEBUG_LEVEL >=9)
				fprintf(arg_get_fp("log_fp"),"function:multi_hash_init : multi_hash allocated at %x\n",multi_hash);
	for(i=1;i<=hash_tbl_num;i++)
		hash_init(&multi_hash[i],HASH_SIZE,i);
	return multi_hash;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	hush function is multiple of all elements in list mod HASH_SIZE
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int hash_get_key(Hash *hash,int *p)
{
	VERYLONGINT mul=1;
	int i;
	int key;

	for(i=0; i<hash->bckt_sz; i++)
			mul *=p[i];
	key=(int)fmod((double)mul,(double)HASH_SIZE);
	return key;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void hash_insert(Hash *hash, int *p)
{
	int key;
	
	if(p==NULL)
		return;
#ifdef ENABLE_PROFILE
	calls_to_hash_insert++;
#endif
	//sort p array
	qsort( (void *)p, (size_t)hash->bckt_sz, sizeof(int), compare );
	
	key=hash_get_key(hash,p);
	if(hash->h[key]==NULL)
		list_init(&hash->h[key]);
	list_insert(hash->h[key],0,p);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void hash_free_mem(Hash *hash)
{
	int i;
	for(i=0;i<hash->size;i++){
		if(hash->h[i]!=NULL) {
			list_free_mem(hash->h[i]);
			//free((void*)hash->h[i]);
		}
	}
	myfree((void*)hash->h);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void multi_hash_free_mem(Hash *multi_hash, int hash_tbl_num)
{
	int i;

	for(i=1; i<hash_tbl_num+1; i++)
		hash_free_mem(&multi_hash[i]);
	myfree((void*)multi_hash);
}


