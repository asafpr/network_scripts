#ifndef __MOTIF_RES_H
#define __MOTIF_RES_H


#include <stdio.h>
#include "motif.h"

typedef struct {
	double n_eff; //N effective
	double n_eff_zscore; //N effective statistic distance
	double n_eff_pval; //P value for N effective
	double c_eff; //concentraion N effective
	double c_eff_zscore; //concentration N effective statistic distance
	double c_eff_pval; //P value for concentration N effective
}Neff_st;


typedef struct {
	MotifID	id;
	double real_count;			//real network motif count
	double real_pval;				//p value for real count
	double real_zscore;			//real count statistics distance
	double conc_real;				//real network motif concentration
	double conc_real_pval;		//real network motif concentration pval
	double conc_real_zscore;	//real network motif concentration zscore
	Neff_st *eff_arr;
	VERYLONGINT unique_appear;		//unique appearances
	double rand_mean;				//mean count for random networks
	double rand_std_dev;			//standard deviation for random networks
	double conc_rand_mean;		//mean concentraion of motif for random networks
	double conc_rand_std_dev;	//standard deviation for motif concentration random networks
} Motif_res;

void			dump_final_res(FILE *fp, list *all_motifs, int mtf_sz, int actual_n_eff);
//void		dump_final_res(FILE *fp, void * GN, list *res, list* full_res, int rnd_net_num, int mtf_sz, int actual_n_eff, int stn_flag);
int 			motif_res_delete (Motif_res *mr);
void			motif_res_calc_deviation (Motif_res *mtf_res, void *res_tbl, int rnd_net_num);
void			motif_res_calc_pval(Motif_res *mtf_res, void *res_tbl,int rnd_net_num);
void			motif_res_calc_zscore(Motif_res *mtf_res);
void			motif_res_calc_n_eff(Motif_res *mtf_res, list *res_sub_mtf, int colors);
void			motif_res_dump (FILE *fp, void *NN, list *res, int rnd_net_num, int colors);
void			motif_res_dump_significnat (FILE *fp, void *NN, list *res, int rnd_net_num, int colors);
Motif_res * motif_res_ini ();

#endif




