#ifndef __GENERATE_RANDOM_NETWORK_H
#define __GENERATE_RANDOM_NETWORK_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include "network.h"

int	gen_rand_network_conserve_profiles(Network **RN_p, Network *N, int rnet, FILE *fp, int switch_factor, int quiet_mode);
int	gen_rand_network_complementation(Network **RN_p, int Vrtx, int N_edges_num, int Plrf, int edge, FILE *fp,
		int *act_vrt, int *act_edg, int *act_drw);

#endif


