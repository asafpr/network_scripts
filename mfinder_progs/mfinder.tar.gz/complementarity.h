#ifndef __COMPLEMENTARITY_H
#define __COMPLEMENTARITY_H

#include <stdio.h>
#include "network.h"

void	bipartiate_analysis (Network *N, FILE *f, int color, int *success, int *quad);
void	complementary_features_analysis (Network *N, FILE *fp, int rnd_net_num);

#endif
