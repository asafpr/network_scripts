#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <string.h>
#include "common.h"
#include "permutation.h"

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	the file includes quite a few static routines. Since they are not declared their order of appearance is by usage 
//	(so that all routines called by a routine will precede the calling routine). This can be quite confusing
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//	the following matrices are used on a one off basis
static Matrix *row_p_m, *col_p_m, *id_m, *res_m, *tmp_m;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	the following matrices are used across many calls to find an isomorphic minimal (canonical) motif ID.
//	to improve efficiency - they are allocated and deallocated via an initial allocation routine and a terminal
//	freeing routine

typedef struct {
Matrix *min_iso_m_row;
Matrix *min_iso_m_col;
Matrix *min_iso_m_id;
Matrix *min_iso_m_res;
Matrix *min_iso_m_tmp;
int	mtf_size;
}Matrix_Set;

Matrix_Set	matrix_set[2]= {NULL, NULL, NULL, NULL, NULL, 0, NULL, NULL, NULL, NULL, NULL, 0};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int p2[2][2] = {
	{0, 1}, {1, 0}
};

int p3[6][3] = {
	{0, 1, 2}, {0, 2, 1}, {1, 0, 2}, {1, 2, 0},
	{2, 0, 1}, {2, 1, 0}
};

int p4[24][4] = {
	{0, 1, 2, 3}, {0, 1, 3, 2}, {0, 2, 1, 3}, {0, 2, 3, 1}, {0, 3, 1, 2}, {0, 3, 2, 1},
	{1, 0, 2, 3}, {1, 0, 3, 2}, {1, 2, 0, 3}, {1, 2, 3, 0}, {1, 3, 0, 2}, {1, 3, 2, 0},
	{2, 0, 1, 3}, {2, 0, 3, 1}, {2, 1, 0, 3}, {2, 1, 3, 0}, {2, 3, 0, 1}, {2, 3, 1, 0}, 
	{3, 0, 1, 2}, {3, 0, 2, 1}, {3, 1, 0, 2}, {3, 1, 2, 0}, {3, 2, 0, 1}, {3, 2, 1, 0}
};



int p5[120][5] = {
  {0, 1, 2, 3, 4}, {0, 1, 2, 4, 3}, {0, 1, 3, 2, 4}, {0, 1, 3, 4, 2},
  {0, 1, 4, 2, 3}, {0, 1, 4, 3, 2}, {0, 2, 1, 3, 4}, {0, 2, 1, 4, 3},
  {0, 2, 3, 1, 4}, {0, 2, 3, 4, 1}, {0, 2, 4, 1, 3}, {0, 2, 4, 3, 1},
  {0, 3, 1, 2, 4}, {0, 3, 1, 4, 2}, {0, 3, 2, 1, 4}, {0, 3, 2, 4, 1},
  {0, 3, 4, 1, 2}, {0, 3, 4, 2, 1}, {0, 4, 1, 2, 3}, {0, 4, 1, 3, 2},
  {0, 4, 2, 1, 3}, {0, 4, 2, 3, 1}, {0, 4, 3, 1, 2}, {0, 4, 3, 2, 1},
  {1, 0, 2, 3, 4}, {1, 0, 2, 4, 3}, {1, 0, 3, 2, 4}, {1, 0, 3, 4, 2},
  {1, 0, 4, 2, 3}, {1, 0, 4, 3, 2}, {1, 2, 0, 3, 4}, {1, 2, 0, 4, 3},
  {1, 2, 3, 0, 4}, {1, 2, 3, 4, 0}, {1, 2, 4, 0, 3}, {1, 2, 4, 3, 0},
  {1, 3, 0, 2, 4}, {1, 3, 0, 4, 2}, {1, 3, 2, 0, 4}, {1, 3, 2, 4, 0},
  {1, 3, 4, 0, 2}, {1, 3, 4, 2, 0}, {1, 4, 0, 2, 3}, {1, 4, 0, 3, 2},
  {1, 4, 2, 0, 3}, {1, 4, 2, 3, 0}, {1, 4, 3, 0, 2}, {1, 4, 3, 2, 0},
  {2, 0, 1, 3, 4}, {2, 0, 1, 4, 3}, {2, 0, 3, 1, 4}, {2, 0, 3, 4, 1},
  {2, 0, 4, 1, 3}, {2, 0, 4, 3, 1}, {2, 1, 0, 3, 4}, {2, 1, 0, 4, 3},
  {2, 1, 3, 0, 4}, {2, 1, 3, 4, 0}, {2, 1, 4, 0, 3}, {2, 1, 4, 3, 0},
  {2, 3, 0, 1, 4}, {2, 3, 0, 4, 1}, {2, 3, 1, 0, 4}, {2, 3, 1, 4, 0},
  {2, 3, 4, 0, 1}, {2, 3, 4, 1, 0}, {2, 4, 0, 1, 3}, {2, 4, 0, 3, 1},
  {2, 4, 1, 0, 3}, {2, 4, 1, 3, 0}, {2, 4, 3, 0, 1}, {2, 4, 3, 1, 0},
  {3, 0, 1, 2, 4}, {3, 0, 1, 4, 2}, {3, 0, 2, 1, 4}, {3, 0, 2, 4, 1},
  {3, 0, 4, 1, 2}, {3, 0, 4, 2, 1}, {3, 1, 0, 2, 4}, {3, 1, 0, 4, 2},
  {3, 1, 2, 0, 4}, {3, 1, 2, 4, 0}, {3, 1, 4, 0, 2}, {3, 1, 4, 2, 0},
  {3, 2, 0, 1, 4}, {3, 2, 0, 4, 1}, {3, 2, 1, 0, 4}, {3, 2, 1, 4, 0},
  {3, 2, 4, 0, 1}, {3, 2, 4, 1, 0}, {3, 4, 0, 1, 2}, {3, 4, 0, 2, 1},
  {3, 4, 1, 0, 2}, {3, 4, 1, 2, 0}, {3, 4, 2, 0, 1}, {3, 4, 2, 1, 0},
  {4, 0, 1, 2, 3}, {4, 0, 1, 3, 2}, {4, 0, 2, 1, 3}, {4, 0, 2, 3, 1},
  {4, 0, 3, 1, 2}, {4, 0, 3, 2, 1}, {4, 1, 0, 2, 3}, {4, 1, 0, 3, 2},
  {4, 1, 2, 0, 3}, {4, 1, 2, 3, 0}, {4, 1, 3, 0, 2}, {4, 1, 3, 2, 0},
  {4, 2, 0, 1, 3}, {4, 2, 0, 3, 1}, {4, 2, 1, 0, 3}, {4, 2, 1, 3, 0},
  {4, 2, 3, 0, 1}, {4, 2, 3, 1, 0}, {4, 3, 0, 1, 2}, {4, 3, 0, 2, 1},
  {4, 3, 1, 0, 2}, {4, 3, 1, 2, 0}, {4, 3, 2, 0, 1}, {4, 3, 2, 1, 0}
} ;


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void static fill_row_perm_mat(Matrix *M, int *p_arr)
{
	int i;
	for (i=0;i<M->size;i++)
		MTRX(M,i+1,p_arr[i]+1)=1;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void static fill_col_perm_mat(Matrix *M, int *p_arr)
{
	int i;
	for (i=0;i<M->size;i++)
		MTRX(M,p_arr[i]+1,i+1)=1;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//multiply square matrices
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void static multiply_mat(Matrix *L_M, Matrix *R_M, Matrix *RES_M)
{
	int i,j,k;

	for (i=1;i<=L_M->size;i++)
		for(j=1;j<=L_M->size;j++) {
			for(k=1;k<=L_M->size;k++)
				MTRX(RES_M,i,j)+=MTRX(L_M,i,k)*MTRX(R_M,k,j);
		}
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	adjusted for big motifs 20.1.3
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static list* calc_id_iso_2(MotifID *id, int colors)
{
	int i;
	list *iso_list;
	MotifID iso_id;
	int perm_num=2;
	int	pcolors = (int)pow(2,colors);
	
	list_ini(&iso_list, LIST_KEY_GEN);

	for(i=0; i<perm_num; i++) {
		fill_row_perm_mat(row_p_m, (int*)p2[i]);
		fill_col_perm_mat(col_p_m, (int*)p2[i]);
		motif_id_to_matrix(id_m, id, colors);
		multiply_mat(row_p_m, id_m, tmp_m);
		multiply_mat(tmp_m, col_p_m, res_m);
		motif_id_from_matrix(&iso_id, res_m, colors, pcolors);	//calc id from matrix
		if(list_get_by_key(iso_list,&iso_id)==NULL)					//insert new id to iso list (if not already there)
			list_ins(iso_list,&iso_id,NULL);
		clear_matrix(row_p_m);
		clear_matrix(col_p_m);
		clear_matrix(tmp_m);
		clear_matrix(res_m);
	}
	return iso_list;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	adjusted for big motifs 20.1.3
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static list* calc_id_iso_3(MotifID *id, int colors)
{
	int i;
	list *iso_list;
	MotifID iso_id;
	int perm_num=6;
	int	pcolors = (int)pow(2,colors);
	
	list_ini(&iso_list, LIST_KEY_GEN);

motif_id_to_matrix(id_m, id, colors);	// moved this call outside the loop
	for(i=0; i<perm_num; i++) {
		fill_row_perm_mat(row_p_m, (int*)p3[i]);
		fill_col_perm_mat(col_p_m, (int*)p3[i]);
//!!		motif_id_to_matrix(id_m,id, colors);
		multiply_mat(row_p_m, id_m, tmp_m);
		multiply_mat(tmp_m, col_p_m, res_m);
		motif_id_from_matrix(&iso_id, res_m, colors, pcolors);//calc id from matrix
		if(list_get_by_key(iso_list,&iso_id)==NULL)				//insert new id to iso list (if not already there)
			list_ins(iso_list,&iso_id,NULL);

		clear_matrix(row_p_m);
		clear_matrix(col_p_m);
		clear_matrix(tmp_m);
		clear_matrix(res_m);
	}
	return iso_list;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	adjusted for big motifs 20.1.3
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static list* calc_id_iso_4(MotifID *id, int colors)
{
	int i;
	list *iso_list;
	MotifID iso_id;
	int perm_num=24;
	int	pcolors = (int)pow(2,colors);
	
	list_ini(&iso_list, LIST_KEY_GEN);					//ss	11.16

	for(i=0; i<perm_num; i++) {
		fill_row_perm_mat(row_p_m, (int*)p4[i]);
		fill_col_perm_mat(col_p_m, (int*)p4[i]);
		motif_id_to_matrix(id_m, id, colors);
		multiply_mat(row_p_m, id_m, tmp_m);
		multiply_mat(tmp_m, col_p_m, res_m);
		motif_id_from_matrix(&iso_id, res_m, colors, pcolors);		//calc id from matrix
		if(list_get_by_key(iso_list,&iso_id)==NULL)						//insert new id to iso list (if not already there)
			list_ins(iso_list,&iso_id,NULL);
		clear_matrix(row_p_m);
		clear_matrix(col_p_m);
		clear_matrix(tmp_m);
		clear_matrix(res_m);
	}
	return iso_list;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	adjusted for big motifs 20.1.3
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static list* calc_id_iso_5(MotifID *id, int colors)
{
	int i;
	list *iso_list;
	MotifID iso_id;
	int perm_num=120;
	int	pcolors = (int)pow(2,colors);
	
	list_ini(&iso_list, LIST_KEY_GEN);					//ss	11.16

	for(i=0; i<perm_num; i++) {
		fill_row_perm_mat(row_p_m, (int*)p5[i]);
		fill_col_perm_mat(col_p_m, (int*)p5[i]);
		motif_id_to_matrix(id_m, id, colors);
		multiply_mat(row_p_m, id_m, tmp_m);
		multiply_mat(tmp_m, col_p_m, res_m);
		motif_id_from_matrix(&iso_id, res_m, colors, pcolors);		//calc id from matrix
		if(list_get_by_key(iso_list,&iso_id)==NULL)						//insert new id to iso list (if not already there)
			list_ins(iso_list,&iso_id,NULL);
		clear_matrix(row_p_m);
		clear_matrix(col_p_m);
		clear_matrix(tmp_m);
		clear_matrix(res_m);
	}
	return iso_list;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	free memory that has been allocated to provide canonical motif id
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void mtf_id_min_iso_free ()
{

	matrix_free (matrix_set[0].min_iso_m_row);
	matrix_free (matrix_set[0].min_iso_m_col);
	matrix_free (matrix_set[0].min_iso_m_id);
	matrix_free (matrix_set[0].min_iso_m_res);
	matrix_free (matrix_set[0].min_iso_m_tmp);	
	matrix_set[0].mtf_size = 0;	

	matrix_free (matrix_set[1].min_iso_m_row);
	matrix_free (matrix_set[1].min_iso_m_col);
	matrix_free (matrix_set[1].min_iso_m_id);
	matrix_free (matrix_set[1].min_iso_m_res);
	matrix_free (matrix_set[1].min_iso_m_tmp);	
	matrix_set[1].mtf_size = 0;	

	return;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	allocate memory required by the routine computing canonical motif id
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void mtf_id_min_iso_alloc (int mtf_sz)
{

	matrix_set[0].min_iso_m_row = init_matrix(mtf_sz);
	matrix_set[0].min_iso_m_col = init_matrix(mtf_sz);
	matrix_set[0].min_iso_m_id  = init_matrix(mtf_sz);
	matrix_set[0].min_iso_m_res = init_matrix(mtf_sz);
	matrix_set[0].min_iso_m_tmp = init_matrix(mtf_sz);
	matrix_set[0].mtf_size = mtf_sz;

	matrix_set[1].min_iso_m_row = init_matrix(mtf_sz-1);
	matrix_set[1].min_iso_m_col = init_matrix(mtf_sz-1);
	matrix_set[1].min_iso_m_id =  init_matrix(mtf_sz-1);
	matrix_set[1].min_iso_m_res = init_matrix(mtf_sz-1);
	matrix_set[1].min_iso_m_tmp = init_matrix(mtf_sz-1);
	matrix_set[1].mtf_size = mtf_sz-1;

	return;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	given a motif id return its canonical id (i.e. the minimal isomorphic motif id)
//	algorithm:
//	A. For a small number of possible permutations trying all of them is the quickest mode of operation. 
//	B. When the number of possible permutations becomes big (motif size >=5) it is worth looking for a quicker way. 
//		A very simple algorithm is to perform hill-climbing by trying basic permutations (i.e. exchange of one row/column 
//		with another) untill no further improvement can be achuieved. However this can lead to local minima.
//		There is an obvious intuition that the minimal ID is achieved if the last row is 'smallest'. However the local minimum
//		problem is that there might be two very different ways to achive the same values in the last row.
// C. The number of actual motifs encountered is very low (in the Protein-Protein + regulation net there were
//		157 iso-ids and you need to multiply that by maximum 24). Therefore an algorithm based on lookup table might
//		be most efficient. It could go as follows - construct a lookup table on the fly. Use it whenever possible and 
//		extend it (on the fly) when encountering a value that does not appear in the table. If the overall size of the
//		table grows beyond a certain limit revert to another mechanism. The limit of size might be governed by 
//		considerations of memory space or considerations of speed of lookup in a huge table.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	adjusted for big motifs 20.1.3
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static void mtf_id_min_iso_size_specific(MotifID *iso_id_p, MotifID *id, int mtf_sz, int perm_num, 
		int **permutation, int colors)
{
	int	i;
	int	indx;
	MotifID iso_id;
	MotifID min_iso_id;
	int	*used_permutation;
	int	*p_iso_id;
	int	*p_min_iso_id;
	int	j;
	int	min;
	int	chunks = sizeof(MotifID)/sizeof(int);
	int	pcolors = (int)pow(2,colors);
	char	*prog = "mtf_id_min_iso_size_specific";

#if	DEBUG_TRACE > 4
	printf("%s: entered with mtf_sz=%d perm_num=%d, id=", prog, mtf_sz, perm_num);
	motif_id_print (id, stdout, "", "\n");
#endif

//	preparations
	p_iso_id = (int *)&iso_id;
	p_min_iso_id = (int *)&min_iso_id;
	memcpy (&min_iso_id, id, sizeof(MotifID));
	switch (mtf_sz) {
	case 2:
		*permutation = (int*)p2[0];
		break;
	case 3:
		*permutation = (int*)p3[0];
		break;
	case 4:
		*permutation = (int*)p4[0];
		break;
	case 5:
		*permutation = (int*)p5[0];
		break;
	default:
		break;
	}

//	compute index of preallocated matrices
	for (i=0, indx=-1; i<2; i++)
		if (matrix_set[i].mtf_size == mtf_sz)
			indx = i;
	if (indx < 0) {
		printf ("%s: memory for matrices of size %d was not preallocated. program aborts\n", prog, mtf_sz);
		exit(-1);
	}

//	loop on all permutations to find the minimum (canonical) motif ID
	for(i=0; i<perm_num; i++) {

	//	1. calculate the a matrix for every permutation
		switch (mtf_sz) {
		case 2:
			fill_row_perm_mat(matrix_set[indx].min_iso_m_row, (int*)p2[i]);
			fill_col_perm_mat(matrix_set[indx].min_iso_m_col, (int*)p2[i]);
			used_permutation = (int*)p2[i];
			break;
		case 3:
			fill_row_perm_mat(matrix_set[indx].min_iso_m_row, (int*)p3[i]);
			fill_col_perm_mat(matrix_set[indx].min_iso_m_col, (int*)p3[i]);
			used_permutation = (int*)p3[i];
			break;
		case 4:
			fill_row_perm_mat(matrix_set[indx].min_iso_m_row, (int*)p4[i]);
			fill_col_perm_mat(matrix_set[indx].min_iso_m_col, (int*)p4[i]);
			used_permutation = (int*)p4[i];
			break;
		case 5:
			fill_row_perm_mat(matrix_set[indx].min_iso_m_row, (int*)p5[i]);
			fill_col_perm_mat(matrix_set[indx].min_iso_m_col, (int*)p5[i]);
			used_permutation = (int*)p5[i];
			break;
		default:
			break;
		}
		motif_id_to_matrix(matrix_set[indx].min_iso_m_id, id, colors);
		multiply_mat(matrix_set[indx].min_iso_m_row, matrix_set[indx].min_iso_m_id, matrix_set[indx].min_iso_m_tmp);
		multiply_mat(matrix_set[indx].min_iso_m_tmp, matrix_set[indx].min_iso_m_col, matrix_set[indx].min_iso_m_res);

	//	2. calculate motif id ('iso_id') from matrix
		motif_id_from_matrix(&iso_id, matrix_set[indx].min_iso_m_res, colors, pcolors);	

	//	3. maintain minimum
		//	if (min_iso_id >= iso_id){														//	version when motif ID was numeric
		//	if (memcmp (&min_iso_id, &iso_id, sizeof(MotifID)) >=0){				//	a simple comparison does not work

//		for (min = TRUE, j=0; j<chunks && min; j++)
//			if (*(p_min_iso_id + chunks - 1 - j) > *(p_iso_id + chunks - 1 - j))
//				min = FALSE;
//		if (!min || !memcmp (&min_iso_id, &iso_id, sizeof(MotifID))){
//			memcpy (&min_iso_id, &iso_id, sizeof(MotifID));
//			*permutation = used_permutation ;
//		}

		for (min = TRUE, j=0; j<chunks && min; j++) {
//			printf ("%d comparing %d with %d\n", j+1, *(p_min_iso_id + chunks - 1 - j), *(p_iso_id + chunks - 1 - j));
			if (*(p_min_iso_id + chunks - 1 - j) > *(p_iso_id + chunks - 1 - j))
				min = FALSE;
			else if (*(p_min_iso_id + chunks - 1 - j) < *(p_iso_id + chunks - 1 - j))
				break;
		}
//		printf ("min=%d, memcmp=%d\n", min, memcmp (&min_iso_id, &iso_id, sizeof(MotifID)));
		if (!min){
			memcpy (&min_iso_id, &iso_id, sizeof(MotifID));
			*permutation = used_permutation ;
//			motif_id_print (&min_iso_id, stdout, "min was reset to: ", "\n");
		}

	//	4. clear memory
		clear_matrix(matrix_set[indx].min_iso_m_row);
		clear_matrix(matrix_set[indx].min_iso_m_col);
		clear_matrix(matrix_set[indx].min_iso_m_tmp);
		clear_matrix(matrix_set[indx].min_iso_m_res);
	}

#if	DEBUG_TRACE > 4
	printf("%s: returned\n", prog);
#endif

	memcpy (iso_id_p, &min_iso_id, sizeof(MotifID));
	return;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	return list of all subids of a motif
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
list* get_mtf_subid(MotifID *id, int mtf_sz, int colors)
{
	list			*subid_list;
	list_item	*tmp;
	MotifID		sub_id, sub_id_rep;
	Matrix		*id_m,*subid_m;
	int			i,j,k,l,t;
	int			*p;
	int			*permutation;
	int			pcolors = (int)pow(2,colors);
	char			*prog="get_mtf_subid";

#if	DEBUG_TRACE > 3
	printf("%s: entered\n", prog);
#endif

	id_m = init_matrix(mtf_sz);
	subid_m = init_matrix(mtf_sz-1);
	motif_id_to_matrix(id_m, id, colors);

	list_ini(&subid_list, LIST_KEY_GEN);

//subsets result from deleting row t and col t
	for(t=1;t<=mtf_sz;t++) {
		for(i=1; i<=mtf_sz; i++) {
			for(j=1;j<=mtf_sz;j++) {
				if ( (i==t) || (j==t) )				//delete row and col t to get subid matrix
					continue;
				if (i<t)
					k=i;
				else
					k=i-1;
				if (j<t)
					l=j;
				else
					l=j-1;
				MTRX(subid_m,k,l)=MTRX(id_m,i,j);
			}
		}
		motif_id_from_matrix(&sub_id, subid_m, colors, pcolors);

//	get the canonical motif id of sub_id
		mtf_id_min_iso (&sub_id_rep, &sub_id, mtf_sz-1, &permutation, colors);	// WARNING: output overrides input

//insert new id to sub_id list (if not already there) otherwise just increase occurences of subid by one
		if( (tmp=list_get_by_key(subid_list,&sub_id_rep))==NULL) {
			p=(int*)mycalloc(1,sizeof(int));
			*p=1;
			list_ins(subid_list,&sub_id_rep,p);
		} else {
			(*(int*)tmp->p)+=1;
		}
			
		clear_matrix(subid_m);
	}
	free_matrix(id_m);
	myfree(id_m);
	free_matrix(subid_m);
	myfree(subid_m);

	return subid_list;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	calculate id of submotif, removing min connectivity vertex from the set 
//	MotifID *sub_id_p	-	pointer where the returned submotif is put
//	MotifID id				-	the id of the input motif
//	int mtf_sz				-	motif size
//	int colors				-	colors in net
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int get_mtf_subid_min_con_vrtx_less(MotifID *sub_id_p, MotifID *id, int mtf_sz, int colors)
{
	list_item *tmp;
	MotifID	sub_id, sub_id_rep;
	Matrix	*id_m,*subid_m;
	int		i,j,k,l,t;
	int		min_con,min_vrtx,cur_con;
	int		*permutation;
	int		pcolors = (int)pow(2,colors);

	id_m=init_matrix(mtf_sz);
	subid_m=init_matrix(mtf_sz-1);
	motif_id_to_matrix(id_m, id, colors);

	//find which vertex is the min conn
	min_con = 1000;
	min_vrtx=1;
	//find vertex with min connectivity
	for(i=1;i<=mtf_sz;i++){
		cur_con=0;
		for(j=1;j<=mtf_sz;j++)		//row
			if(MTRX(id_m,i,j)==1)
				cur_con++;
		for(j=1;j<=mtf_sz;j++)		//col
			if(MTRX(id_m,j,i)==1)
				cur_con++;
		if(cur_con<min_con) {
			min_con=cur_con;
			min_vrtx=i;
		}
	}		

	//the removed vertex
	t=min_vrtx;
	//each subset results from deletion of row t and col t

	for(i=1; i<=mtf_sz; i++) {
		for(j=1;j<=mtf_sz;j++) {
			//delete row and col i to get subid matrix
			if ( (i==t) || (j==t) )
				continue;
			if (i<t)
				k=i;
			else
				k=i-1;
			if (j<t)
				l=j;
			else
				l=j-1;
			MTRX(subid_m,k,l)=MTRX(id_m,i,j);
		}
	}

		motif_id_from_matrix(&sub_id, subid_m, colors, pcolors);
//	get the canonical motif id of sub_id
		mtf_id_min_iso (&sub_id_rep, &sub_id, mtf_sz-1, &permutation, colors);	// WARNING: output overrides input
		
		clear_matrix(subid_m);

	free_matrix(id_m);
	myfree(id_m);
	free_matrix(subid_m);
	myfree(subid_m);

	memcpy (sub_id_p, &sub_id_rep, sizeof(MotifID));
	return ;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	receive a motif id as an input and produce a list of all isomorphic motif ids
//	previously: list * calc_mtf_id_iso
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
list * mtf_id_iso_list(MotifID *id, int mtf_sz, int colors)
{
	list *iso_list;

#if	DEBUG_TRACE > 4
//	static int NN=0;
	char	*prog = "mtf_id_iso_list";
//	if (NN++ > 10) exit (-1);
	printf("%s: entered with motif-size=%d colors=%d", prog, mtf_sz, colors);
	motif_id_print (id, stdout, " id=", "\n");
#endif

	row_p_m=init_matrix(mtf_sz);
	col_p_m=init_matrix(mtf_sz);
	id_m=init_matrix(mtf_sz);
	res_m=init_matrix(mtf_sz);
	tmp_m=init_matrix(mtf_sz);	
	clear_matrix(row_p_m);			//ss <<
	clear_matrix(col_p_m);			//ss <<
	clear_matrix(id_m);				//ss <<
	clear_matrix(res_m);				//ss <<
	clear_matrix(tmp_m);				//ss <<

	switch (mtf_sz) {
	case 2:
		iso_list=calc_id_iso_2(id, colors);
		break;
	case 3:
		iso_list=calc_id_iso_3(id, colors);
		break;
	case 4:
		iso_list=calc_id_iso_4(id, colors);
		break;
	case 5:
		iso_list=calc_id_iso_5(id, colors);
		break;
	default:
		break;
	}
	free_matrix(row_p_m);
	myfree(row_p_m);
	free_matrix(col_p_m);
	myfree(col_p_m);
	free_matrix(id_m);
	myfree(id_m);
	free_matrix(res_m);
	myfree(res_m);
	free_matrix(tmp_m);
	myfree(tmp_m);

#if	DEBUG_TRACE > 4
	printf("%s: returned ", prog);
	list_dump (stdout, iso_list);
#endif

	return iso_list;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	receive (input) a pointer to a motif id and return the minimal isomorphic motif id
// WARNING: NOTE THAT THE VALUE RETURND OVERRIDES THE INPUT VALUE
//	arguments:
//	MotifID *idc		-	(output) a pointer to a motif id. on output this is the canonical motif id isomorphic to 'id'
//	MotifID *id			-	(input) a pointer to a motif id for which a cannoical id is required. 
//	int mtf_sz			-	(input) motif size
//	int *permutation	-	(output) the permutation that led from the input motif id to the output motif id
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void mtf_id_min_iso (MotifID *idc, MotifID *id, int mtf_sz, int **permutation, int colors)
{
	MotifID iso_id;
	char	*prog = "mtf_id_min_iso";
#if	DEBUG_TRACE > 4
	printf("%s: entered", prog);
	motif_id_print (id, stdout, " with motif id ", "\n");
#endif

	switch (mtf_sz) {
	case 2:
		mtf_id_min_iso_size_specific(&iso_id, id, 2, 2, permutation, colors);
		break;
	case 3:
		mtf_id_min_iso_size_specific(&iso_id, id, 3, 6, permutation, colors);
		break;
	case 4:
		mtf_id_min_iso_size_specific(&iso_id, id, 4, 24, permutation, colors);
		break;
	case 5:
		mtf_id_min_iso_size_specific(&iso_id, id, 5, 120, permutation, colors);
		break;
	default:
		break;
	}

	memcpy (idc, &iso_id, sizeof(MotifID));

#if	DEBUG_TRACE > 4
	printf("%s: returned\n", prog);
#endif

	return;
}



	
