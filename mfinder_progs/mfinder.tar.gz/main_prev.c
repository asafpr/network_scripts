void
res_tbl_mem_free_previousversion(Res_tbl *res)
{
	list_item *item;
	int i;
	Motif*	mtf;														//ss

//	printf("res_tbl_mem_free: res->real=%p %d\n", res->real, pointer_size(res->real));

// handling results of random networks							//ss
	for(i=0;i<arg_get_int("rnd_net_num");i++){
		for(item=list_get_next(res->rand_arr[i],NULL);item!=NULL;
			item=list_get_next(res->rand_arr[i],item)) {
				if (item->p != NULL)	{								//ss	added
					mtf = (Motif*)item->p;							//ss	added
					if (mtf->members != NULL)						//ss	added
						list_free_mem(mtf->members);				//ss	added
				}															//ss	added
//				list_free_mem(item->p);								//ss	- original: removed. this is not a pointer to a list
		}
		list_free_mem(res->rand_arr[i]);							//ss	- original: removes the list & header of the list.
	}
	myfree(res->rand_arr);											//ss	- removes all headers in one block (same as in allocation).

// handling results of the real network						//ss
	for(item=list_get_next(res->real,NULL);item!=NULL;		//ss	- according to the plan there is no content in the
		item=list_get_next(res->real,item))						//ss	  .p's of real networks and therefore this loop 	
			if (item->p != NULL)	{									//ss    might not be required. however - this structures
				mtf = (Motif*)item->p;								//ss	  contains a header to the members list which is
				if (mtf->members != NULL)							//ss	  allocated even if there are no members.
					list_free_mem(mtf->members);					//ss	  hence the need for this loop.
			}																//ss
	list_free_mem(res->real);
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int
gen_rand_network(Network **RN_p)
{
	int num_of_switchs;
	int i,j,s1,s2,t1,t2;
	int k;
	Network *RN;
	int rand_network_checked=FALSE;

#if	DEBUG_TRACE > 1
	printf("gen_rand_network: entered\n");
#endif
	
	while (!rand_network_checked) {
		//duplicate source network
		duplicate_network(G_N,&RN,"random network");

		//directed graph
		if (arg_get_int("undirected_flag") == FALSE) {
			// num of switches is round(10*(1+rand)*#edges)
			num_of_switchs=(arg_get_int("r_switch_factor")+get_rand(arg_get_int("r_switch_factor")))*RN->edges_num;
			k=0;
			//second half switches dont allow switches that cause self_edges
			while(k<num_of_switchs) {
				//get random indexes for edges
				i=get_rand(RN->edges_num); 
				while ((j=get_rand(RN->edges_num)) == i);
				
				s1=RN->e_arr[i].s;
				t1=RN->e_arr[i].t;
				s2=RN->e_arr[j].s;
				t2=RN->e_arr[j].t;
				
				//check : 1.that there are no crossing edges in the network,
				//		  2.there are no common vertices of these 2 edges
				//if hasnt passed the check then have to find other pair to switch
				if ( !(MatGet(RN->mat,s1,t2) || MatGet(RN->mat,s2,t1))
					&&(s1!=s2) && (s1!=t2) && (t1!=s2) && (t1!=t2) ) {
					//make the switch
					//update edges array
					RN->e_arr[i].t=t2;
					RN->e_arr[j].t=t1;
					//update matrix
					MatAsgn(RN->mat,s1,t1,0);
					MatAsgn(RN->mat,s2,t2,0);
					MatAsgn(RN->mat,s1,t2,1);
					MatAsgn(RN->mat,s2,t1,1);
					
					k++;
				}
			}

		}else {
			//undirected graph
			
			// num of switches is round(10*(1+rand)*#edges)
			//num of edges in undirfecetd is actually *2 therefore divided by 2
			num_of_switchs=(10+get_rand(10))*RN->edges_num/2;
			k=0;
			//second half switches dont allow switches that cause self_edges
			while(k<num_of_switchs) {
				//get random indexes for edges
				i=get_rand(RN->edges_num/2); 
				while ((j=get_rand(RN->edges_num/2)) == i);
				s1=RN->e_arr[2*i-1].s;
				t1=RN->e_arr[2*i-1].t;
				s2=RN->e_arr[2*j-1].s;
				t2=RN->e_arr[2*j-1].t;
				
				//check : 1.that there are no crossing edges in the network,
				//		  2.there are no common vertices of these 2 edges
				//if hasnt passed the check then have to find other pair to switch
				if ( !( MatGet(RN->mat,s1,t2) || MatGet(RN->mat,s2,t1)) && (s1!=t2) &&(s2!=t1) && (s1!=s2) && (t1!=t2) ) {
					//make the switch
					//update edges array
					RN->e_arr[2*i-1].t=t2;
					RN->e_arr[2*i].s=t2;
					RN->e_arr[2*j-1].t=t1;
					RN->e_arr[2*j].s=t1;
					//update matrix
					MatAsgn(RN->mat,s1,t1,0);
					MatAsgn(RN->mat,t1,s1,0);
					MatAsgn(RN->mat,s2,t2,0);
					MatAsgn(RN->mat,t2,s2,0);
					MatAsgn(RN->mat,s1,t2,1);
					MatAsgn(RN->mat,t2,s1,1);
					MatAsgn(RN->mat,s2,t1,1);
					MatAsgn(RN->mat,t1,s2,1);
					k++;
				}
			}
		}
		//check that there are no self edges. If there are any then start again
		rand_network_checked = TRUE;
		for(i=1;i<=RN->vertices_num;i++) {
			if( MatGet(RN->mat,i,i)==1 ) {
				printf("Self edges still exist building random graph again\n");
				rand_network_checked=FALSE;
				free_network_mem(RN);
				break;
			}
		}
	}

	//dump_network(RN);
	*RN_p=RN;
	return RC_OK;
}
