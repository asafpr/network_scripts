#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include "arguments.h"
#include "switches.h"
#include "metropolis.h"

static Gnrl_st GNRL_ST;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	process an argument of type char.
//	int argc			-	# of arguments
//	char *argv[]	-	list of arguments
//	char *c			-	value where argument is returned
//	int sz			-	size of character 'c'
//	int i				-	sequence number of argument to use
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int	process_char_arg (int argc, char *argv[], char *c, int sz, int i)
{
	int rc=RC_OK;

	if (i < argc && strlen(argv[i]) < sz) {
		strcpy(c, argv[i]);
		return rc;
	} else if (i < argc && strlen(argv[i]) >= sz) {
		printf("Error: argument %d '%s' is too long\n", i, argv[i]);
		return RC_ERR;
	} else {
		printf("Error: another argument is required to complement argument %d '%s'\n", i-1, argv[i-1]);
		usage();
		return RC_ERR;
	}
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	process an argument of type dbl
//	int argc			-	# of arguments
//	char *argv[]	-	list of arguments
//	double *f		-	value where argument is returned
//	int i				-	sequence number of argument to use
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int	process_double_arg (int argc, char *argv[], double *f, int i)
{
	int rc=RC_OK;

	if (i < argc) {
		*f = atof(argv[i]);
		return rc;
	} else {
		printf("Error: another argument is required to complement argument %d '%s'\n", i-1, argv[i-1]);
		usage();
		return RC_ERR;
	}
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	process an argument of type int
//	int argc			-	# of arguments
//	char *argv[]	-	list of arguments
//	int *in			-	value where argument is returned
//	int i				-	sequence number of argument to use
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static int	process_int_arg (int argc, char *argv[], int *in, int i)
{
	int rc=RC_OK;

	if (i < argc) {
		*in = atoi(argv[i]);
		return rc;
	} else {
		printf("Error: another argument is required to complement argument %d '%s'\n", i-1, argv[i-1]);
		usage();
		return RC_ERR;
	}
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	process all arguments
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int	process_input_args(int argc, char *argv[])
{
	int rc=RC_OK;
	int i=2;
	char	*prog="process_input_args";

#if	DEBUG_TRACE > 0
	printf("%s: entered\n", prog);
#endif

	if ( argc<2 || (!strcmp(argv[i],"-h")) ) {
		usage();
		return RC_ERR;
	} else {
		GNRL_ST.rnd_net_num = 0;
		strcpy (GNRL_ST.input_network_fname,argv[1]);
		
		//printf("argc is %d\n", argc);
		
//	initialize GNRL_ST to default values (later they will be overidden by the command line arguments)
		GNRL_ST.rnd_net_num=DEFAULT_RAND_NETWORK_NUM;
		GNRL_ST.t_init=T0;
		GNRL_ST.iteration_factor=ITERATION_F;
		GNRL_ST.e_thresh=ETHRESH;
		GNRL_ST.long_out_flag=FALSE;
		GNRL_ST.calc_unique_flag=FALSE;
		GNRL_ST.undirected_flag=FALSE;
		GNRL_ST.run_prob_app=FALSE;
		GNRL_ST.prob_app_samples_num=0;
		GNRL_ST.actual_n_eff=DEFAULT_NEFF;
		GNRL_ST.mfactor_th=MFACTOR_TH;
		GNRL_ST.zfactor_th=ZSCORE_TH;
		GNRL_ST.out_s_mat_flag=TRUE;
		GNRL_ST.out_l_mat_flag=FALSE;
		GNRL_ST.out_s_c_mat_flag=FALSE;
		GNRL_ST.out_random_flag=FALSE;
		GNRL_ST.motif_occr_dump=FALSE;
		GNRL_ST.quiet_mode=FALSE;
		GNRL_ST.use_metropolis=FALSE;
		GNRL_ST.dont_search_real=FALSE;
		GNRL_ST.out_intermediate=FALSE;
		GNRL_ST.r_switch_factor=R_SWITCH_FACTOR;
		GNRL_ST.ts=FALSE;
		GNRL_ST.stat_vertex_extended_degree_cap=0;	// or is 2 a better default
		GNRL_ST.stat_vertex_degree=FALSE;
		GNRL_ST.stat_motif_distribution = -1;
		GNRL_ST.stat_motif_distribution_tolerance = 0;
		GNRL_ST.stat_bipartiate=FALSE;
		strcpy(GNRL_ST.rnd," ");
		strcpy(GNRL_ST.version,"03");

		strcpy(GNRL_ST.out_fname,"mfinder_OUT");
		strcpy(GNRL_ST.log_fname,"mfinder_LOG");
		strcpy(GNRL_ST.required_motifs_fname,"");

//	process command line arguements
		while(i<argc) {
			//motif size
			if (!strcmp(argv[i],"-s")) {
				if (rc = process_int_arg (argc, argv, &GNRL_ST.mtf_sz, ++i)) break;
				if(GNRL_ST.mtf_sz > 5 || GNRL_ST.mtf_sz < 3) {
					printf("Error :This version of mfinder supports motif size 3-5 only\nChange argument after -s flag\n");
					return RC_ERR;
				}
			} else if (!strcmp(argv[i],"-r")) {											//random network num
				if (rc = process_int_arg (argc, argv, &GNRL_ST.rnd_net_num, ++i)) break;
#ifdef METROAPPROACH
			} else if (!strcmp(argv[i],"-iter")) {										// metropolis iteration numbers
				if (rc = process_double_arg (argc, argv, &GNRL_ST.iteration_factor, ++i)) break;
			} else if (!strcmp(argv[i],"-t0")) {										// initial metropolis temperature
				if (rc = process_double_arg (argc, argv, &GNRL_ST.t_init, ++i)) break;
			} else if (!strcmp(argv[i],"-eth")) {										// metropolis energy threshold
				if (rc = process_double_arg (argc, argv, &GNRL_ST.e_thresh, ++i)) break;
			} else if (!strcmp(argv[i],"-met")) {
				GNRL_ST.use_metropolis=TRUE;
				GNRL_ST.out_metrop_mat_flag=TRUE;
#endif
			} else if (!strcmp(argv[i],"-u")) {											//clac unique flag
				GNRL_ST.calc_unique_flag=TRUE;
			} else if (!strcmp(argv[i],"-e")) {											//actual Neff
				if (rc = process_int_arg (argc, argv, &GNRL_ST.actual_n_eff, ++i)) break;
			} else if (!strcmp(argv[i],"-z")) {											//zscore th to use
				if (rc = process_double_arg (argc, argv, &GNRL_ST.zfactor_th, ++i)) break;
			} else if (!strcmp(argv[i],"-m")) {											//mfactor th to use
				if (rc = process_double_arg (argc, argv, &GNRL_ST.mfactor_th, ++i)) break;
			} else if (!strcmp(argv[i],"-nd")) {										//undirected graph
				GNRL_ST.undirected_flag=TRUE;
#ifdef PROBAPPROACH
			} else if (!strcmp(argv[i],"-p")) {											//probabilistic approach
				GNRL_ST.run_prob_app=TRUE;
				if (rc = process_int_arg (argc, argv, &GNRL_ST.prob_app_samples_num, ++i)) break;
#endif
			} else if (!strcmp(argv[i],"-q")) {											//quiet mode
				GNRL_ST.quiet_mode=TRUE;
			} else if (!strcmp(argv[i],"-oc")) {										//out .MAT in conc not counts
				GNRL_ST.out_s_c_mat_flag=TRUE;
			} else if (!strcmp(argv[i],"-mod")) {										//require dump of motif occurence
				GNRL_ST.motif_occr_dump=TRUE;
			} else if (!strcmp(argv[i],"-modf")) {										//limy dump of motif occurence
				if (rc=process_char_arg (argc, argv, GNRL_ST.required_motifs_fname, sizeof (GNRL_ST.required_motifs_fname),++i))
				 break;
			} else if (!strcmp(argv[i],"-nor")) {										//dont-search-on-real-network flag
				GNRL_ST.dont_search_real=TRUE;
			} else if (!strcmp(argv[i],"-oi")) {										//output intermediate results
				GNRL_ST.out_intermediate=TRUE;
			} else if (!strcmp(argv[i],"-or")) {										//output random network
				GNRL_ST.out_random_flag=TRUE;
			} else if (!strcmp(argv[i],"-nsr")) {										//random network switch edges factor
				GNRL_ST.r_switch_factor = atoi(argv[++i]);
			} else if (!strcmp(argv[i],"-f")) {											//output file name
				if (rc = process_char_arg (argc, argv, GNRL_ST.out_fname, sizeof (GNRL_ST.out_fname), ++i)) break;
				strcpy(GNRL_ST.log_fname,argv[i]);
				strcpy(GNRL_ST.mat_s_fname,argv[i]);
				strcpy(GNRL_ST.mat_l_fname,argv[i]);
				strcpy(GNRL_ST.mat_metrop_fname,argv[i]);
				strcpy(GNRL_ST.inter_out_fname,argv[i]);
				strcpy(GNRL_ST.motif_occr_fname,argv[i]);
				strcat(GNRL_ST.out_fname,"_OUT.txt");
				strcat(GNRL_ST.log_fname,"_LOG.txt");
				strcat(GNRL_ST.mat_s_fname,"_MAT.txt");
				strcat(GNRL_ST.mat_l_fname,"_MAT_long.txt");
				strcat(GNRL_ST.mat_metrop_fname,"_METROP.txt");
				strcat(GNRL_ST.inter_out_fname,"_INTER.txt");
				strcat(GNRL_ST.motif_occr_fname,"_MOTIFS.txt");
			} else if (!strcmp(argv[i],"-ol")) {										//	flag output l-mat
				GNRL_ST.out_l_mat_flag=TRUE;
			} else if (!strcmp(argv[i],"-ts")) {										//	direction of arcs
				GNRL_ST.ts=TRUE;
			} else if (!strcmp(argv[i],"-stvedc")) {									//	statistics - vertex extended degree cap
				if (rc = process_int_arg (argc, argv, &GNRL_ST.stat_vertex_extended_degree_cap, ++i)) break;
			} else if (!strcmp(argv[i],"-stvd")) {										//	statistics - vertex degree
				GNRL_ST.stat_vertex_degree=TRUE;
			} else if (!strcmp(argv[i],"-stmd")) {										//	statistics - motif distribution
				if (isdigit(argv[i+1][0])) {
					if (rc = process_int_arg (argc, argv, &GNRL_ST.stat_motif_distribution, ++i)) break;
					if (isdigit(argv[i+1][0]))												//	statistics - motif distribution tolerance
						if (rc = process_int_arg (argc, argv, &GNRL_ST.stat_motif_distribution_tolerance, ++i)) break;
				} else
					GNRL_ST.stat_motif_distribution = 0;
			} else if (!strcmp(argv[i],"-stbip")) {									//	bipartiate statistics
				GNRL_ST.stat_bipartiate=TRUE;
			} else if (!strcmp(argv[i],"-rnd")) {										//	randomization mode
				if (rc = process_char_arg (argc, argv, GNRL_ST.rnd, sizeof (GNRL_ST.rnd), ++i)) break;
				if (GNRL_ST.rnd[0] != 'd' && GNRL_ST.rnd[0] != 'p' && GNRL_ST.rnd[0] != 's') {
					printf("Error in argument %d illegal randomization mode '%c'\n", i, GNRL_ST.rnd[0]);
					rc = RC_ERR;
					break;
				}
			} else {
				//error
				printf("Error in argument %d '%s'\n", i, argv[i]);
				usage();
				return RC_ERR;
			}
			i++;
		}
	}
	if(GNRL_ST.quiet_mode==FALSE)
			printf("Input Network file is %s\n", GNRL_ST.input_network_fname);
	return rc;
}


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	get a char * argument from the repository GNRL_ST
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
char * arg_get_char (char *argname)
{
	char *prog="arg_get_char";

	if (!strcmp(argname,"input_network_fname"))
		return GNRL_ST.input_network_fname;
	else if  (!strcmp(argname,"out_fname"))
		return GNRL_ST.out_fname;
	else if  (!strcmp(argname,"log_fname"))
		return GNRL_ST.log_fname;
	else if  (!strcmp(argname,"mat_s_fname"))
		return GNRL_ST.mat_s_fname;
	else if  (!strcmp(argname,"mat_l_fname"))
		return GNRL_ST.mat_l_fname;
	else if  (!strcmp(argname,"mat_metrop_fname"))
		return GNRL_ST.mat_metrop_fname;
	else if  (!strcmp(argname,"inter_out_fname"))
		return GNRL_ST.inter_out_fname;
	else if  (!strcmp(argname,"motif_occr_fname"))
		return GNRL_ST.motif_occr_fname;
	else if  (!strcmp(argname,"required_motifs_fname"))
		return GNRL_ST.required_motifs_fname;
	else if  (!strcmp(argname,"rnd"))
		return GNRL_ST.rnd;
	else if  (!strcmp(argname,"version"))
		return GNRL_ST.version;
	else {
		printf("%s: called with improper argument '%s'\n", prog, argname);
		exit(-1);
	}
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	get a double argument from the repository GNRL_ST
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
double	arg_get_double (char *argname)
{
	char *prog="arg_get_double";

	if (!strcmp(argname,"t_init"))
		return GNRL_ST.t_init;
	else if  (!strcmp(argname,"iteration_factor"))
		return GNRL_ST.iteration_factor;
	else if  (!strcmp(argname,"e_thresh"))
		return GNRL_ST.e_thresh;
	else if  (!strcmp(argname,"mfactor_th"))
		return GNRL_ST.mfactor_th;
	else if  (!strcmp(argname,"zfactor_th"))
		return GNRL_ST.zfactor_th;
	else {
		printf("%s: called with improper argument '%s'\n", prog, argname);
		exit(-1);
	}
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	get a FILE * argument  from the repository GNRL_ST
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
FILE * arg_get_fp (char *argname)
{
	char *prog="arg_get_fp";

	if (!strcmp(argname,"out_fp"))
		return GNRL_ST.out_fp;
	else if  (!strcmp(argname,"log_fp"))
		return GNRL_ST.log_fp;
	else if  (!strcmp(argname,"mat_s_fp"))
		return GNRL_ST.mat_s_fp;
	else if  (!strcmp(argname,"mat_l_fp"))
		return GNRL_ST.mat_l_fp;
	else if  (!strcmp(argname,"mat_metrop_fp"))
		return GNRL_ST.mat_metrop_fp;
	else if  (!strcmp(argname,"inter_out_fp"))
		return GNRL_ST.inter_out_fp;
	else if  (!strcmp(argname,"motif_occr_fp"))
		return GNRL_ST.motif_occr_fp;
	else if  (!strcmp(argname,"required_motifs_fp"))
		return GNRL_ST.required_motifs_fp;
	else {
		printf("%s: called with improper argument '%s'\n", prog, argname);
		exit(-1);
	}
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	get an integer argument from the repository GNRL_ST
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int	arg_get_int (char *argname)
{
	char *prog="arg_get_int";

	if (!strcmp(argname,"mtf_sz"))
		return GNRL_ST.mtf_sz;
	else if  (!strcmp(argname,"rnd_net_num"))
		return GNRL_ST.rnd_net_num;
	else if  (!strcmp(argname,"long_out_flag"))
		return GNRL_ST.long_out_flag;
	else if  (!strcmp(argname,"out_s_mat_flag"))
		return GNRL_ST.out_s_mat_flag;
	else if  (!strcmp(argname,"out_l_mat_flag"))
		return GNRL_ST.out_l_mat_flag;
	else if  (!strcmp(argname,"out_s_c_mat_flag"))
		return GNRL_ST.out_s_c_mat_flag;
	else if  (!strcmp(argname,"out_random_flag"))
		return GNRL_ST.out_random_flag;
	else if  (!strcmp(argname,"out_metrop_mat_flag"))
		return GNRL_ST.out_metrop_mat_flag;
	else if  (!strcmp(argname,"actual_n_eff"))
		return GNRL_ST.actual_n_eff;
	else if  (!strcmp(argname,"calc_unique_flag"))
		return GNRL_ST.calc_unique_flag;
	else if  (!strcmp(argname,"undirected_flag"))
		return GNRL_ST.undirected_flag;
	else if  (!strcmp(argname,"use_metropolis"))
		return GNRL_ST.use_metropolis;
	else if  (!strcmp(argname,"run_prob_app"))
		return GNRL_ST.run_prob_app;
	else if  (!strcmp(argname,"prob_app_samples_num"))
		return GNRL_ST.prob_app_samples_num;
	else if  (!strcmp(argname,"quiet_mode"))
		return GNRL_ST.quiet_mode;
	else if  (!strcmp(argname,"out_intermediate"))
		return GNRL_ST.out_intermediate;
	else if  (!strcmp(argname,"dont_search_real"))
		return GNRL_ST.dont_search_real;
	else if  (!strcmp(argname,"r_switch_factor"))
		return GNRL_ST.r_switch_factor;
	else if  (!strcmp(argname,"ts"))
		return GNRL_ST.ts;
	else if  (!strcmp(argname,"stat_vertex_extended_degree_cap"))
		return GNRL_ST.stat_vertex_extended_degree_cap;
	else if  (!strcmp(argname,"stat_vertex_degree"))
		return GNRL_ST.stat_vertex_degree;
	else if  (!strcmp(argname,"stat_motif_distribution"))
		return GNRL_ST.stat_motif_distribution;
	else if  (!strcmp(argname,"stat_motif_distribution_tolerance"))
		return GNRL_ST.stat_motif_distribution_tolerance;
	else if  (!strcmp(argname,"motif_occr_dump"))
		return GNRL_ST.motif_occr_dump;
	else if  (!strcmp(argname,"stat_bipartiate"))
		return GNRL_ST.stat_bipartiate;
	else {
		printf("%s: called with improper argument '%s'\n", prog, argname);
		exit(-1);
	}
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	get a Runtime * argument from the repository GNRL_ST
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Runtime * arg_get_rt (char *argname)
{
	char *prog="arg_get_rt";

	if (!strcmp(argname,"total_time"))
		return &GNRL_ST.total_time;
	else if  (!strcmp(argname,"real_net_time"))
		return &GNRL_ST.real_net_time;
	else if  (!strcmp(argname,"rand_net_time"))
		return &GNRL_ST.rand_net_time;
	else {
		printf("%s: called with improper argument '%s'\n", prog, argname);
		exit(-1);
	}
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	put a FILE * argument into the repository GNRL_ST
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	arg_put_fp (char *argname, FILE *fp)
{
	char *prog="arg_put_fp";
	if (!strcmp(argname,"out_fp"))
		GNRL_ST.out_fp = fp;
	else if  (!strcmp(argname,"log_fp"))
		GNRL_ST.log_fp = fp;
	else if  (!strcmp(argname,"mat_s_fp"))
		GNRL_ST.mat_s_fp = fp;
	else if  (!strcmp(argname,"mat_l_fp"))
		GNRL_ST.mat_l_fp = fp;
	else if  (!strcmp(argname,"mat_metrop_fp"))
		GNRL_ST.mat_metrop_fp = fp;
	else if  (!strcmp(argname,"inter_out_fp"))
		GNRL_ST.inter_out_fp = fp;
	else if  (!strcmp(argname,"motif_occr_fp"))
		GNRL_ST.motif_occr_fp = fp;
	else if  (!strcmp(argname,"required_motifs_fp"))
		GNRL_ST.required_motifs_fp = fp;
	else {
		printf("%s: called with improper argument '%s'\n", prog, argname);
		exit(-1);
	}
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	put a Runtime * argument into the repository GNRL_ST
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	arg_put_rt (char *argname, Runtime *rt)
{
	char *prog="arg_put_rt";

	if (!strcmp(argname,"total_time"))
		memcpy(&GNRL_ST.total_time, rt, sizeof(Runtime));
	else if  (!strcmp(argname,"real_net_time"))
		memcpy(&GNRL_ST.real_net_time, rt, sizeof(Runtime));
	else if  (!strcmp(argname,"rand_net_time"))
		memcpy(&GNRL_ST.rand_net_time, rt, sizeof(Runtime));
	else {
		printf("%s: called with improper argument '%s'\n", prog, argname);
		exit(-1);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	present usage information
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	usage()
{
	printf("Usage : mfinder <Network input file name> -s <motif size> -r <rand net num> [-f <output file name>] [-u]");
	printf("[-e <neff type num>] [-nd] [-m] [-p <num of samples>]\n");
	printf("\t-s <motif size>  :Motif size to search\n");
	printf("\t-r <rand net num> :Number of Random network to generate\n");
	printf("\t-f <output file name>  : Output file name\n");
	printf("\t-u : If this option is used, calculate number of unique apperances\n");
	printf("\t-e <Neff type> : Neff type to use for calculating motifs (1-5)\n");
	printf("\t    Neff 1 : mul all subcircuits\n");
	printf("\t    Neff 2 : mul all subcircuits(at most once)\n");
	printf("\t    Neff 3 : mul min ratio subcircuit\n");
	printf("\t    Neff 4 : sum all subcircuits\n");
	printf("\t    Neff 5 : min connectivity\n");
	printf("\t-nd : If this option is used then input graph is undirected.\n");
#ifdef PROBAPPROACH
	printf("\t-p <num of samples>: run probabilistic approach\n");
#endif
	printf("\t-m <value> : mfactor threshold to use when calculating motifs\n");
	printf("\t-z <value> : Z-score threshold to use when calculating motifs\n");
	printf("\t-q :Quiet mode - No output to the screen\n");  
#ifdef METROAPPROACH
	printf("\t-met :Metropolis mode - random networks with same triadic census\n");  
	printf("\t-t0 <(default 0.001)> :Initial temperature (-met option)\n");
	printf("\t-iter <(default 10)> :controls how many steps to perform (-met option) \n");
	printf("\t-eth  <(default 0.005)> : energy threshhold (-met option)\n");
#endif
	printf("\t-oi :output intermediate output file. Defualt :No: \n");
	printf("\t-ol : output matlab matrix long format\n");
	printf("\t-oc : output matlab short format with Concentrations and with Counts\n");
	printf("\t-or : output random networks\n");
	printf("\t-nor : Dont search Real network. Defualt :No: \n");
	printf("\t-nsr : Edges Switches factor when generating Random networks. Defualt:10 \n");
	printf("\t-ts : indicates arcs are presented target<-source. Default is that they are presented source->target.\n");
	printf("\t-stvedc <cap> : statistics - requirement to provide vertex extended degree distribution\n");
		printf("\t\t the numeric (mandatory) parameter indicates a cap on the degree in the distribution.\n");
	printf("\t-stvd : statistics - requirement to provide vertex degree distribution.\n");
	printf("\t-stmd [<min>] [<tolerance>]: statistics - requirement to provide motif distribution\n");
		printf("\t\tthe first numeric argument indicates the minimal number of occurences of a motif\n");
		printf("\t\t in the real network for the motif to be presented. it defaults to 1\n");
		printf("\t\tthe second numeric argument indicates the tolerance for identifying motifs with cliques\n");
		printf("\t\t this tolerance defaults to zero and if provided must be preseeded by the first numeric argument\n");
	printf("\t-stbip : statistics - requirement to provide bipartiateness analysis.\n");
	printf("\t-mod : require motif occurence dump\n");
	printf("\t-modf <file_name>: limit motif occurence dump to motifs appearing in the file\n");
	printf("\t-rnd : randomization mode either '-rnd d' or '-rnd p' or '-rnd s (skip)'. default - by COLOR\n");
}
