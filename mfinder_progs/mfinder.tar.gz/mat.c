#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "common.h"
#include "mat.h"
#include "arguments.h"


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Matrix FUNCTIONS
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void clear_matrix(Matrix *M)
{
	int i;
	int mat_cells_num=M->size*M->size;

	for(i=0;i<mat_cells_num;i++)
		M->m[i]=0;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void free_matrix(Matrix *M)
{
	if (M != NULL) {
		myfree(M->m); 
		//free((void*)M);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

Matrix* init_matrix(int size)
{
	Matrix *mat;
	mat=(Matrix*)mycalloc(1,sizeof(Matrix));
	if (DEBUG_LEVEL >=9)
				fprintf(arg_get_fp("log_fp"),"function:init_matrix : mat allocated at %x\n",mat);

	mat->size=size;
	mat->m=(char*)mycalloc((size+1)*(size+1), sizeof(char));
	if (DEBUG_LEVEL >=9)
				fprintf(arg_get_fp("log_fp"),"function:init_matrix : mat->m allocated at %x\n",mat->m);
	return mat;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// dump a Matrix in 'dim' dimensions (1 or 2)
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void matrix_dump(FILE *fp,Matrix *M, char *name, int dim)
{
	int i,j;
	if(strcmp(name,""))
		fprintf(fp,"name :%s\n",name);

	for (i=1; i<=M->size; i++) {
		fprintf (fp, "%s", dim == 2 ? "\n" : " | ");
		for (j=1; j<=M->size; j++)
			fprintf (fp,"%d ",MTRX(M,i,j));
	}
	fprintf (fp, "%s", dim == 2 ? "\n" : " | ");
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	free memory of a matrix. note there is a historical version free_matrix which deallocates only the content of the matrix
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void matrix_free (Matrix *M)
{
	if (M != NULL) {
		myfree (M->m); 
		myfree (M);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// SparseMatrix FUNCTIONS
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
dump_spr_matrix(FILE *fp,Mat *M, char *name)
{
	int i,j;
	if(strcmp(name,""))
		fprintf(fp,"name :%s\n",name);

	for (i=1; i<=M->spr->size; i++) {
		fprintf(fp,"\n");
		for (j=1; j<=M->spr->size; j++)
			fprintf (fp,"%d ",MatGet(M,i,j));
	}
	fprintf(fp,"\n");
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
free_spr_matrix(SparseMatrix *M)
{
	int i;

	if(M != NULL) {
//		for(i=0;i<M->size;i++) {		//ss - original
		for(i=1;i<M->size+1;i++) {		//ss revised
			if(M->m[i].to != NULL)
				list_free_mem(M->m[i].to);
			if(M->m[i].from != NULL)
				list_free_mem(M->m[i].from);
		}
		myfree(M->m);
	}
}
	


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	initialize a spare matrix
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
SparseMatrix* init_spr_matrix(int size)
{
	int i;
	Edges_lists* m;

	SparseMatrix *mat;
	mat=(SparseMatrix*)mycalloc(1,sizeof(SparseMatrix));
	mat->size=size;

// note that the size allocated is different than indicated in ->size
//	mat->m=(Edges_lists*)calloc((unsigned int)size+1,sizeof(Edges_lists));	//ss - original
	m = (Edges_lists*)mycalloc((unsigned int)size+1,sizeof(Edges_lists));	//ss - similar to original
	for (i=0; i<=size; i++) {		//ss
		m[i].to = NULL; 				//ss
		m[i].from = NULL;				//ss
	} 										//ss
	mat->m = m;							//ss

	return mat;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// Mat FUNCTIONS (handle both the full or sparse situations)
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//void	mat_edges_switch (Mat *mat, int s1, int t1, int s2, int t2) {
//				MatAsgn(mat,s1,t1,0);
//				MatAsgn(mat,s2,t2,0);
//				MatAsgn(mat,s1,t2,1);
//				MatAsgn(mat,s2,t1,1);
//}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int	mat_check (Mat *mat, int vertices, int edges){
	int	OK=TRUE;
	int	i;
	SparseMatrix	*spr;
	int	edg = 0;

	switch (mat->type) {
	case FULL:
//		not handled yet
		break;
	case SPARSE:
		spr = mat->spr;
// 	check # of vertices
		if (spr->size != vertices) {
			printf ("mat_check: size conflict\n");
			OK = FALSE;
		} else {
// 	check arrays of edges
			for (i=1; i<=vertices; i++) {
				if (spr->m[i].from) {
					if (spr->m[i].from->size < 0 || spr->m[i].from->size > vertices) {
						OK = FALSE;
						printf ("mat_check: edge error illegal 'from' size=%d\n", spr->m[i].from->size);
					}
					if (list_check (spr->m[i].from) > 0) {
						printf ("mat_check: list_check error for vertex %d\n", i);
						OK = FALSE;
					}
				}
				if (spr->m[i].to) {
					if (spr->m[i].to->size < 0 || spr->m[i].to->size > vertices) {
						OK = FALSE;
						printf ("mat_check: edge error illegal 'to' size=%d\n", spr->m[i].to->size);
					}
					if (list_check (spr->m[i].to) > 0) {
						printf ("mat_check: list_check error for vertex %d\n", i);
						OK = FALSE;
					}
					edg += spr->m[i].to->size;
				}
			}
// 	check # of edges
			if (edg != edges)
				OK = FALSE;
		}
		break;
	default:
		OK = FALSE;
		break;
	}
	return OK;

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	mat_dump (FILE *fp, Mat *mat, char *name)
{
	if (mat) {
		if (mat->type == FULL) {
			matrix_dump(fp, mat->full, name, 2);
		} else if (mat->type == FULL) {
			dump_spr_matrix(fp, mat, name);
		} else {
			fprintf (fp, "from mat_dump: illegal type of mat. program aborted");
			exit(-1);
		}
	} else
		fprintf (fp, "from mat_dump: mat is null");
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//asign value val to mat[i,j]
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void MatAsgn(Mat *mat, int i, int j, int val)
{
	list_item *e_l;
	int *val_p;

#if	DEBUG_TRACE > 8
	printf("MatAsgn: entered with i=%d j=%d\n", i, j);
#endif

	switch (mat->type) {
	case FULL:
		MTRX(mat->full,i,j)=val;
		break;
	case SPARSE:
		if (!mat->spr->m) {
			printf("MatAsgn: a sparse matrix is not initialized properly for i=%d\n", i);
			exit(-1);
		}
		//update the "to" lists
		if( mat->spr->m[i].to==NULL){
			//no edges from this vertex
			list_init(&mat->spr->m[i].to);
			val_p=(int*)mycalloc(1,sizeof(int));
			*val_p=val;
			list_insert(mat->spr->m[i].to,j,val_p);
		}else if( (e_l=list_get(mat->spr->m[i].to,j)) == NULL) {
			//edges from this vertex exist but not this one
			val_p=(int*)mycalloc(1,sizeof(int));
			*val_p=val;
			list_insert(mat->spr->m[i].to,j,val_p);
		}else{
			//edge exist but need to assign val
			if (val==0)
				//need to delete this edge from list
				list_delete(mat->spr->m[i].to,j);
			else
				//different value to be assigned
				*(int*)e_l->p=val;
		}
		//update the "from" lists
		if( mat->spr->m[j].from==NULL){
			//no edges from this vertex
			list_init(&mat->spr->m[j].from);
			val_p=(int*)mycalloc(1,sizeof(int));
			*val_p=val;
			list_insert(mat->spr->m[j].from,i,val_p);
		}else if( (e_l=list_get(mat->spr->m[j].from,i)) == NULL) {
			//edges from this vertex exist but not this one
			val_p=(int*)mycalloc(1,sizeof(int));
			*val_p=val;
			list_insert(mat->spr->m[j].from,i,val_p);
		}else{
			//edge exist but need to assign val
			if (val==0)
				//need to delete this edge from list
				list_delete(mat->spr->m[j].from,i);
			else
				//different value to be assigned
				*(int*)e_l->p=val;
		}
		break;
	default:
		break;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void
MatFree(Mat *mat)
{
	switch(mat->type){
	case FULL:
		free_matrix(mat->full);
		myfree((void*)mat->full);
		break;
	case SPARSE:
		free_spr_matrix(mat->spr);
		myfree((void*)mat->spr);
		break;
	default:
		break;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//returns value of mat[i,j]
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int MatGet(Mat *mat,int i, int j)
{
	list_item *e_l;
	SparseMatrix *spr;

#if	DEBUG_TRACE > 8
	printf("MatGet: entered with i=%d j=%d\n", i, j);
#endif

	switch (mat->type) {
	case FULL:
		return MTRX(mat->full,i,j);
		break;
	case SPARSE:
		spr = mat->spr;
		if(i<0 || j<0 || i>spr->size || j>spr->size)
			printf("MatGet: Illegal arguments i=%d, j=%d, spr->size=%d\n",	i, j, spr->size, mat->spr->m[i].to);
		if(!mat->spr->m[i].to)
			//no edges exist for i - return zero
			return 0;
		else if( (e_l=list_get(mat->spr->m[i].to,j)) != NULL)
			//edge exist
			return *(int*)e_l->p;
		else
			//edge doest not exist return zero
			return 0;
		break;
	default:
		return -1;
		break;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	initialize a Mat structure
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int
MatInit(Mat **mat_p, int size)
{
	Mat *mat;
	mat=(Mat*)mycalloc(1,sizeof(Mat));
	if (DEBUG_LEVEL >=9)
				fprintf(arg_get_fp("log_fp"),"function MatInit: mat allocated at %x\n",mat);
	
	//if number of vertices <= MAT_MAX_SIZE use full matrix data structure otherwise use sparse matrix data structure
	if(size <= MAT_MAX_SIZE)
		mat->type=FULL;
	else
		mat->type=SPARSE;

	switch(mat->type){
	case FULL:
		mat->full=init_matrix(size);
		break;
	case SPARSE:
		mat->spr=init_spr_matrix(size);
		break;
	default:
		return -1;
		break;
	}
	*mat_p=mat;
	return 0;
}


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



//#define ASGN_MAT(N,i,j,val) ( *(char*)(N.m+(i*(N.vertices_num-1))+(j-1)) = val )
//#define GET_MAT(N,i,j)      ( *(char*)(N.m+(i*(N.vertices_num-1))+(j-1)) )
