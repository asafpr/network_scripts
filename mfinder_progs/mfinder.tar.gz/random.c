#include <stdio.h>
#include <time.h>


#define MBIG 1000000000
#define MSEED 161803398
#define MZ 0
#define FAC (1.0/MBIG)

#define IM1 2147483563
#define IM2 2147483399
#define AM (1.0/IM1)
#define IMM1 (IM1-1)
#define IA1 40014
#define IA2 40692
#define IQ1 53668
#define IQ2 52774
#define IR1 12211
#define IR2 3791
#define NTAB 32
#define NDIV (1+IMM1/NTAB)
#define EPS 1.2e-7
#define RNMX (1.0-EPS)

#define IB1 1
#define IB2 2
#define IB5 16
#define IB18 131072

#define NR_END 1

//The random seed
//should be initialized to negative value
//in the beginning of each run 
long Rand_seed; 

float ran2(long *idum)
{
	int j;
	long k;
	static long idum2=123456789;
	static long iy=0;
	static long iv[NTAB];
	float temp;

	if (*idum <= 0) {
		if (-(*idum) < 1) *idum=1;
		else *idum = -(*idum);
		idum2=(*idum);
		for (j=NTAB+7;j>=0;j--) {
			k=(*idum)/IQ1;
			*idum=IA1*(*idum-k*IQ1)-k*IR1;
			if (*idum < 0) *idum += IM1;
			if (j < NTAB) iv[j] = *idum;
		}
		iy=iv[0];
	}
	k=(*idum)/IQ1;
	*idum=IA1*(*idum-k*IQ1)-k*IR1;
	if (*idum < 0) *idum += IM1;
	k=idum2/IQ2;
	idum2=IA2*(idum2-k*IQ2)-k*IR2;
	if (idum2 < 0) idum2 += IM2;
	j=iy/NDIV;
	iy=iv[j]-idum2;
	iv[j] = *idum;
	if (iy < 1) iy += IMM1;
	if ((temp=AM*iy) > RNMX) return RNMX;
	else return temp;
}

float ran3(long *idum)
/* Returnes a uniform random deviate between 0.0 and 1.0.
   Set idum to any negative value to initialize or reinitialize
   the sequence */
{
	static int inext,inextp;
	static long ma[56];
	static int iff=0;
	long mj,mk;
	int i,ii,k;

	if (*idum < 0 || iff == 0) {
		iff=1;
		mj=MSEED-(*idum < 0 ? -*idum : *idum);
		mj %= MBIG;
		ma[55]=mj;
		mk=1;
		for (i=1;i<=54;i++) {
			ii=(21*i) % 55;
			ma[ii]=mk;
			mk=mj-mk;
			if (mk < MZ) mk += MBIG;
			mj=ma[ii];
		}
		for (k=1;k<=4;k++)
			for (i=1;i<=55;i++) {
				ma[i] -= ma[1+(i+30) % 55];
				if (ma[i] < MZ) ma[i] += MBIG;
			}
		inext=0;
		inextp=31;
		*idum=1;
	}
	if (++inext == 56) inext=1;
	if (++inextp == 56) inextp=1;
	mj=ma[inext]-ma[inextp];
	if (mj < MZ) mj += MBIG;
	ma[inext]=mj;
	return mj*FAC;
}

int irbit1(unsigned long *iseed)
/* Returnes as an integer a random bit, based on the 18
   low-significance bits in iseed (which is modified for the next
   call) */
{
	unsigned long newbit;	// The accumulated XOR's

	newbit = (*iseed & IB18) >> 17		// get bit 18.
		^ (*iseed & IB5) >> 4			// XOR with bit 5
		^ (*iseed & IB2) >> 1			// XOR with bit 2
		^ (*iseed & IB1);				// XOR with bit 1
	*iseed=(*iseed << 1) | newbit;		// leftshift the seed and put
	return (int) newbit;		// the result of the XOR's in its bit 1
}


//return negative random seed
//this is needed to ran2
init_random_seed()
{
	long neg_mask=0x80000000;
	Rand_seed= (long)time(NULL) | neg_mask;
	//Rand_seed= 0xfff00000;
}

seed_set(long seed)
{
	long neg_mask=0x80000000;
	Rand_seed= seed | neg_mask;
}

// return random integer in the interval 1 to max_val
int
get_rand(int max_val)
{
	float tmp;
	long r;
	
	tmp=ran2(&Rand_seed)*(float)(max_val);

	
	r = ((long)(tmp))+1;
	//just to be sure on the limits (if r2 returns 0.000 or 1.000 exactly 
	if(r==0)
		r=1;
	if(r>max_val)
		r=max_val;
	return (int)(r);
}


double
get_rand_double()
{
	float frnd;

	frnd=ran2(&Rand_seed);
	return((double)frnd);
}

// old version : using simple c library function rand() 
#if 0
// return random integer in the interval 1 to max_val
int
get_rand(int max_val)
{
	long r;
	
	r = (long)(((long)rand()*(long)(max_val)) / (RAND_MAX+1));
	return (int)(r+1);
}
#endif
	



