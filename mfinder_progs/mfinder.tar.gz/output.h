#ifndef __OUTPUT_H
#define __OUTPUT_H

#include <stdio.h>

void		dump_all_ids_C_data_matrix(list* full_res);
void		dump_all_ids_data_matrix_full(list* full_res);
void		dump_all_ids_N_data_matrix(list* full_res);
void		output_header (FILE *fp, Network *N, int rnd_net_num);
int		output_results(FILE *fp, Network * N, list *final_res, list*final_res_all);
void		vertex_degree_distribution (FILE *fp, Network *N);
void		vertex_degree_distribution_accumulate (Network *N, FILE *fp, int out, int col, char *hdr);
void		vertex_extended_degree_dump (FILE *fp, Network *N, int MaxDeg);

#endif




