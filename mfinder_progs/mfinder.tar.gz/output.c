#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include "common.h"
#include "list.h"
#include "mat.h"
#include "network.h"
#include "output.h"
#include "arguments.h"

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//output all ids data matrix short format- good for matlab use in conc units
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	dump_all_ids_C_data_matrix(list* full_res)
{
	list_item *l_mtf;
	Motif_res *mtf_res;
	Neff_st eff;
	FILE	*fp = arg_get_fp("mat_s_fp");

	if (arg_get_int("mtf_sz")<=4) {
		for(l_mtf=list_get_next(full_res,NULL); l_mtf!=NULL;l_mtf=list_get_next(full_res,l_mtf)) {
			mtf_res=(Motif_res*)l_mtf->p;
			eff=mtf_res->eff_arr[arg_get_int("actual_n_eff")];
			motif_id_print (&mtf_res->id, fp, "", "");
			fprintf(fp ,"%.2f %.2f %.3f %.2f %.2f %.3f %.2f %.2f\n",
				mtf_res->conc_real, mtf_res->conc_real_zscore,
				mtf_res->conc_real_pval, eff.c_eff, eff.c_eff_zscore,
				eff.c_eff_pval, mtf_res->conc_rand_mean, mtf_res->conc_rand_std_dev);		
		}
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//output all ids data matrix long format - good for matlab use
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	dump_all_ids_data_matrix_full(list* full_res)
{
	list_item *l_mtf;
	Motif_res *mtf_res;
	Neff_st *eff_arr;
	FILE	*fp=arg_get_fp("mat_l_fp");

	fprintf(arg_get_fp("mat_l_fp"),"Motif Id\tCReal\tCReal Z\tCReal P\tCeff1\tCeff1 Z\tCeff1 P\tCeff2\tCeff2 Z\tCeff2 P\tCeff3\tCeff3 Z\tCeff3 P\tCeff4\tCeff4 Z\tCeff4 P\tCeff5\tCeff5 Z\tCeff5 P\tCRandMean\tCRandStd\tNReal\tNreal Z\tNreal P\tNeff1\tNeff1 Z\tNeff1 P\tNeff2\tNeff2 Z\tNeff2 P\tNeff3\tNeff3 Z\tNeff3 P\tNeff4\tNeff4 Z\tNeff4 P\tNeff5\tNeff5 Z\tNeff5 P\tUnique\tNRandMean\tNRandStd\t#RandNet\t#samples\n");
	if (arg_get_int("mtf_sz")<=4) {
		for(l_mtf=list_get_next(full_res,NULL); l_mtf!=NULL;l_mtf=list_get_next(full_res,l_mtf)) {
			mtf_res=(Motif_res*)l_mtf->p;
			eff_arr=mtf_res->eff_arr;
			motif_id_print (&mtf_res->id, fp, "", "");
			fprintf(fp,"%.2f\t%.3f\t%.3f\t%.2f\t%.3f\t%.3f\t%.2f\t%.3f\t%.3f\t%.2f\t%.3f\t%.3f\t%.2f\t%.3f\t%.3f\t%.2f\t%.3f\t%.3f\t%.2f\t%.2f\t%.1f\t%.3f\t%.3f\t%.2f\t%.3f\t%.3f\t%.2f\t%.3f\t%.3f\t%.2f\t%.3f\t%.3f\t%.2f\t%.3f\t%.3f\t%.2f\t%.3f\t%.3f\t%d\t%.2f\t%.2f\t%d\t%d\t\n",
						mtf_res->conc_real,mtf_res->conc_real_zscore,mtf_res->conc_real_pval,
						eff_arr[1].c_eff,eff_arr[1].c_eff_zscore,eff_arr[1].c_eff_pval,
						eff_arr[2].c_eff,eff_arr[2].c_eff_zscore,eff_arr[2].c_eff_pval,
						eff_arr[3].c_eff,eff_arr[3].c_eff_zscore,eff_arr[3].c_eff_pval,
						eff_arr[4].c_eff,eff_arr[4].c_eff_zscore,eff_arr[4].c_eff_pval,
						eff_arr[5].c_eff,eff_arr[5].c_eff_zscore,eff_arr[5].c_eff_pval,
						mtf_res->conc_rand_mean,mtf_res->conc_rand_std_dev,
						mtf_res->real_count,mtf_res->real_zscore,mtf_res->real_pval,
						eff_arr[1].n_eff,eff_arr[1].n_eff_zscore,eff_arr[1].n_eff_pval,
						eff_arr[2].n_eff,eff_arr[2].n_eff_zscore,eff_arr[2].n_eff_pval,
						eff_arr[3].n_eff,eff_arr[3].n_eff_zscore,eff_arr[3].n_eff_pval,
						eff_arr[4].n_eff,eff_arr[4].n_eff_zscore,eff_arr[4].n_eff_pval,
						eff_arr[5].n_eff,eff_arr[5].n_eff_zscore,eff_arr[5].n_eff_pval,
						(int)mtf_res->unique_appear,
						mtf_res->rand_mean, mtf_res->rand_std_dev,
						arg_get_int("rnd_net_num"),
						arg_get_int("prob_app_samples_num"));
		}
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//output all ids data matrix short format- good for matlab use in counts units
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	dump_all_ids_N_data_matrix(list* full_res)
{
	list_item *l_mtf;
	Motif_res *mtf_res;
	Neff_st eff;
	FILE *fp=arg_get_fp("mat_s_fp");

	if (arg_get_int("mtf_sz")<=4) {
		for(l_mtf=list_get_next(full_res,NULL); l_mtf!=NULL;l_mtf=list_get_next(full_res,l_mtf)) {
			mtf_res=(Motif_res*)l_mtf->p;
			eff=mtf_res->eff_arr[arg_get_int("actual_n_eff")];
			motif_id_print (&mtf_res->id, fp, "", "");
			fprintf(fp," %.1f %.2f %.3f %.2f %.2f %.3f %.2f %.2f\n",
				mtf_res->real_count,mtf_res->real_zscore,
				mtf_res->real_pval,eff.n_eff,eff.n_eff_zscore,
				eff.n_eff_pval,mtf_res->rand_mean, mtf_res->rand_std_dev);		
		}
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void output_header (FILE *fp, Network *N, int rnd_net_num)
{
	long	now;

	if (!N)
		return;

	now= time(NULL);

	fprintf(fp,"\tmotif finder version %s                    %s", arg_get_char("version"), ctime(&now));
	fprintf(fp,"\t===================================================================\n");

	fprintf(fp,"\n\tMOTIF FINDER RESULTS: \n\n");
	fprintf(fp,"\tnetwork name : %s\n",N->name);
	fprintf(fp,"\tNum of Vertices: %d   Num of arcs: %d  Num of colors: %d\n", 
				N->vertices_num, N->edges_num, N->colors);
	fprintf(fp,"\tNum of Connected Vertices: %d\n", N->con_vertices_num);
	fprintf(fp,"\tMotif size searched is %d\n",arg_get_int("mtf_sz"));
	fprintf(fp,"\tNumber of random network generated is : %d\n\n",rnd_net_num);

	if (arg_get_int("rnd_net_num")) {
		if(arg_get_int("run_prob_app"))
			fprintf(fp,"\n\tAlgorithm used : Probabilistic (num of samples : %d)\n\n",arg_get_int("prob_app_samples_num"));
		else
			fprintf(fp,"\n\tAlgorithm used : Exhaustive Search\n\n");
	}

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int	output_results(FILE *fp, Network * N, list *list_of_encountered_motifs_res, list *list_of_all_motifs_res)
{
	int	prof;				//	index on profiles
	int	vedc;
	int	rc=RC_OK;
	int	rnd_net_num=arg_get_int("rnd_net_num");
	int	pcolors = (int)pow(2,N->colors);
	char*	prog="output_results";

#if	DEBUG_TRACE > 0
	printf("%s: entered with %p, %p\n", prog, list_of_encountered_motifs_res, list_of_all_motifs_res);
#endif

//	write output header, distribution of edge profiles and distribution of extended degrees
	output_header (fp, N, rnd_net_num);

//	present profile frequency
	if (PROFILES) {
		fprintf(fp,"\tDistribution of arc profiles (edges with arcs both ways are counted in two profiles)\n");
		fprintf(fp,"\tArc Profile\tfrequency\n");
		for (prof = 0; prof < PROFILES; prof++)
			fprintf(fp, "\t%2d (%d,%d)\t%5d\n", 
			prof, profile_out(prof, pcolors), profile_in(prof, pcolors), N->profs[prof]);
		fprintf(fp, "\n");
	}

//	present extended vertex degree distribution
	if (vedc=arg_get_int("stat_vertex_extended_degree_cap")) vertex_extended_degree_dump (fp, N, vedc);

//	present vertex degree distribution
	if (vedc=arg_get_int("stat_vertex_degree")) vertex_degree_distribution (fp, N);

//	write the motifs encountered
	motif_res_dump (fp, N, list_of_encountered_motifs_res, rnd_net_num, N->colors);

// do the reporting on 'res'
	if (rnd_net_num) {
		motif_res_dump_significnat (fp, N, list_of_encountered_motifs_res, rnd_net_num, N->colors);
		dump_final_res (fp, list_of_all_motifs_res, arg_get_int("mtf_sz"), arg_get_int("actual_n_eff"));
	}

	//if not finished generating  random networks , return here
	//finished all random networks generating
	if(arg_get_int("out_s_mat_flag")==TRUE) {
		if(arg_get_int("out_s_c_mat_flag"))
			dump_all_ids_C_data_matrix(list_of_all_motifs_res);
		else
			dump_all_ids_N_data_matrix(list_of_all_motifs_res);
	}
	if(arg_get_int("out_l_mat_flag"))
		dump_all_ids_data_matrix_full(list_of_all_motifs_res);

#if	DEBUG_TRACE > 0
	printf("%s: returned\n", prog);
#endif

	return rc;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	present distribution of network degrees
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void vertex_degree_distribution (FILE *fp, Network *N)
{
	int	d;
	list	*degree_dist;
	char*	prog="vertex_degree_distribution";

	if (!N)
		return;

//	do out-degree distributions for every color combination
	for (d=1; d<PCOLORS; d++)
		vertex_degree_distribution_accumulate (N, fp, 1, d, "out degrees for combined color");

//	do out-degree distributions for every color combination
	for (d=1; d<PCOLORS; d++)
		vertex_degree_distribution_accumulate (N, fp, 0, d, "in degrees for combined color");

//	do out-degree distributions for every pure color
	for (d=0; d<COLORS; d++)
		vertex_degree_distribution_accumulate (N, fp, 1, -(d+1), "out degrees for pure color");

//	do out-degree distributions for every pure color
	for (d=0; d<COLORS; d++)
		vertex_degree_distribution_accumulate (N, fp, 0, -(d+1), "in degrees for pure color");

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	present distribution of network degrees
//	arguments:
//	Network *N				-	network
//	list *degree_dist		-	list in which the distribution is retained
//	int out					-	if true - calculate out degree, if false - do in degree
//	int col					-	color to be calculated. if positive use as combined color, if negative use as mask
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void vertex_degree_distribution_accumulate (Network *N, FILE *fp, int out, int col, char *hdr)
{
	int	i,j,k,c;
	int	vertices=N->vertices_num;
	Mat	*M = N->mat;
	SparseMatrix	*S = N->mat->spr;
	list	*degree_dist, *lst;
	int	deg;
	list_item	*li;
	int	*pi;
	char*	prog="vertex_degree_distribution_accumulate ";

	if (!N)
		return;

	list_ini(&degree_dist, LIST_KEY_INT);

//	loop on vertices to handle each of them
	for (i=1; i<=vertices; i++) {

//	calculate degree
		if (M->type == FULL) {
			deg = 0;
			for (j=1; j<=vertices; j++) {
				if (out)
					c= MatGet(M,i,j);
				else 
					c= MatGet(M,j,i);
				if (col > 0) {
					if (c == col)
						deg++;
				} else {
					if (c & -col)
						deg++;
				}
			}
		} else if  (M->type == SPARSE) {
			deg = 0;
			if (out) 
				lst = S->m[i].to;
			else
				lst = S->m[i].from;
			if(lst)
				for(li=list_get_next(lst,NULL); li; li=list_get_next(lst,li)) {
					pi = (int*)li->p;
					c = *pi;
					if (col > 0) {
						if (c == col)
							deg++;
					} else {
						if (c & -col)
							deg++;
					}
				}
		}

//	add to/in list
		li = list_get_by_key(degree_dist, &deg);
		if (li) {
			pi = (int *)li->p;
			*pi += 1;
		} else {
			pi = (int *)myalloc (sizeof(int));
			*pi = 1;
			list_ins(degree_dist, &deg, pi);
		}
	}

//	write distribution
	fprintf (fp, "\n\tDistribution of vertex degree for %s %d\n\tdegree\tfreq.\n", hdr, col > 0 ? col : -col);
	for (li=list_get_next(degree_dist, NULL); li; li=list_get_next(degree_dist, li)) {
		pi = (int *)li->p;
		fprintf(fp, "\t%3d\t%4d\n", li->val, *pi);
	}

	list_free_mem(degree_dist);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	dump the distribution of network extended degrees
//	arguments
//	FILE *fp		-	output stream
//	Network *N	-	network
//	int MaxDeg	-	truncation limit for degrees. if pow(Maxdeg, pcolors*2) cannot fit into 32 bit there will be a problem.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void vertex_extended_degree_dump (FILE *fp, Network *N, int MaxDeg)
{
	int	i,j,k, c;
	int	vertices=N->vertices_num;
	Mat	*M = N->mat;
	SparseMatrix	*S = N->mat->spr;
	int	pcolors = (int)pow(2,N->colors);
	int	in_deg[PCOLORS];
	int	out_deg[PCOLORS];
	list	*degree_dist;
	list	*lst;
	int	deg;
	VERYLONGINT	l;									//	this usage of VERYLONGINT has nothing to do with motif IDs or list keys
	list_item	*li;
	int	*pi;
	char*	prog="vertex_extended_degree_dump";

	if (!N)
		return;

//	initialize structure (and allocate memory)
	list_ini(&degree_dist, LIST_KEY_INT);

//	loop on the vertices of the network 'N' to handle each of them
	for (i=1; i<=vertices; i++) {

//	for each vertex - initialize the extended degree counters
		for (k=0; k<pcolors; k++) {
			in_deg[k] = 0;
			out_deg[k] = 0;
		}

//	for each vertex - calculate the extended degree
		if (M->type == FULL) 
			for (j=1; j<=vertices; j++) {
				c= MatGet(M,i,j);
				if (c < 0 || c >= pcolors)
					printf ("%s: illegal color\n", prog); 
				else 
					if (c) out_deg[c]++;
				c= MatGet(M,j,i);
				if (c < 0 || c >= pcolors)
					printf ("%s: illegal color\n", prog); 
				else 
					if (c) in_deg[c]++;
			}
		else if  (M->type == SPARSE) {
			if((lst = S->m[i].to) != NULL)
				for(li=list_get_next(lst,NULL); li; li=list_get_next(lst,li)) {
					pi = (int*)li->p;
					c = *pi;
					if (c < 0 || c >= pcolors)
						printf ("%s: illegal color\n", prog); 
					else 
						if (c) out_deg[c]++;
				}
			if((lst = S->m[i].from) != NULL)
				for(li=list_get_next(lst,NULL); li; li=list_get_next(lst,li)) {
					pi = (int*)li->p;
					c = *pi;
					if (c < 0 || c >= pcolors)
						printf ("%s: illegal color\n", prog); 
					else 
						if (c) in_deg[c]++;
				}
		}

//	encode the degrees into one long integer
		deg = 0;
		l = 1;
		for (k=1; k<pcolors; k++) {
			if (out_deg[k]>=MaxDeg)	out_deg[k]=MaxDeg-1;
			deg += l*out_deg[k];
			l *= MaxDeg;
		}
		for (k=1; k<pcolors; k++) {
			if (in_deg[k]>=MaxDeg)	in_deg[k]=MaxDeg-1;
			deg += l*in_deg[k];
			l *= MaxDeg;
		}

//	add to/in list
		li = list_get_by_key(degree_dist, &deg);
		if (li) {
			pi = (int *)li->p;
			*pi += 1;
		} else {
			pi = (int *)myalloc (sizeof(int));
			*pi = 1;
			list_ins(degree_dist, &deg, pi);
		}
	}

//	write the distribution
	fprintf (fp, "\n\tDistribution of extended-degree (truncated to %d)\n\tfreq.\tout degree\t\t|\tin degree\n", MaxDeg-1);
	for (li=list_get_next(degree_dist, NULL); li; li=list_get_next(degree_dist, li)) {
		pi = (int *)li->p;
		fprintf(fp, "\t%3d", *pi);
		deg = li->val;
//		motif_id_print (&deg, fp, "|", "|");
		j = 1;
		for (k=1; k<pcolors; k++) {
			j *= MaxDeg;
			i = deg % MaxDeg;
			fprintf(fp, "\t%3d", i);
			if(i==MaxDeg-1) fprintf(fp, "+");
			deg -=i;
			deg /= MaxDeg;
		}
		fprintf(fp, "\t|");
		for (k=1; k<pcolors; k++) {
			j *= MaxDeg;
			i = deg % MaxDeg;
			fprintf(fp, "\t%3d", i);
			if(i==MaxDeg-1) fprintf(fp, "+");
			deg -=i;
			deg /= MaxDeg;
		}
		fprintf(fp, "\n");
	}

//	deallocate memory
	list_free_mem(degree_dist);
}
