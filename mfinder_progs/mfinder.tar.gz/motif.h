#ifndef __MOTIF_H
#define __MOTIF_H


#include <stdio.h>
#include "mat.h"

typedef struct {
	char	id[MOTIF_ID_AND_LIST_KEY_SIZE];
} MotifID;

typedef struct {
	MotifID	id;
	double count;
	double prob_count; //sigma (Ri/pi)
	double conc; //concentration in mili motifs (counts/total motif counts)*1000
	list *members;
}Motif;

int	motif_contains_isolated_vertex (MotifID *id, int mtf_sz);
int	motif_contains_self_loop (MotifID *id, int mtf_sz);
int	motif_count_edges_old (Motif *mtf, int colors);
int	motif_count_edges (Motif *mtf, int colors);
int	motif_delete (Motif *m);
void	motif_dump(FILE *fp, Motif *m, char *msg);
void	motif_id_from_matrix_old(MotifID *id, Matrix *M, int colors, int pcolors);
void	motif_id_from_matrix(MotifID *id, Matrix *M, int colors, int pcolors);
void	motif_id_minimal (MotifID *id, int mtf_sz, int colors);
int	motif_id_next(MotifID *id, int mtf_sz, int colors);
void	motif_id_print (MotifID *id, FILE *fp, char* before, char* after);
void	motif_id_to_matrix_old(Matrix *M, MotifID *id_p, int colors);
void	motif_id_to_matrix(Matrix *M, MotifID *id, int colors);
Motif * motif_ini ();
void	motif_insert_members (Motif* mtf, list* vrtx_set, int mtf_sz);
int	motif_is_int (MotifID *id, int i);
void 	motif_list_unify_isomorphic (list **motif_list_p, int mtf_sz, int colors);
void	motif_matrix_dump (FILE *fp, MotifID *mtf_id, int dim, int colors);
int	motif_members_intersect_array (Motif *mtf,int *mtf_vrtx_arr,int mtf_sz);
void	motif_occurence_dump (FILE *fp, list *vrtx_set, MotifID *mtf_id, int mtf_sz, int colors, list *dmp_mtf_lst, int num);
void	motifs_dump(FILE *fp, list *res, char *name);

#endif




