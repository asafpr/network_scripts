#ifndef __ARGUMENTS_H
#define __ARGUMENTS_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include "common.h"

typedef struct {
	int	mtf_sz;							//	motif size
	int	rnd_net_num;					//	number of random networks to generate
	double t_init;							// initial temperature for metropolis randomization
	double iteration_factor;			// how many metropolis steps
	double e_thresh;						// energy stop threshold for metropolis randomization
	char	input_network_fname[80];	//	input file name
	char	out_fname[80];					//	output file name
	char	log_fname[80];					//	log file name
	char	mat_s_fname[80];				//	matlab short output file name
	char	mat_l_fname[80];				//	matlab short output file name
	char	mat_metrop_fname[80];		//	matlab metropolis output file name
	char	inter_out_fname[80];			//	intermediate output file name
	char	motif_occr_fname[80];		//	file name where motif occurences are written
	char	required_motifs_fname[80];	//	file name containing motifs for which dump occurence is required
	int	long_out_flag;					//	short_output_flag
	int	out_s_mat_flag;				//	ouput matlab matrix short format
	int	out_l_mat_flag;				//	ouput matlab matrix long format
	int	out_s_c_mat_flag;				//	ouput matlab matrix short format in conc
	int	out_random_flag;						//	output random networks
	int	out_metrop_mat_flag;			//	ouput metropolis format
	int	motif_occr_dump;				//	list occurences of motifs
	int	actual_n_eff;					// Neff to use (1-5)
	int	calc_unique_flag;				//	claculate unique appearances flag
	int	undirected_flag;				//	input network is undirected graph
	int	use_metropolis;				//	randomize networks with metropolis algorithm
	int	run_prob_app;					//	run probabilistic approach flag
	int	prob_app_samples_num;		//	probabilistic approach samples number
	double mfactor_th;					//	mfactor to take into acount for th
	double zfactor_th;					//	zscore to take into acount for th
	int	quiet_mode;						//	quiet mode flag
	int	out_intermediate;				//	ouput intermediate results
	int	dont_search_real;				//	do not search real network
	int	r_switch_factor;				//	number of edges switch factor, when genrating random network 
	int	ts;								//	if true, the direction of order of vertixes indicating an arc is t<-s;
												//	if false (default) it is s->t
	char	rnd[2];							//	randomization mode
	FILE	*out_fp;
	FILE	*log_fp;
	FILE	*mat_s_fp;
	FILE	*mat_l_fp;
	FILE	*mat_metrop_fp;
	FILE	*inter_out_fp;
	FILE	*motif_occr_fp;
	FILE	*required_motifs_fp;
	Runtime total_time;
	Runtime real_net_time;
	Runtime rand_net_time;
	int	stat_vertex_extended_degree_cap;
	int	stat_vertex_degree;
	int	stat_motif_distribution;
	int	stat_motif_distribution_tolerance;
	int	stat_bipartiate;
	char	version[3];
}Gnrl_st;

char * arg_get_char (char *argname);
double	arg_get_double (char *argname);
FILE * arg_get_fp (char *argname);
int	arg_get_int (char *argname);
Runtime * arg_get_rt (char *argname);
void	arg_put_rt (char *argname, Runtime *rt);
void	arg_put_fp (char *argname, FILE *fp);
int	process_input_args(int argc, char *argv[]);
void	usage();

#endif
