#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include "common.h"
#include "list.h"
#include "mat.h"
#include "network.h"
#include "hash.h"
#include "permutation.h"
#include "metropolis.h"

/******************************* Externs *********************************/
extern void
init_random_seed();

// return random integer in the interval 1 to max_val
extern int
get_rand(int max_val);
extern double get_rand_double();



/***************** Shalev's functions *************************/

void zero_neighbours(int *arr,int *arr_len)
{
	register int i;

	for (i=0;i<ARR_NUM;i++)
	{
		arr[i]=0;
	}
	
	*arr_len=0;
}

void fill_neighbours(Network *N,int s,int t,int direct,int *arr,int *arr_len)
/* add all weakly connected nodes of s to arr, and return also arr_len */
/* direct - 1 if  there is an edge from s to t.
			0 if there is an edge from t to s
/* don't add node t */
{
	list_item *tmp;
	list_item *tmp2;

	// add all incoming and outgoing edges from/to node s, except t
	tmp = list_get_next(N->mat->spr->m[s].to,NULL);
	tmp2 = list_get_next(N->mat->spr->m[s].from,NULL);

	while (tmp != NULL)
	{
		if (direct)
		{
			if (tmp->val!=t)
			{
				arr[*arr_len]=tmp->val;
				(*arr_len)=(*arr_len)+1;
			}
		}
		else
		{
			arr[*arr_len]=tmp->val;
			(*arr_len)=(*arr_len)+1;
			
		}
		tmp=list_get_next(N->mat->spr->m[s].to,tmp);
	}

	while (tmp2 != NULL)
	{
		if (!direct)
		{
			if (tmp2->val!=t)
			{
				arr[*arr_len]=tmp2->val;
				(*arr_len)=(*arr_len)+1;
			}
		}
		else
		{
			arr[*arr_len]=tmp2->val;
			(*arr_len)=(*arr_len)+1;
		}
		tmp2=list_get_next(N->mat->spr->m[s].from,tmp2);
	}
	
}


void fill_13(Network *N,int s1,int t1,int s2,int t2,int sub[14],int add[14])
/* computes the current 13 3-node circuits of s1-t1 and neighbours
   and s2-t2+neighbours. Puts results in sub-a 13*1 vector.
   computes the future 13 3-node circuits of s1-t2 and neighbours
   and s2-t1+neighbours. Puts results in add-a 13*1 vector.
   Takes into account that single edges are switched*/
{
   int sarr1[ARR_NUM];
   int tarr1[ARR_NUM];
   int sarr2[ARR_NUM];   
   int tarr2[ARR_NUM];
   int sarr1_len,tarr1_len,sarr2_len,tarr2_len;
   register int i;
   int state_var;
   int index;
   int old_triple[ARR_NUM][4];
   int new_triple[ARR_NUM][4];
   int old_len=0;
   int new_len=0;
   int first,second,third;

   zero_neighbours(sarr1,&sarr1_len);
   zero_neighbours(tarr1,&tarr1_len);
   zero_neighbours(sarr2,&sarr2_len);
   zero_neighbours(tarr2,&tarr2_len);

   fill_neighbours(N,s1,t1,1,sarr1,&sarr1_len);
   fill_neighbours(N,t1,s1,0,tarr1,&tarr1_len);
   fill_neighbours(N,s2,t2,1,sarr2,&sarr2_len);
   fill_neighbours(N,t2,s2,0,tarr2,&tarr2_len);

   for (i=0;i<14;i++)
   {
		sub[i]=0;
		add[i]=0;
   }

   for (i=0;i<ARR_NUM;i++)
   {
		old_triple[i][0]=0;old_triple[i][1]=0;old_triple[i][2]=0;old_triple[i][3]=0;
		new_triple[i][0]=0;new_triple[i][1]=0;new_triple[i][2]=0;new_triple[i][3]=0;
   }
   old_len=0;
   new_len=0;

//	fprintf(arg_get_fp("mat_metrop_fp","starting old set\n");

   /* update sub with the circuits of sarr1,s1,t1 */
   for (i=0;i<sarr1_len;i++)
   {
		refine(old_triple,&old_len,sarr1[i],s1,t1);
   }

   /* update sub with the circuits of s1,t1,tarr1 */
   for (i=0;i<tarr1_len;i++)
   {
		refine(old_triple,&old_len,s1,t1,tarr1[i]);
   }

	/* update sub with the circuits of sarr2,s2,t2 */
   for (i=0;i<sarr2_len;i++)
   {
		refine(old_triple,&old_len,sarr2[i],s2,t2);
   }


   /* update sub with the circuits of s2,t2,tarr2 */
   for (i=0;i<tarr2_len;i++)
   {
		refine(old_triple,&old_len,s2,t2,tarr2[i]);
   }


	/********* New bug fix - when a node connects to both s1 and t2 **********/
   /* update sub with the circuits of sarr1,s1,t2 */
   for (i=0;i<sarr1_len;i++)
   {
		refine(old_triple,&old_len,sarr1[i],s1,t2);
   }

   /* update sub with the circuits of s1,t2,tarr2 */
   for (i=0;i<tarr2_len;i++)
   {
		refine(old_triple,&old_len,s1,t2,tarr2[i]);
   }

	/* update sub with the circuits of sarr2,s2,t1 */
   for (i=0;i<sarr2_len;i++)
   {
		refine(old_triple,&old_len,sarr2[i],s2,t1);
   }


   /* update sub with the circuits of s2,t1,tarr1 */
   for (i=0;i<tarr1_len;i++)
   {
		refine(old_triple,&old_len,s2,t1,tarr1[i]);
   }



   for (i=0;i<old_len;i++)
   {
	   first=old_triple[i][1];
	   second=old_triple[i][2];
	   third=old_triple[i][3];
	   state_var=32*is_edge(N,first,second)+16*is_edge(N,second,third)+8*is_edge(N,third,first)
		+4*is_edge(N,second,first)+2*is_edge(N,third,second)+is_edge(N,first,third);
		index=elm(state_var);
		if ((index>0)&&(index<=13))
			sub[index]=sub[index]+1;
		state_var=32*is_edge2(N,first,second,s1,t1,s2,t2)+16*is_edge2(N,second,third,s1,t1,s2,t2)+8*is_edge2(N,third,first,s1,t1,s2,t2)
		+4*is_edge2(N,second,first,s1,t1,s2,t2)+2*is_edge2(N,third,second,s1,t1,s2,t2)+is_edge2(N,first,third,s1,t1,s2,t2);
		index=elm(state_var);
		if ((index>0)&&(index<=13))
			add[index]=add[index]+1;
   }

#if 0 
   //fprintf(arg_get_fp("mat_metrop_fp"),"starting new set\n");
   /* update add with the circuits of sarr1,s1,t2 */
   for (i=0;i<sarr1_len;i++)
   {
		refine(new_triple,&new_len,sarr1[i],s1,t2);
   }

   /* update add with the circuits of s1,t2,tarr2 */
   for (i=0;i<tarr2_len;i++)
   {
		refine(new_triple,&new_len,s1,t2,tarr2[i]);
   }

	/* update add with the circuits of sarr2,s2,t1 */
   for (i=0;i<sarr2_len;i++)
   {
		refine(new_triple,&new_len,sarr2[i],s2,t1);
   }


   /* update add with the circuits of s2,t1,tarr1 */
   for (i=0;i<tarr1_len;i++)
   {
		refine(new_triple,&new_len,s2,t1,tarr1[i]);
   }
	

   	/********* New bug fix - when a node connects to both s1 and t2 **********/
   /* update sub with the circuits of sarr1,s1,t1 */
   for (i=0;i<sarr1_len;i++)
   {
		refine(new_triple,&new_len,sarr1[i],s1,t1);
   }

   /* update sub with the circuits of s1,t1,tarr1 */
   for (i=0;i<tarr1_len;i++)
   {
		refine(new_triple,&new_len,s1,t1,tarr1[i]);
   }

	/* update sub with the circuits of sarr2,s2,t2 */
   for (i=0;i<sarr2_len;i++)
   {
		refine(new_triple,&new_len,sarr2[i],s2,t2);
   }


   /* update sub with the circuits of s2,t1,tarr2 */
   for (i=0;i<tarr2_len;i++)
   {
		refine(new_triple,&new_len,s2,t2,tarr2[i]);
   }


   
   for (i=0;i<new_len;i++)
   {
	   first=new_triple[i][1];
	   second=new_triple[i][2];
	   third=new_triple[i][3];
	   state_var=32*is_edge2(N,first,second,s1,t1,s2,t2)+16*is_edge2(N,second,third,s1,t1,s2,t2)+8*is_edge2(N,third,first,s1,t1,s2,t2)
		+4*is_edge2(N,second,first,s1,t1,s2,t2)+2*is_edge2(N,third,second,s1,t1,s2,t2)+is_edge2(N,first,third,s1,t1,s2,t2);
		index=elm(state_var);
		if ((index>0)&&(index<=13))
			add[index]=add[index]+1;
   }
#endif   
}


void fill_13_dbl(Network *N,int s1,int t1,int s2,int t2,int sub[14],int add[14])
/* computes the current 13 3-node circuits of s1-t1+neighbours
   and s2-t2+neighbours. Puts results in sub-a 13*1 vector.
   computes the future 13 3-node circuits of s1-t2 and neighbours
   and s2-t1+neighbours. Puts results in add-a 13*1 vector.
   Takes into account that double edges are switched*/
{

   int sarr1[ARR_NUM];
   int tarr1[ARR_NUM];
   int sarr2[ARR_NUM];   
   int tarr2[ARR_NUM];
   int sarr1_len,tarr1_len,sarr2_len,tarr2_len;
   register int i;
   int state_var;
   int index;
   int old_triple[ARR_NUM][4];
   int new_triple[ARR_NUM][4];
   int old_len=0;
   int new_len=0;
   int first,second,third;

   zero_neighbours(sarr1,&sarr1_len);
   zero_neighbours(tarr1,&tarr1_len);
   zero_neighbours(sarr2,&sarr2_len);
   zero_neighbours(tarr2,&tarr2_len);

   fill_neighbours(N,s1,t1,1,sarr1,&sarr1_len);
   fill_neighbours(N,t1,s1,0,tarr1,&tarr1_len);
   fill_neighbours(N,s2,t2,1,sarr2,&sarr2_len);
   fill_neighbours(N,t2,s2,0,tarr2,&tarr2_len);

   for (i=0;i<14;i++)
   {
		sub[i]=0;
		add[i]=0;
   }

   for (i=0;i<ARR_NUM;i++)
   {
		old_triple[i][0]=0;old_triple[i][1]=0;old_triple[i][2]=0;old_triple[i][3]=0;
		new_triple[i][0]=0;new_triple[i][1]=0;new_triple[i][2]=0;new_triple[i][3]=0;
   }
   old_len=0;
   new_len=0;

//	fprintf(arg_get_fp("mat_metrop_fp"),"starting old set\n");

   /* update sub with the circuits of sarr1,s1,t1 */
   for (i=0;i<sarr1_len;i++)
   {
		refine(old_triple,&old_len,sarr1[i],s1,t1);
   }

   /* update sub with the circuits of s1,t1,tarr1 */
   for (i=0;i<tarr1_len;i++)
   {
		refine(old_triple,&old_len,s1,t1,tarr1[i]);
   }

	/* update sub with the circuits of sarr2,s2,t2 */
   for (i=0;i<sarr2_len;i++)
   {
		refine(old_triple,&old_len,sarr2[i],s2,t2);
   }


   /* update sub with the circuits of s2,t2,tarr2 */
   for (i=0;i<tarr2_len;i++)
   {
		refine(old_triple,&old_len,s2,t2,tarr2[i]);
   }


	/********* New bug fix - when a node connects to both s1 and t2 **********/
   /* update sub with the circuits of sarr1,s1,t2 */
   for (i=0;i<sarr1_len;i++)
   {
		refine(old_triple,&old_len,sarr1[i],s1,t2);
   }

   /* update sub with the circuits of s1,t2,tarr2 */
   for (i=0;i<tarr2_len;i++)
   {
		refine(old_triple,&old_len,s1,t2,tarr2[i]);
   }

	/* update sub with the circuits of sarr2,s2,t1 */
   for (i=0;i<sarr2_len;i++)
   {
		refine(old_triple,&old_len,sarr2[i],s2,t1);
   }


   /* update sub with the circuits of s2,t1,tarr1 */
   for (i=0;i<tarr1_len;i++)
   {
		refine(old_triple,&old_len,s2,t1,tarr1[i]);
   }



   for (i=0;i<old_len;i++)
   {
	   first=old_triple[i][1];
	   second=old_triple[i][2];
	   third=old_triple[i][3];
	   state_var=32*is_edge(N,first,second)+16*is_edge(N,second,third)+8*is_edge(N,third,first)
		+4*is_edge(N,second,first)+2*is_edge(N,third,second)+is_edge(N,first,third);
		index=elm(state_var);
		if ((index>0)&&(index<=13))
			sub[index]=sub[index]+1;
		state_var=32*is_edge2_dbl(N,first,second,s1,t1,s2,t2)+16*is_edge2_dbl(N,second,third,s1,t1,s2,t2)+8*is_edge2(N,third,first,s1,t1,s2,t2)
		+4*is_edge2_dbl(N,second,first,s1,t1,s2,t2)+2*is_edge2_dbl(N,third,second,s1,t1,s2,t2)+is_edge2_dbl(N,first,third,s1,t1,s2,t2);
		index=elm(state_var);
		if ((index>0)&&(index<=13))
			add[index]=add[index]+1;
   }

}



int is_edge(Network *N,int node1,int node2)
/* checks if there is an edge between node1 and node2 */

{
	register int i;
	
	return(MatGet(N->mat,node1,node2));

}

int is_edge2(Network *N,int node1,int node2,int s1,int t1,int s2,int t2)
/* checks if there is an edge between node1 and node2
   if we are at the cross edges s1->t2 or s2->t1 output 1 */

{
	register int i;
	
	if (((node1==s1)&&(node2==t2))||((node1==s2)&&(node2==t1)))
		return(1);
/*	if (((node2==s1)&&(node1==t2))||((node2==s2)&&(node1==t1)))
		return(1);*/
	if (((node1==s1)&&(node2==t1))||((node1==s2)&&(node2==t2)))
		return(0);
	/*if (((node2==s1)&&(node1==t1))||((node2==s2)&&(node1==t2)))
		return(0);*/
	return(MatGet(N->mat,node1,node2));

}


int is_edge2_dbl(Network *N,int node1,int node2,int s1,int t1,int s2,int t2)
/* checks if there is an edge between node1 and node2
   if we are at the cross edges s1->t2 or s2->t1 output 1 
   considers that a switch means switching putting on
   t2->s1 and t1->s2*/

{
	register int i;
	
	if (((node1==s1)&&(node2==t2))||((node1==s2)&&(node2==t1)))
		return(1);
	if (((node2==s1)&&(node1==t2))||((node2==s2)&&(node1==t1)))
		return(1);
	if (((node1==s1)&&(node2==t1))||((node1==s2)&&(node2==t2)))
		return(0);
	if (((node2==s1)&&(node1==t1))||((node2==s2)&&(node1==t2)))
		return(0);
	return(MatGet(N->mat,node1,node2));

}

int elm(int state)
{


	switch (state)
		{
			
			case 10 :
			case 20 :
			case 33 :
					return(1);
			case 11 :
			case 22 :
			case 26 :
			case 37 :
			case 41 :
			case 52 :
					return(2);
			case 27 :
			case 45 :
			case 54 :
					return(3);
			case 12 :
			case 17 :
			case 34 :
					return(4);
			case 3 :
			case 5 :
			case 6 :
			case 24 :
			case 40 :
			case 48 :
					return(5);
			case 13 :
			case 19 :
			case 25 :
			case 38 :
			case 44 :
			case 50 :
					return(6);
			case 7  :
			case 56  :
					return(7);
			case 15 :
			case 23 :
			case 39 :
			case 57 :
			case 58 :
			case 60 :
					return(8);
			case 31 :
			case 47 :
			case 55 :			
			case 59 :
			case 61 :
			case 62 :			
					return(9);
			case 63 :
					return(10);
			case 14 :
			case 21 :
			case 28 :
			case 35 :
			case 42 :
			case 49 :
					return(11);
			case 29 :
			case 46 :
			case 51 :
					return(12);
			case 30 :
			case 43 :
			case 53 :
					return(13);
			default :
					return(0);
		
		}
}

void refine(int triples[ARR_NUM][4],int *len,int first,int second,int third)
/* checks if the triple already occurs in triples. If 
   not, adds it. */
{
		register int i;
		int t1[4],t2[4],t3[4],t4[4],t5[4],t6[4];
		int check_len;
		int write=1;
		

		//create all possible 6 permutations of 3 elements

		t1[1]=first; t1[2]=second; t1[3]=third;
		t2[1]=second; t2[2]=third;  t2[3]=first;
		t3[1]=third; t3[2]=first; t3[3]=second;
		t4[1]=first; t4[2]=third; t4[3]=second;
		t5[1]=third; t5[2]=second; t5[3]=first;
		t6[1]=second; t6[2]=first; t6[3]=third;

		check_len=*len;

		if ((first==second)||(second==third)||(first==third))
			return;
		for (i=0;i<check_len;i++)
		{
			if ((equal(t1,triples[i],3))||(equal(t2,triples[i],3))||(equal(t3,triples[i],3))
				||(equal(t4,triples[i],3))||(equal(t5,triples[i],3))||(equal(t6,triples[i],3)))
				//write=0;
				return;
			
		}

		if (write==1)
		{
			triples[(*len)][1]=first;
			triples[(*len)][2]=second;
			triples[(*len)][3]=third;
			(*len)=(*len)+1;
			//fprintf(arg_get_fp("mat_metrop_fp"),"%d %d %d\n",first,second,third);
		}
}

int equal(int *t1,int *t2,int len)
/* returnes 1 if the vectors t1 and t2 are equal between indices 1 and len */
{
	register int i;
	int result=1;

	for (i=1;i<=len;i++)
		if (t1[i]!=t2[i])
			result=0;

	return(result);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
/* shalev's metropolis additions frmo main */
/* takes the motif results and puts them in a 13vec */
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void met_dump_motifs_res(list *res, char *network_name,int vec13[14])
{
	Motif *m;
	list_item *l_res_id;
	int id,i,index;
	int nadav2elem[239];
	nadav2elem[6]=1;nadav2elem[14]=2;nadav2elem[78]=3;nadav2elem[36]=4;
	nadav2elem[12]=5;nadav2elem[74]=6;nadav2elem[98]=7;nadav2elem[102]=8;nadav2elem[110]=9;
	nadav2elem[238]=10;nadav2elem[38]=11;nadav2elem[108]=12;nadav2elem[46]=13;
	VERYLONGINT	*vli;
	char	*prog="met_dump_motifs_res";

	if (sizeof(VERYLONGINT) != sizeof(MotifID)) {
		printf ("%s cannot handle motifs of size different from VERYLONGINT\n", prog);
		exit (-1);
	}

	for (i=1;i<=13;i++)
		vec13[i]=0;

	//printf("motifs results for %s :\n", network_name);
	for(l_res_id=list_get_next(res,NULL); l_res_id!=NULL;
		l_res_id=list_get_next(res,l_res_id)) 
		{
			//id=l_res_id->val;
			m=(Motif *)l_res_id->p;
//			id=m->id;
			vli = (VERYLONGINT *)&m->id;
			id=*vli;
			index=nadav2elem[id];
			//vec13[index]=*(int*)l_res_id->p;
			vec13[index]=m->count;
		}
}

			


// compute the real number of motifs
void met_motifs_search_real(Network *N,Res_tbl *met_res_tbl,int vec[14])
{
	Runtime	rt;
	int rc=RC_OK;
	
	time_measure_start(&rt);
	arg_put_rt("real_net_time", &rt);

	//if(arg_get_int("run_prob_app")==FALSE)
		search_motifs(N, 3, met_res_tbl->real, REAL_NET);
	//else
	//	search_motifs_prob(N, arg_get_int("mtf_sz"), RES_TBL.real, REAL_NET);
	//free_network_mem(N);

	//calc result after isomorphism of ids
	motif_list_unify_isomorphic(&met_res_tbl->real, 3, N->colors);
//	fprintf(arg_get_fp("out_fp"),"\n   Summary motif results\n");
//	fprintf(arg_get_fp("out_fp"),"   =====================\n");

	met_dump_motifs_res(met_res_tbl->real,N->name,vec);
	//time_measure_stop(arg_get_rt("real_net_time"));
	//if(arg_get_int("quiet_mode")==FALSE)
	//	dump_time_measure(stdout, "Real network processing runtime was:", arg_get_rt("real_net_time"));

//	return rc;
}

/* Numerical Recipes algorithms */


int metrop(double de, double t)
{
	double bolzman,rnd;
	static long gljdum=1;
	float frnd;

	bolzman=exp(-de/t);
	rnd=get_rand_double();
	if (de<0.0)
		return(1);
	if ((-(de/t))<-10000.0)
		return(0);
	else
		return(rnd<bolzman);

//	return de < 0.0 || rnd < bolzman;
}

double energy(int target[14],int current[14])
/* computes the energy as sigma(i=1:13){(target[i]-current[i]})/0.5(target[i]+current[i])}*/
{
	register int i;
	double result=0.0;
	double mone,mechane,sm,df;

	for (i=1;i<=13;i++)
	{
		sm=(double)(target[i]+current[i]);
		if (sm!=0)
		{
			df=(double)(abs(target[i]-current[i]));
			
			result+=df/sm;
			
			//printf("%lf\t",result);
			//result+=(target[i]-current[i])*(target[i]-current[i]);
		}
	}
	return(result);

}

void update(int target[14],int minus[14],int plus[14],int fwd)
{
	register int i;

	for (i=1;i<=13;i++)
	{
		if (fwd)
			target[i]=target[i]-minus[i]+plus[i];
		else
			target[i]=target[i]+minus[i]-plus[i];
	
	}
}

void output13(int vec[14],FILE *fp)
{
	register int i;
	
	//fprintf(fp,"triadic census : ");
	for (i=1;i<=13;i++)
	{
		fprintf(fp,"%d ",vec[i]);
	//	printf("%d ",vec[i]);
	}
	fprintf(fp,"\n");
	//printf("\n");
}
