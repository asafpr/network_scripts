#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include "common.h"
#include "network.h"

#define BITINBYTE 8

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	the routine indicates whether the 'current' color inludes the basic 'expected' color 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int color_is_suitable (int	current, int expected) 
{
	if (!expected)
		return (current > 0);

	return ((current >> (expected-1)) & 1);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void dump_network (FILE *fp,Network *N)
{
	network_dump (fp, N);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// duplicate_network was moved to network_duplicate. it is retained only for compatibility considerations.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int duplicate_network(Network *SRC, Network **TRG_p, char *trg_name)
{
	network_duplicate (SRC, TRG_p, trg_name, 0);

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// this routine adds an edge. its purpose is to enable having an input file composed of several uni-color
// networks and this routine integrates the colors of the uni-directional edges.
// the routine maintains a list of edges where the key value is the standard linearization of a matrix.
//	if the edge is found with key value key its color is added there
//	otherwise the edge is inserted with key value = 'key'.
//	arguments:
//	list *	e_list	-	input edge list
//	int	key1			-	main possible value of edge
//	int	key2			-	alternative value of edge
//	Edge *e				-	the edge to be added
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void edge_color_add(list *e_list, int key, Edge *e)
{
	list_item *l_e;
	int	color;
	Edge	*found;

	l_e = list_get(e_list, key);

	if (l_e) {
		found = (Edge*)l_e->p;
		found->color += e->color;
		myfree(e);
	} else {
		list_insert(e_list, key, (void*)e);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	dump edges of a network
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void edge_dump (FILE *fp, Network *N, char *msg)
{
	int	i;
	int	edges_num=N->edges_num;
	Edge	*e;
	char*	prog="edge_dump";

//	dump edges
	if(edges_num>0) {
		fprintf (fp, "edges %s\n", msg);
		for(i=1;i<=edges_num;i++) {
			e = N->e_arr + i;
			fprintf(fp,"%d->%d (%d) (%p,%p)\n", e->s, e->t, e->color, e->profile, e, e->reverse);
		}
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// get a pointer to an edge that leads from 'from' to 'to'. return NULL if none exists
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Edge * edge_get (Network *N, int from, int to)
{
	int	i;

#if	DEBUG_TRACE > 5
	printf("edge_get: entered with network '%s' edge %d->%d Mat=%d\n", N->name, from, to, MatGet(N->mat, from, to));
#endif

	if (!MatGet(N->mat, from, to))
		return NULL;

	for(i=1; i<=N->edges_num;i++)
		if (N->e_arr[i].s == from && N->e_arr[i].t == to)
			return N->e_arr+i;

	return NULL;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// classify edges according to their profile
// for two colors the profiles are:
// (0,1) (0,2) (0,3) (1,0) (1,1) (1,2) (1,3) (2,0) (2,1) (2,2) (2,3) (3,0) (3,1) (3,2) (3,3)
//   1     2     3     4     5     6     7     8     9     10    11    12    13    14    15
// for degrees (i,j) the profile is p=i*PCOLORS+j . for profile p the degrees are i=p/PCOLORS and j=p%PCOLORS
// note that if an edge has an opposite edge then both of them are classified to profiles. If the two colors are different
// then the two edges are classified to antisymetric profiles. if the two colors are the same then both edges are
// classified to the same profile. this scheme is appropriate for generating random graphs that retain edge profiles.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void edge_profile_classify(Network *N)
{
	int	i, j;	//	indices in arrays
	int	s;		//	source vertex
	int	t;		//	target vertex
	int	c;		//	color of edge
	int	C;		//	color of opposite edge
	int	hi;	// higest color of the edge and its revers
	int	lo;	// lowest color of the edge and its revers
	Edge	*e;
	int	p;		//	profile
	int	pcolors = (int)pow(2,N->colors);
	char	*prog = "edge_profile_classify";

#if	DEBUG_TRACE > 10
	printf("%s: entered\n", prog);
#endif

// initializations
	if (!PROFILES)
		return;
	for (i=0; i<PROFILES; i++)
		N->profs[i]=0;

// loop on edges to classify them into profiles

	for (i=1; i<=N->edges_num; i++) {

		e = N->e_arr+i;

	//	get the details of the edge
		s = e->s;
		t = e->t;
		c = e->color;

	// get the color of the opposite edge
		C = MatGet(N->mat,t,s);

	// calculate p - the profile # for the pair (c, C).
	//	it is a simple lineartization of a two dimenstional matrix.
		p = c * pcolors + C;

	// insert 'e' into the appropriate profile & increment the # of edges that have the profile
		(N->edgs[p])[N->profs[p]++] = e;

	// set 'e' to have profile p
		e->profile = p;

#if	DEBUG_TRACE > 10
	printf("%s: edge %d %d->%d has: color=%d reverse-color=%d profile=%d address %p\n",
	 prog, i, s, t, c, C, p, e);
#endif
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	function to figure whether two edges are switchable and switch them if permitted & required
// N		network
//	edg1	first edge
//	edg2	second edge
//	act	if true - switch when possible, if false - do not switch just report whether switching is possible
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// edge switching goes as follows: the switch should result with 
//		new profile(s1,t1) = previous profile(s1,t2)
//		new profile(s1,t2) = previous profile(s1,t1)
//		new profile(s2,t2) = previous profile(s2,t1)
//		new profile(s2,t1) = previous profile(s2,t2)
// such a transformation retains, by definition, the distribution of edge profiles. however,it also needs to retain the 
// 'degrees' of all vertices. it is obvious that the 'degrees' of s1 and of s2 are retained so all that remains to
// arrange is that the 'degrees' of t1 and t2 are retained. for that it is necessary that
// 	{new profile(s1,t1), new profile(s2,t1)} = {previous profile(s1,t1), previous profile(s2,t1)}
//		{new profile(s1,t2), new profile(s2,t2)} = {previous profile(s1,t2), previous profile(s2,t2)}
// from the switch results we know that
// 	{new profile(s1,t1), new profile(s2,t1)} = {previous profile(s1,t2), previous profile(s2,t2)}
//		{new profile(s1,t2), new profile(s2,t2)} = {previous profile(s1,t1), previous profile(s2,t1)}
// so the switchability requirement is 
// 	{previous profile(s1,t1), previous profile(s2,t1)} = {previous profile(s1,t2), previous profile(s2,t2)}
//		{previous profile(s1,t2), previous profile(s2,t2)} = {previous profile(s1,t1), previous profile(s2,t1)}
// note that the two equations are identical so we need to fulfill only one.
// this is fulfilled if either (a) or (b) holds
// (a) previous profile(s1,t1) = previous profile(s2,t2) & previous profile(s2,t1) = previous profile(s1,t2)
// (b) previous profile(s1,t1) = previous profile(s1,t2) & previous profile(s2,t1) = previous profile(s2,t2)
//
// for (a) to be fulfilled, the first part is required by the program that calls edge_switch_if_can. 
//    the second part is equivalent to 
//		previous color(s2,t1) = previous color(s1,t2) && previous color(t1,s2) = previous color(t2,s1)
// as to (b), this is of no interest to us as in this case the switch does not make any change in the graph.

//
//	s1 =====> t1
//    \   -/|
//     \  /
//      \/
//      /\
//     /  \
//    /   _\|
// s2 =====> t2
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int edge_switch_if_can (Network * N, Edge *edges1t1, Edge *edges2t2, int act) 
{
	int	s1,s2,t1,t2;
	int	cs1t1;
	int	cs1t2;
	int	cs2t1;
	int	cs2t2;
	list_item *li_s1t1;
	list_item *li_s1t2;
	list_item *li_s2t1;
	list_item *li_s2t2;
	Edge	*edget1s1, *edget2s2;
	Edge	*edges1t2, *edges2t1, *edget1s2, *edget2s1;
	char*	prog="edge_switch_if_can";

#if	DEBUG_TRACE > 3
	printf("%s: entered '%s', %d->%d, %d->%d to %s\n",
	prog, N->name, edges1t1->s, edges1t1->t, edges2t2->s, edges2t2->t, act ? "act" : "inform");
#endif

	if (!edges1t1 || !edges2t2) 
		return FALSE;

	edget1s1 = edges1t1->reverse;
	edget2s2 = edges2t2->reverse;

	s1=edges1t1->s;
	t1=edges1t1->t;
	s2=edges2t2->s;
	t2=edges2t2->t;

	if (s1==s2 || s1==t2 || t1==s2 || t1==t2) 
		return FALSE;

	// there are several requirements here. the first requirement is performed by the calling program and can be commented.
	if ( edges1t1->profile != edges2t2->profile)
		return FALSE;

	//	figure the crossing edges (these are also invloved in the switching but might be null)
	edges1t2 = edge_get (N, s1, t2);
	edges2t1 = edge_get (N, s2, t1);
	edget1s2 = (edges2t1 ? edges2t1->reverse : edge_get (N, t1, s2));
	edget2s1 = (edges1t2 ? edges1t2->reverse : edge_get (N, t2, s1));

	// check that the cross edges have the same profile (including the situation that they are null)
	if (edges1t2 && edges2t1)
		if ( edges1t2->profile != edges2t1->profile)
			return FALSE;
	if ((edges1t2 && !edges2t1) || (!edges1t2 && edges2t1))
		return FALSE;
	if (!edges1t2 && !edges2t1) {
		if (edget1s2 && edget2s1)
			if (edget1s2->profile != edget2s1->profile)
				return FALSE;
		if ((edget1s2 && !edget2s1) || (!edget1s2 && edget2s1))
			return FALSE;
	}
		
	// now we know that the edges are switchable. we now need to actually switch edges.
	//	since the essence of the switchability test is that switching is permitted only for vertices that 
	//	have the same profile, in the case of sparse structure
	//	it suffices to change the vertices of the edges via the 'edge_switch' routine.

	if (act) {

		//	switch edges in the e_arr structure
		edges1t1->t=t2;
		edges2t2->t=t1;
		if (edget1s1) edget1s1->s = t2;
		if (edget2s2) edget2s2->s = t1;
		if (edges1t2) edges1t2->t = t1;
		if (edget2s1) edget2s1->s = t1;
		if (edges2t1) edges2t1->t = t2;
		if (edget1s2) edget1s2->s = t2;

		// switch edges in the mat structure
		if (N->mat->type == FULL) {
			//	switch edges in the mat structure
			MatAsgn (N->mat, s1, t1, edges1t2 ? edges1t2->color : 0);
			MatAsgn (N->mat, s1, t2, edges1t1->color);
			MatAsgn (N->mat, s2, t1, edges2t2->color);
			MatAsgn (N->mat, s2, t2, edges2t1 ? edges2t1->color : 0);
			MatAsgn (N->mat, t1, s1, edget2s1 ? edget2s1->color : 0);
			MatAsgn (N->mat, t2, s1, edget1s1 ? edget1s1->color : 0);
			MatAsgn (N->mat, t1, s2, edget2s2 ? edget2s2->color : 0);
			MatAsgn (N->mat, t2, s2, edget1s2 ? edget1s2->color : 0);
		} else {
			//	switch edges in the sparse structure - this is much more frequent then the FULL case
			edge_switch_target (N, s1, t1, t2, 0);
			edge_switch_target (N, s2, t2, t1, 0);
			if (edget1s1 || edget2s1) edge_switch_source (N, s1, t1, t2, 0);
			if (edget1s2 || edget2s2) edge_switch_source (N, s2, t2, t1, 0);
		}

	}

#if	DEBUG_TRACE > 3
	printf("%s: the required edges %s\n", prog, act ? "were switched" : "are switchable");
#endif

	return TRUE;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	this is a procedure for quick-switching of edges in a sparse matrix.
//	it changes the edge s<-told to be s<-tnew.
// note that the operation is limited to sparse matrices
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void edge_switch_source (Network *N, int s, int told, int tnew, int dbg)
{
	list_item *itold, *itnew;
	SparseMatrix * spr;
	int *	tmp;
	char*	prog="edge_switch_source";

#if	DEBUG_TRACE > 3
	printf("%s: entered '%s', switch %d<-%d to %d<-%d\n",	prog, N->name, s, told, s, tnew);
#endif

//	validate input arguments

	if (told == tnew) return;
	if ( told <= 0 || tnew <= 0 || s <= 0 || told > N->vertices_num || tnew > N->vertices_num || s > N->vertices_num) {
		printf("%s error: illegal values. switching request was ignored\n", prog);
		return;
	}

	if (!N) {
		printf ("%s error: null network. switching request was ignored\n", prog);
		return;
	}
	if (N->mat->type != SPARSE) {
		printf ("%s error: network not sparse. switching request was ignored\n", prog);
		return;
	}

	spr = N->mat->spr;

	if (dbg) {
		printf("%s: entered '%s', switch %d<-%d to %d<-%d\n",	prog, N->name, s, told, s, tnew);
		printf("before switching\n");
		printf ("arcs outgoing from s=%d\n", s);			list_dump (stdout, spr->m[s].to);
		printf ("arcs incoming into s=%d\n", s);			list_dump (stdout, spr->m[s].from);
		printf ("arcs outgoing from told=%d\n",told);	list_dump (stdout, spr->m[told].to);
		printf ("arcs incoming into told=%d\n",told);	list_dump (stdout, spr->m[told].from);
		printf ("arcs outgoing from tnew=%d\n",tnew);	list_dump (stdout, spr->m[tnew].to);
		printf ("arcs incoming into tnew=%d\n",tnew);	list_dump (stdout, spr->m[tnew].from);
	}

// the requirement is to perform the following:
// 1. if both edges exist then 
//		a. exchange the .p of m[s].to{x}   and m[s].to{y} 	and
// 	b. exchange the .p of m[x].from{s} and m[y].from{s}
//	2. if only one edge exist then
//		a. exchange the .val of m[s].to   of the existing edge to point to the other vertex
//		b. exchange the .val of m[s].from of the existing edge to point to the other vertex

	// replace in the 'from' list

	itold = list_get (spr->m[s].from, told);
	itnew = list_get (spr->m[s].from, tnew);
	if (itold && itnew) {
		tmp = itold->p;
		itold->p = itnew->p;
		itnew->p = tmp;
	} else if (itold && !itnew) {
		list_item_rmv (spr->m[s].from, itold);
		itold->val=tnew;
		list_item_ins (spr->m[s].from, itold);
	} else if (!itold && itnew) {
		list_item_rmv (spr->m[s].from, itnew);
		itnew->val=told;
		list_item_ins (spr->m[s].from, itnew);
	} else {
		printf ("%s: network '%s' illegal situation - requested to switch two null arcs %d<-%d to %d<-%d\n",
		prog, N->name, s, told, s, tnew);
	}


	// replace in the to list
	itold = list_get (spr->m[told].to, s);
	itnew = list_get (spr->m[tnew].to, s);
	if (itold && itnew) {
		tmp = itold->p;
		itold->p = itnew->p;
		itnew->p = tmp;
	} else if (itold && !itnew) {
		list_item_rmv (spr->m[told].to, itold);
		list_item_ins (spr->m[tnew].to, itold);
	} else if (!itold && itnew) {
		list_item_rmv (spr->m[tnew].to, itnew);
		list_item_ins (spr->m[told].to, itnew);
	} else {
		printf ("%s: network '%s' illegal situation - requested to switch two null arcs %d->%d to %d->%d\n",
		prog, N->name, told, s, tnew, s);
	}

	if (dbg) {
		printf("after switching\n");
		printf ("arcs outgoing from s=%d\n",s);			list_dump (stdout, spr->m[s].to);
		printf ("arcs incoming into s=%d\n",s);			list_dump (stdout, spr->m[s].from);
		printf ("arcs outgoing from told=%d\n",told);	list_dump (stdout, spr->m[told].to);
		printf ("arcs incoming into told=%d\n",told);	list_dump (stdout, spr->m[told].from);
		printf ("arcs outgoing from tnew=%d\n",tnew);	list_dump (stdout, spr->m[tnew].to);
		printf ("arcs incoming into tnew=%d\n",tnew);	list_dump (stdout, spr->m[tnew].from);
	}

#if	DEBUG_TRACE > 5
	printf("%s: terminated\n", prog);
#endif

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	this is a procedure for quick-switching of edges in a sparse matrix.
//	it changes the edge s->told to be s->tnew.
// note that the operation is limited to sparse matrices
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void edge_switch_target (Network *N, int s, int told, int tnew, int dbg)
{
	list_item *itold, *itnew;
	SparseMatrix * spr;
	int *	tmp;
	char*	prog="edge_switch_target";

#if	DEBUG_TRACE > 3
	printf("%s: entered '%s', switch %d->%d to %d->%d\n",	prog, N->name, s, told, s, tnew);
#endif

//	validate input arguments

	if (told == tnew) return;
	if ( told <= 0 || tnew <= 0 || s <= 0 || told > N->vertices_num || tnew > N->vertices_num || s > N->vertices_num) {
		printf("%s error: illegal values. switching request was ignored\n", prog);
		return;
	}

	if (!N) {
		printf ("%s error: null network. switching request was ignored\n", prog);
		return;
	}
	if (N->mat->type != SPARSE) {
		printf ("%s error: network not sparse. switching request was ignored\n", prog);
		return;
	}

	spr = N->mat->spr;

	if (dbg) {
		printf("%s: entered '%s', switch %d->%d to %d->%d\n",	prog, N->name, s, told, s, tnew);
		printf("before switching\n");
		printf ("arcs outgoing from s=%d\n",s);			list_dump (stdout, spr->m[s].to);
		printf ("arcs incoming into s=%d\n",s);			list_dump (stdout, spr->m[s].from);
		printf ("arcs outgoing from told=%d\n",told);	list_dump (stdout, spr->m[told].to);
		printf ("arcs incoming into told=%d\n",told);	list_dump (stdout, spr->m[told].from);
		printf ("arcs outgoing from tnew=%d\n",tnew);	list_dump (stdout, spr->m[tnew].to);
		printf ("arcs incoming into tnew=%d\n",tnew);	list_dump (stdout, spr->m[tnew].from);
	}

// the requirement is to perform the following:
// 1. if both edges exist then 
//		a. exchange the .p of m[s].to{x}   and m[s].to{y} 	and
// 	b. exchange the .p of m[x].from{s} and m[y].from{s}
//	2. if only one edge exist then
//		a. exchange the .val of m[s].to   of the existing edge to point to the other vertex
//		b. exchange the .val of m[s].from of the existing edge to point to the other vertex

	// replace in the 'to' list

	itold = list_get (spr->m[s].to, told);
	itnew = list_get (spr->m[s].to, tnew);
	if (itold && itnew) {
		tmp = itold->p;
		itold->p = itnew->p;
		itnew->p = tmp;
	} else if (itold && !itnew) {
		list_item_rmv (spr->m[s].to, itold);
		itold->val=tnew;
		list_item_ins (spr->m[s].to, itold);
	} else if (!itold && itnew) {
		list_item_rmv (spr->m[s].to, itnew);
		itnew->val=told;
		list_item_ins (spr->m[s].to, itnew);
	} else {
		printf ("%s: network '%s' illegal situation - requested to switch two null arcs %d->%d (%p) to %d->%d (%p)\n",
		prog, N->name, s, told, s, tnew, itold, itnew);
	}

	// replace in the 'from' list
	itold = list_get (spr->m[told].from, s);
	itnew = list_get (spr->m[tnew].from, s);
	if (itold && itnew) {
		tmp = itold->p;
		itold->p = itnew->p;
		itnew->p = tmp;
	} else if (itold && !itnew) {
		list_item_rmv (spr->m[told].from, itold);
		list_item_ins (spr->m[tnew].from, itold);
	} else if (!itold && itnew) {
		list_item_rmv (spr->m[tnew].from, itnew);
		list_item_ins (spr->m[told].from, itnew);
	} else {
		printf ("%s: network '%s' illegal situation - requested to switch two null arcs %d<-%d (%p) to %d<-%d (%p)\n",
		prog, N->name, s, told, s, tnew, itold, itnew);
	}

	if (dbg) {
		printf("after switching\n");
		printf ("arcs outgoing from s=%d\n",s);			list_dump (stdout, spr->m[s].to);
		printf ("arcs incoming into s=%d\n",s);			list_dump (stdout, spr->m[s].from);
		printf ("arcs outgoing from told=%d\n",told);	list_dump (stdout, spr->m[told].to);
		printf ("arcs incoming into told=%d\n",told);	list_dump (stdout, spr->m[told].from);
		printf ("arcs outgoing from tnew=%d\n",tnew);	list_dump (stdout, spr->m[tnew].to);
		printf ("arcs incoming into tnew=%d\n",tnew);	list_dump (stdout, spr->m[tnew].from);
	}

#if	DEBUG_TRACE > 5
	printf("%s: terminated\n", prog);
#endif

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// free Network structure related allocated memory
// does not free the netowk structure itself. see network_free for that,
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void free_network_mem(Network *N)
{
	int	i;
	char	*prog = "free_network_mem";

#if	DEBUG_TRACE > 4
	printf("%s: entered to free network '%s'\n", prog, N->name);
#endif

	if(N) {
		if(N->mat){
			MatFree(N->mat);
			myfree(N->mat);
		}
		if(N->e_arr)
			myfree(N->e_arr);
		//if(N->name!=NULL)
			//free(N->name);
		if(N->indeg)
			myfree(N->indeg);
		if(N->outdeg)
			myfree(N->outdeg);
		if(N->edgs){
			for (i=0; i<PROFILES; i++)
				if (N->edgs[i] != NULL)
					myfree(N->edgs[i]);
			myfree(N->edgs);
		}
		if(N->profs)
			myfree(N->profs);

		if (N->vrt_name){
			for(i=1; i<=N->vertices_num; i++)
				myfree (N->vrt_name[i]);
			myfree(N->vrt_name);
		}
	}

#if	DEBUG_TRACE > 4
	printf("%s: returned\n", prog);
#endif
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	checking network consistency and validity.
//	this is mainly intended to be used in the stages of testing the program.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int network_check (FILE *fp, Network *N)
{
	int	i, j;
	int	OK = TRUE;
	SparseMatrix *spr;
	list_item *from, *to;
	int	s,t,c;
	int	found;
	Edge	*e, *er;
	int	pcolors;
	char	*prog = "network_check";

#if	DEBUG_TRACE > 3
	printf("%s: entered to check network '%s'\n", prog, N->name);
#endif

	if (!N)
		return;

	pcolors = (int)pow(2,N->colors);

// check that edges have legal values
	if(N->edges_num>0) {
		for(i=1;i<=N->edges_num;i++) {
			e = N->e_arr + i;
			if (e->s <= 0 && e->s > N->vertices_num) {
				fprintf (fp,"%s '%s', edge %d, illegal s=%d\n", prog, N->name, i, e->s);
				OK = FALSE;
			}
			if (e->t <= 0 && e->t > N->vertices_num) {
				fprintf (fp,"%s '%s', edge %d, illegal t=%d\n", prog, N->name, i, e->t);
				OK = FALSE;
			}
			if (e->color <= 0 && e->color > N->colors) {
				fprintf (fp,"%s '%s', edge %d, illegal color=%d\n", prog, N->name, i, e->color);
				OK = FALSE;
			}
			if (er = e->reverse) {
				if (e->s != er->t || e->t != er->s) {
					fprintf (fp,"%s '%s', edge %d, illegal reverse\n", prog, N->name, i);
					OK = FALSE;
				}
				if (e->reverse->reverse != e) {
					fprintf (fp,"%s '%s', edge %d has a reverse that does not reverse to self\n", prog, N->name, i);
					OK = FALSE;
				}
			} else if (er = edge_get (N, e->t, e->s)) {
				fprintf (fp,"%s '%s', edge %d, has an error: should have a reverse\n", prog, N->name, i);
				OK = FALSE;
			}
			if (profile_out (e->profile, pcolors) != e->color) {
				fprintf (fp,"%s '%s', edge %d, has an error: out_profile=%d and color=%d\n", 
				prog, N->name, i, profile_out (e->profile, pcolors), e->color);
				OK = FALSE;
			}
			if ((profile_in (e->profile, pcolors) && !e->reverse) || (!profile_in (e->profile, pcolors) && e->reverse)) {
				fprintf (fp,"%s '%s', edge %d. inconsitency between profile (in=%d) and reverse %p\n", 
				prog, N->name, i, profile_in (e->profile, pcolors), e->reverse);
				OK = FALSE;
			}
			if (profile_in (e->profile, pcolors) && e->reverse)
				if (profile_in (e->profile, pcolors) != e->reverse->color) {
					fprintf (fp,"%s '%s', edge %d. inconsitency between profile (in=%d) and reverse color (%d)\n",
					prog, N->name, i, profile_in (e->profile, pcolors), e->reverse->color);
					OK = FALSE;
				}
		}
	}

// check that all edges appear in the matrix
	if(N->edges_num>0) {
		for(i=1;i<=N->edges_num;i++) {
			e = N->e_arr + i;
			if (!MatGet (N->mat, e->s, e->t)) {
				fprintf (fp,"%s '%s': edge %d (%d->%d) does not appear in the matrix\n", prog, N->name, i, e->s, e->t);
				OK = FALSE;
			}
		}
	}

// for a sparse matrix check that all entries in the matrix appear in the edges array
	if (N->mat) {
		if (N->mat->type == SPARSE) {
			spr = N->mat->spr;
			for (i=1; i<=spr->size; i++) {
				if (spr->m[i].from) 
					for (from=spr->m[i].from->l; from; from=from->next) {
						s = from->val;
						t = i;
						c = *((int*)(from->p));
						found = FALSE;
						for (j=1; j<=N->edges_num; j++) {
							if (N->e_arr[j].s == s && N->e_arr[j].t == t) {
								found = TRUE;
								if (N->e_arr[j].color != c) {
									fprintf (fp,"%s '%s': edge %d (%d->%d) has color %d in edges and %d in matrix\n",
									prog, N->name, j, s, t, N->e_arr[j].color, c);
									OK = FALSE;
								}
							}
						}
						if (!found) {
							fprintf (fp,"%s '%s': edge %d->%d in sparse matrix does not appear in edge list\n",
							prog, N->name, s, t);
							OK = FALSE;
						}
					}
				if (spr->m[i].to) 
					for (to=spr->m[i].to->l; to; to=to->next) {
						s = i;
						t = to->val;
						c = *((int*)(to->p));
						found = FALSE;
						for (j=1; j<=N->edges_num; j++) {
							if (N->e_arr[j].s == s && N->e_arr[j].t == t) {
								found = TRUE;
								if (N->e_arr[j].color != c) {
									fprintf (fp,"%s '%s': edge %d (%d->%d) has color %d in edges and %d in matrix\n",
									prog, N->name, j, s, t, N->e_arr[j].color, c);
									OK = FALSE;
								}
							}
						}
						if (!found) {
							fprintf (fp,"%s '%s': edge %d->%d in sparse matrix does not appear in edge list\n",
							prog, N->name, s, t);
							OK = FALSE;
						}
					}
			}
		}
	}

//	check matrix
	if (N->mat == NULL) {
		fprintf (fp,"%s '%s' : null mat\n", prog, N->name); 
		OK = FALSE;
	}	else {
		OK = OK && mat_check (N->mat, N->vertices_num, N->edges_num);
	}

// check Profiles
	if (PROFILES) {
		for (i=0; i<PROFILES; i++)
			if (N->edgs[i]) 
				for (j=0; j<N->profs[i]; j++) {
					e = (N->edgs[i])[j];
					if (e->s <=0 || e->s > N->vertices_num) {
						fprintf (fp,"%s '%s' : Profile %d element %d has illegal source %d\n", prog, N->name, i, j, e->s); 
						OK = FALSE;
					}
					if (e->t <=0 || e->t > N->vertices_num) {
						fprintf (fp,"%s '%s' : Profile %d element %d has illegal source %d\n", prog, N->name, i, j, e->t); 
						OK = FALSE;
					}
					if (e->color <=0 || e->color >= pcolors) {
						fprintf (fp,"%s '%s' : Profile %d element %d has illegal color %d\n", prog, N->name, i, j, e->color); 
						OK = FALSE;
					}
				}
	}

//	handle vertex names - should be added here

#if	DEBUG_TRACE > 3
	printf("%s:  network '%s' is OK\n", prog, N->name);
#endif

	return OK;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	find the difference between two networks
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void network_compare (FILE *fp, Network *N1, Network *N2)
{
	int	i,j,k;
	int	vertices, size, edges_num;
	list_item	*li1, *li2;
	Matrix *M1, *M2;
	SparseMatrix *S1, *S2;
	Edge	*e1, *e2, *e1r, *e2r;
	Edge	**edgs1, **edgs2;
	int	profs1, profs2;
	char*	prog="network_compare";

	if (N1 == N2)
		return;

	if (!N1) {
		fprintf (fp, "%s: network 1 is null\n", prog);
		return;
	}

	if (!N2) {
		fprintf (fp, "%s: network 2 is null\n", prog);
		return;
	}

#if	DEBUG_TRACE > 0
	printf("%s: entered, to compare networks %s and %s\n", prog, N1->name, N2->name);
#endif

	if (N1->name != N2->name)
		fprintf (fp, "%s: name difference network-1='%s' network-2='%s'\n", prog, N1->name, N2->name);

	if (N1->vertices_num != N2->vertices_num)
		fprintf (fp, "%s: vertices_num difference network-1=%d network-2=%d\n", prog, N1->vertices_num, N2->vertices_num);

	if (N1->edges_num != N2->edges_num)
		fprintf (fp, "%s: edges_num difference network-1=%d network-2=%d\n", prog, N1->edges_num, N2->edges_num);

	if (N1->con_vertices_num != N2->con_vertices_num)
		fprintf (fp, "%s: edcon_verticesge_num difference network-1=%d network-2=%d\n", 
		prog, N1->con_vertices_num, N2->con_vertices_num);

	if (N1->colors != N2->colors)
		fprintf (fp, "%s: color difference network-1=%d network-2=%d\n", prog, N1->colors, N2->colors);

// comparing the 'mat' structure
	if (N1->mat->type != N2->mat->type) {
		fprintf (fp, "%s: mat->type difference network-1=%d network-2=%d\n", prog, N1->mat->type, N2->mat->type);
	} else {
		switch (N1->mat->type) {
		case FULL:
			M1 = N1->mat->full;
			M2 = N2->mat->full;
			if (M1->size != M2->size) {
				fprintf (fp, "%s: full matrices have different size network-1=%d network-2=%d\n", prog, M1->size, M2->size);
			} else {
				for (i=1; i<=M1->size; i++) {
					for (j=1; j<=M1->size; j++) 
						if (MTRX(M1,i,j) != MTRX(M2,i,j)) 
							fprintf (fp,"%s: i=%d, j=%d, M1=%d, M2=%d ",prog, i, j, MTRX(M1,i,j), MTRX(M2,i,j));
				}
			}
			break;
		case SPARSE:
			S1 = N1->mat->spr;
			S2 = N2->mat->spr;
			if (S1->size != S2->size) {
				fprintf (fp, "%s: sparse matrices have different size network-1=%d network-2=%d\n", prog, S1->size, S2->size);
			} else if (N1->vertices_num != N2->vertices_num) {
				fprintf (fp, "%s: sparse matrices have different # of edges network-1=%d network-2=%d\n", 
				prog, N1->vertices_num, N2->vertices_num);
			} else if (N1->vertices_num == N2->vertices_num) {
				vertices = N1->vertices_num;
				for (i=1; i<=vertices; i++) {
					if ((S1->m[i].to && !S2->m[i].to) || (S2->m[i].to && !S1->m[i].to))
						fprintf (fp, "%s: sparse matrices have different 'to' for edge %d: network-1=%p network-2=%p\n", 
						prog, i, S1->m[i].to, S2->m[i].to);
					if (S1->m[i].to && S2->m[i].to) {
						if (S1->m[i].to->size != S2->m[i].to->size) {
							fprintf (fp, "%s: sparse matrices have different 'to' size for edge %d: network-1=%d network-2=%d\n", 
							prog, i, S1->m[i].to->size, S2->m[i].to->size);
						} else {
							li1 = S1->m[i].to->l;
							li2 = S2->m[i].to->l;
							while (li1 || li2) {
								if (li1 && !li2) {
									fprintf (fp, "%s: sparse matrices difference in 'to': ", prog);
									fprintf (fp, "network-1=(%d->%d) does not appear in network-2\n", i, li1->val);
									li1=li1->next;
								} else if (!li1 && li2) {
									fprintf (fp, "%s: sparse matrices difference in 'to': ", prog);
									fprintf (fp, "network-2=(%d->%d) does not appear in network-1\n", i, li2->val);
									li2=li2->next;
								} else if (li1->val == li2->val) {
									li1=li1->next;
									li2=li2->next;
								} else if (li1->val < li2->val) {
									fprintf (fp, "%s: sparse matrices difference in 'to': ", prog);
									fprintf (fp, "network-1=(%d->%d) does not appear in network-2\n", i, li1->val);
									li1=li1->next;
								} else if (li1->val > li2->val) {
									fprintf (fp, "%s: sparse matrices difference in 'to': ", prog);
									fprintf (fp, "network-2=(%d->%d) does not appear in network-1\n", i, li2->val);
									li2=li2->next;
								}
//								if (*(int*)li1->p != *(int*)li2->p)
//									fprintf (fp, "%s: sparse matrices difference in 'to': ", prog);
//									fprintf (fp, "edge i=%d, j=%d: network-1=%d network-2=%d\n", i, j, *(int*)li1->p, *(int*)li2->p);
							}
						}
					}
					if ((S1->m[i].from && !S2->m[i].from) || (S2->m[i].from && !S1->m[i].from))
						fprintf (fp, "%s: sparse matrices have different 'from' for edge %d: network-1=%p network-2=%p\n", 
						prog, i, S1->m[i].from, S2->m[i].from);
					if (S1->m[i].from && S2->m[i].from) {
						if (S1->m[i].from->size != S2->m[i].from->size) {
							fprintf (fp, "%s: sparse matrices have different 'from' size for edge %d: network-1=%d network-2=%d\n", 
							prog, i, S1->m[i].from->size, S2->m[i].from->size);
						} else {
							li1 = S1->m[i].from->l;
							li2 = S2->m[i].from->l;
							while (li1 || li2) {
								if (li1 && !li2) {
									fprintf (fp, "%s: sparse matrices difference in 'from': ", prog);
									fprintf (fp, "network-1=(%d->%d) does not appear in network-2\n", li1->val, i);
									li1=li1->next;
								} else if (!li1 && li2) {
									fprintf (fp, "%s: sparse matrices difference in 'from': ", prog);
									fprintf (fp, "network-2=(%d->%d) does not appear in network-1\n", li2->val, i);
									li2=li2->next;
								} else if (li1->val == li2->val) {
									li1=li1->next;
									li2=li2->next;
								} else if (li1->val < li2->val) {
									fprintf (fp, "%s: sparse matrices difference in 'from': ", prog);
									fprintf (fp, "network-1=(%d->%d) does not appear in network-2\n", li1->val, i);
									li1=li1->next;
								} else if (li1->val > li2->val) {
									fprintf (fp, "%s: sparse matrices difference in 'from': ", prog);
									fprintf (fp, "network-2=(%d->%d) does not appear in network-1\n", li2->val, i);
									li2=li2->next;
								}
//								if (*(int*)li1->p != *(int*)li2->p)
//									fprintf (fp, "%s: sparse matrices have different color in 'from': ", prog);
//									fprintf (fp, "edge i=%d, j=%d: network-1=%d network-2=%d\n", 
//									i, j, *(int*)li1->p, *(int*)li2->p);
							}
						}
					}
				}
			}
			break;
		default:
			break;
		}
	}

// comparing the Edge structure
	if ((N1->e_arr&& !N2->e_arr) || (!N1->e_arr && N2->e_arr))
		fprintf (fp, "%s: inconsistent edge array network-1=%p network-2=%p\n", prog, N1->e_arr, N2->e_arr);
	else if (N1->e_arr && N2->e_arr && N1->edges_num != N2->edges_num)
		fprintf (fp, "%s: inconsistent edge array size network-1=%d network-2=%d\n", prog, N1->edges_num, N2->edges_num);
	else if (N1->e_arr && N2->e_arr && N1->edges_num == N2->edges_num) {
		edges_num = N1->edges_num;
		for(i=1;i<=edges_num;i++) {
			e1 = N1->e_arr + i;
			e2 = N2->e_arr + i;
			if (e1->s != e2->s || e1->t != e2->t || e1->color != e2->color)
				fprintf (fp,"%s: edge %d in network-1 is (%d->%d, %d) and in network-2 is (%d->%d, %d)\n", 
				prog, i, e1->s, e1->t, e1->color, e2->s, e2->t, e2->color);
			if (e1->profile != e2->profile)
				fprintf (fp,"%s: edge %d in network-1 is in profile %d and in network-2 is profile %d\n", 
				prog, i, e1->profile, e2->profile);
			// if edges are same, check that their reverses are same
			if (e1->s == e2->s && e1->t == e2->t && e1->color == e2->color) {
				e1r=e1->reverse;
				e2r=e2->reverse;
				if ((e1r && !e2r) || (!e1r && e2r)) {
					fprintf (fp,"%s: edge %d has conflicting reverse, in network-1 is %p and in network-2 is %p\n", 
					prog, i, e1r, e2r);
				} else if (e1r && e2r){
					if (e1r->s != e2r->s || e1r->t != e2r->t || e1r->color != e2r->color)
						fprintf (fp,"%s: reverse of edge %d in network-1 is (%d->%d, %d) and in network-2 is (%d->%d, %d)\n", 
						prog, i, e1r->s, e1r->t, e1r->color, e2r->s, e2r->t, e2r->color);
					if (e1r->profile != e2r->profile)
						fprintf (fp,"%s: reverse of edge %d in network-1 is in profile %d and in network-2 is profile %d\n", 
						prog, i, e1r->profile, e2r->profile);
				}
			}
		}
	}

	if (PROFILES) {
		for (i=0; i<PROFILES; i++) {
			edgs1 = N1->edgs[i];
			edgs2 = N2->edgs[i];
			profs1 = N1->profs[i];
			profs2 = N2->profs[i];
			if (profs1 != profs2) 
				fprintf (fp,"%s: in profile %d network-1 has %d edges and network-2 has %d edges\n", 
				prog, i, profs1, profs2);
			else if ((edgs1 && !edgs2) || (!edgs1 && edgs2))
				fprintf (fp,"%s: conflicting pointers to edgs for profile %d; network-1 points to %p and network-2 to %p\n", 
				prog, i, edgs1, edgs2);
			else if (edgs1 && edgs2) {
				for (j=0; j<N1->profs[i]; j++) {
					e1 = (edgs1)[j];
					e2 = (edgs2)[j];
					if (e1->s != e2->s || e1->t != e2->t || e1->color != e2->color)
						fprintf (fp,"%s: edge profile %d in network-1 is (%d->%d, %d) and in network-2 is (%d->%d, %d)\n", 
						prog, i, e1->s, e1->t, e1->color, e2->s, e2->t, e2->color);
				}
			}
		}
	}

//	handle vertex names - should be added here

#if	DEBUG_TRACE > 0
	printf("%s: returned\n", prog);
#endif
	return;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	construct a network from its list of edges
// based on network_load
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int network_construc_from_edges (Network *N, FILE* log_fp)
{
	int   rc=RC_OK;
	int	s,t,i,j,color;
//	int	bad_color=0;
	list_item *l_e;
	int	max_node=0,cnt=1;
//	Edge	*e;
	int	self_edge_exists=FALSE;
	char	*prog = "network_construc_from_edges";

#if	DEBUG_TRACE > 0
	printf("%s: entered\n", prog);
#endif

//fill matrix (mat structure) from the list of edges established previously
	for(i=1; i<=N->edges_num; i++)
		MatAsgn(N->mat,N->e_arr[i].s,N->e_arr[i].t,N->e_arr[i].color);

//check there are no Self edges- if there are any then inform and stop
	for(i=1; i<=N->vertices_num; i++) {
		if(MatGet(N->mat,i,i) > 0) {
			fprintf(stdout,"Self edges exist in Input Network!\n");
			fprintf(stdout,"Self Edges : (%d,%d)\t",i,i);
			self_edge_exists=TRUE;
		}
	}
	if(self_edge_exists==TRUE){
		fprintf(stdout,"\nprogram aborts due to Self edges in Network '%s'!\n", N->name);
		exit(-1);
	}

	N->con_vertices_num=0;

#ifndef NODEG
	//allocate indeg and out deg arrays
	N->indeg=(int*)mycalloc(N->vertices_num+1,sizeof(int));
	N->outdeg=(int*)mycalloc(N->vertices_num+1,sizeof(int));
#endif

// handle profiling of edges

//set reverse edge for every edge
	for(i=1;i<=N->edges_num;i++)
			N->e_arr[i].reverse = edge_get(N, N->e_arr[i].t, N->e_arr[i].s);	

//Calculate profiles of edges
	edge_profile_classify(N);

	if(N->mat->type == FULL) {
#ifndef NODEG
		//fill in deg and out deg arrays
		for(i=1;i<=N->vertices_num;i++) {
			N->indeg[i]=0;
			N->outdeg[i]=0;
		}

		for (i=1; i<=N->vertices_num;i++){
			for(j=1;j<=N->vertices_num;j++){
				N->outdeg[i]+=MatGet(N->mat,i,j);
			}
		}
		for (i=1;i<=N->vertices_num;i++){
			for(j=1;j<=N->vertices_num;j++){
				N->indeg[i]+=MatGet(N->mat,j,i);
			}
		}
#endif
	}

	//pass through matrix and fill profiles
	if(N->mat->type == SPARSE) {
#ifndef NODEG
		//fill in deg and out deg arrays
		for(i=0;i<=N->vertices_num;i++) {
			N->indeg[i]=0;
			N->outdeg[i]=0;
		}
		for (i=1; i<=N->vertices_num;i++){
			if(N->mat->spr->m[i].to==NULL)
				N->outdeg[i]=0;
			else
				N->outdeg[i]=N->mat->spr->m[i].to->size;
			if(N->mat->spr->m[i].from==NULL)
				N->indeg[i]=0;
			else
				N->indeg[i]=N->mat->spr->m[i].from->size;
		}
#endif
	}

#ifndef NODEG
	//calc total num of cellected vertices
	for(i=1; i<=N->vertices_num;i++){
		if( (N->indeg[i]!=0) || (N->outdeg[i]!=0) )
			N->con_vertices_num++;
	}
#endif

#if	DEBUG_TRACE > 3
	printf("%s: returning\n", prog);
#endif
	return rc;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	dump a network
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void network_dump (FILE *fp, Network *N)
{
	int	i,j, k;
	int	vertices=N->vertices_num;
	int	size;
	int	edges_num=N->edges_num;
	list_item	*li;
	Mat	*M = N->mat;
	SparseMatrix *S;
	Edge	*e, *er;
	Edge	**edgs;
	int	profs;
	char*	prog="network_dump";

	fprintf(fp,"network '%s' has %d vertices, %d edges and %d colors. the edges are:\n",
	N->name, N->vertices_num, N->edges_num, N->colors);

//	dump edges
	edge_dump (fp, N, "");

//	dump matrix
	switch (N->mat->type) {
	case FULL:
		fprintf(fp,"the matrix is:");
		for (i=1; i<=vertices; i++) {
			fprintf(fp,"\n");
			for (j=1; j<=vertices; j++)
				fprintf(fp,"%d ",MatGet(M,i,j));
		}
		fprintf(fp,"\n");
	case SPARSE:
		fprintf(fp,"the matrix is:");
		for (i=1; i<=vertices; i++) {
			fprintf(fp,"\n%d ", i);
			for (j=1; j<=vertices; j++)
				if (k = MatGet(M,i,j)) {
					if (!j%10)
						fprintf(fp,"\n%d ", i);
					fprintf(fp,"%d(%d) ",j, k);
				}
		}
		fprintf(fp,"\n");
		break;
	default:
		break;
	}

	if (PROFILES) {
		fprintf (fp, "edge profiles\n");
		for (i=0; i<PROFILES; i++) {
			edgs = N->edgs[i];
			profs = N->profs[i];
			if (profs && edgs) {
				for (j=0; j<profs; j++) {
					e = (edgs)[j];
					fprintf (fp, "%4d) (%d->%d, %d)\n", i, e->s, e->t, e->color);
				}
			}
		}
	}

//	handling of vertex names should be added here
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	duplicate a network
// 'network_duplicate' replaces 'duplicate_network' (the latter is retained only for compatibility considerations)
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int network_duplicate (Network *SRC, Network **TRG_p, char *trg_name, int trg_num)
{
	int i,j;
	Network *TRG;
	list_item *l_e;
	Edge	*s, *t;
	char	*prog="network_duplicate";

#if	DEBUG_TRACE > 3
	printf("%s: entered\n", prog);
#endif

	TRG = network_init(trg_name, trg_num, SRC->vertices_num, SRC->edges_num, COLORS, PROFILES);

	//FULL: TRG->m = (char*)myalloc(TRG->vertices_num*TRG->vertices_num*sizeof(char));
	//init matrix according to input network
	if(SRC->mat->type==FULL) {
		for (i=1; i<=TRG->vertices_num; i++)
			for (j=1; j<=TRG->vertices_num; j++)
				MatAsgn(TRG->mat,i,j,MatGet(SRC->mat,i,j));
	} else {
		//sparse
		for (i=1; i<=TRG->vertices_num; i++)
			for(l_e=list_get_next(SRC->mat->spr->m[i].to,NULL);l_e!=NULL;
				l_e=list_get_next(SRC->mat->spr->m[i].to,l_e))
					MatAsgn(TRG->mat,i,l_e->val,*(int*)l_e->p);
	}
	//copy edge arr from source network

	for(i=1;i<=TRG->edges_num;i++) {
		TRG->e_arr[i].s=SRC->e_arr[i].s;
		TRG->e_arr[i].t=SRC->e_arr[i].t;
		TRG->e_arr[i].color=SRC->e_arr[i].color;
	}
	//set pointer to reverse edge
	for(i=1;i<=TRG->edges_num;i++)
		TRG->e_arr[i].reverse = edge_get(TRG, TRG->e_arr[i].t, TRG->e_arr[i].s);	

	for (i=0; i<PROFILES; i++) {
		TRG->profs[i] = SRC->profs[i];
		for (j=0; j<TRG->profs[i]; j++) {
			(TRG->edgs[i])[j] = edge_get(TRG, ((SRC->edgs[i])[j])->s, ((SRC->edgs[i])[j])->t);
			((TRG->edgs[i])[j]) -> profile = i;
		}
	}

#ifndef NODEG
	TRG->indeg=(int*)mycalloc((unsigned int)TRG->vertices_num+1,sizeof(int));
	TRG->outdeg=(int*)mycalloc((unsigned int)TRG->vertices_num+1,sizeof(int));
//	for(i=1;i<=TRG->vertices_num+1;i++) {		//ss	<< wrong index, deactivated
	for(i=1;i<=TRG->vertices_num;i++) {			//ss	<<	correct
		TRG->indeg[i]=SRC->indeg[i];
		TRG->outdeg[i]=SRC->outdeg[i];
	}
#endif

//	handle vertex names
	if (SRC->vrt_name) {
		TRG->vrt_name = (char **)mycalloc(TRG->vertices_num+1, sizeof(char *));
		TRG->vrt_name[0] = NULL;
		for(i=1; i<=TRG->vertices_num; i++) {
			TRG->vrt_name[i] = (char *)myalloc(VRT_NAME_LEN+1);
			strcpy (TRG->vrt_name[i], SRC->vrt_name[i]);
		}
	}

	//network_dump(stdout, TRG);
	*TRG_p=TRG;

#if	DEBUG_TRACE > 3
	printf("%s: returned\n", prog);
#endif
	return RC_OK;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// export network in Pajek format
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void network_export_pajek (Network *N, FILE *fp)
{
	int	i;
	Edge	*s;

	if (N) {
		fprintf (fp, "*Vertices %d\n", N->vertices_num);
		for (i=1; i<N->vertices_num; i++)
			fprintf (fp, "%d %c%d%c\n", i, '"', i, '"');
		fprintf (fp, "*Arcs %d\n", N->edges_num);
		for (i=1; i<N->edges_num; i++)
			fprintf (fp, "%d %d %d\n", N->e_arr[i].s, N->e_arr[i].t, N->e_arr[i].color);
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// export network in Pajek format
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void network_export_standard (Network *N, FILE *fp)
{
	int	i;
	Edge	*s;

	if (N) {
		for (i=1; i<N->edges_num; i++)
			fprintf (fp, "%d %d %d\n", N->e_arr[i].s, N->e_arr[i].t, N->e_arr[i].color);
	}
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// free Network structure and hanging structures. see also free_network_mem
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void network_free(Network *N)
{
	if (N) {
		free_network_mem(N);
		myfree (N);
	}
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	given a network 'N' and a set of its vertices, 'vrtx_set', construct the induced sub-net 'SN'.
//	note that the generated metwork is only needed for its FULL matrix hence not all network aspects are handled
//	previously: gen_subset_matrix(Network *N, Network **SN, list *vrtx_set, int mtf_sz)
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int	network_generate_from_subset(Network *N, Network **SN, list *vrtx_set, int mtf_sz)
{
	int i,j,rc=RC_OK;
	list_item *row,*col;
	char	*prog="network_generate_from_subset";

#if	DEBUG_TRACE > 5
	printf("%s: entered mtf_sz=%d\n", prog, mtf_sz);
//	dump_spr_matrix(stdout, N->mat, "matrix when entering network_generate_from_subset");
	printf("vertex set:\n");
	list_dump (stdout, vrtx_set);
#endif

//	allocate a network and initialize it
	(*SN)=network_init("", 0, mtf_sz, 0, N->colors, 0);

//	fill the matrix 
	row=vrtx_set->l;
	col=vrtx_set->l;
	for (i=1; i<=(*SN)->vertices_num; i++) {
		for (j=1; j<=(*SN)->vertices_num; j++) {
			MatAsgn((*SN)->mat,i,j,MatGet(N->mat,row->val,col->val));
			col=col->next;
		}
		row=row->next;
		col=vrtx_set->l;
	}
#if	DEBUG_TRACE > 5
	printf("%s: exited having created a network of type %d with %d vertices\n",
	prog, (*SN)->mat->type, (*SN)->vertices_num);
//	matrix_dump (stdout, (*SN)->mat->full, "matrix when returning from network_generate_from_subset", 2);
#endif

	return RC_OK;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// allocate and initialize a network
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Network * network_init(char *name, int num, int vertices, int edges, int colors, int profiles)
{
	Network *N;
	int	i;
	Edge *e;

#if	DEBUG_TRACE > 6 
	printf("network_init: entered to construct a network '%s' and initialize it with %d vertices, %d edges, %d profiles\n", 
	name, vertices, edges, profiles);
#endif

	N=(Network*)mycalloc(1,sizeof(Network));
	N->name=name;
	N->number=num;
	N->vertices_num = vertices;
	N->edges_num = edges;
	N->con_vertices_num = 0;
	N->mat = NULL;
	if (vertices > 0) {
		MatInit(&N->mat, vertices);
	}
	N->e_arr = NULL;
	if (edges > 0) {
		N->e_arr=(Edge*)mycalloc(edges+1,sizeof(Edge));
		for (i=1; i<=edges; i++) {
			N->e_arr[i].s=0;
			N->e_arr[i].t=0;
			N->e_arr[i].color=0;
			N->e_arr[i].reverse=NULL;
			N->e_arr[i].profile=0;
		}
	}
	N->indeg = NULL;
	N->outdeg = NULL;
	N->edgs = NULL;
	N->profs = NULL;
	N->vrt_name = NULL;
	N->colors = colors;

	if (profiles>0) {
		N->edgs = (Edge***)mycalloc(profiles, sizeof(Edge**));
		N->profs = (int *)mycalloc(profiles, sizeof(int));
		for (i=0; i<profiles; i++) {
			N->edgs[i] = NULL;
			N->profs[i] = 0;
		}
		if (edges>0) {
			for (i=0; i<profiles; i++) {
				N->edgs[i] = (Edge **)mycalloc(edges+1,sizeof(Edge*));		//ss << >> can probably do with edges not edges+1
			}
		}
	}

#if	DEBUG_TRACE > 5
	printf("network_init: constructed a network '%s' for %d colors and %d Profiles\n", name, colors, profiles);
#endif

	return N;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	load a network from a file to memory.
// previously called load_network
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int network_load(Network **N_p, char* network_fname, int undirected_flag, int ts, FILE* log_fp)
{
	int   rc=RC_OK;
	int	s,t,i,j,color;
	int	bad_color=0;
	list	*e_list;						//	edge list into which the input data is initially, temporarily, read into
	list_item *l_e;
	int	max_node=0;
	int	cnt=1;
	int	max_color=0;
	Edge	*e;
	FILE	*net_fp;
	char	vrt_names_fname[80];
	FILE	*vrt_names_fp = NULL;
	Network *N;
	int	self_edges=0;
	int	Maxcolor;
	char	vrt_name[100];
	char	*prog = "network_load";

#if	DEBUG_TRACE > 0
	printf("%s: entered with network_fname=%s undirected_flag=%d\n", prog, network_fname, undirected_flag);
#endif

	Maxcolor = (int)pow((double)2, (double)COLORS);		// number of color combinations. for two colors this is 4

// open the input file
	if ((net_fp = fopen(network_fname,"rt"))==NULL) {
		printf("file '%s' cannot be opened\n", network_fname);
		exit(-1);
	}

//	first round of reading the data - to figure max_node
	while ( (rc = fscanf( net_fp,"%d %d %d\n", &s, &t, &color) != EOF) ) {
		if (s > max_node) max_node = s;
		if (t > max_node) max_node = t;
		if (color > max_color) max_color = color;
	}
	fclose(net_fp);

//	reopen the input file for real reading of the file
	net_fp = fopen(network_fname,"rt");

//initializing a list of edges into which the input will be read
	list_init(&e_list);

//read edges one by one and insert them to a list of edges
	while ( (rc = fscanf( net_fp,"%d %d %d\n", &s, &t, &color) != EOF) ) {	//ss	11.13
		// if non default order of vertices then switch 's' and 't'
		if (ts) {
			i=s;
			s=t;
			t=i;
		}
		//insert edge to edge list
		e=(Edge*)mycalloc(1,sizeof(Edge));
		e->s=s;
		e->t=t;
		e->color=color;
		if (color < 1 || color >= Maxcolor) {
			fprintf(stdout, "edge %d -> %d has illegal color %d.\n",	s, t, color);
			bad_color++;
		}

		// handle self edges
		if (s == t) {
			self_edges++;
#if IGNORESELFEDGES == 1
			printf("edge %d->%d (%d) is ignored\n", s, t, color);
#endif
#ifdef IGNORESELFEDGES
			myfree(e);
			continue;
#endif
		}
		edge_color_add(e_list, s*max_node+t, e);
	}
	fclose(net_fp);

#if IGNORESELFEDGES <= 2
	if (self_edges)
		printf("%d self edges were encountered. they were ignored at loading\n", self_edges);
#endif

	if (bad_color) {
		fprintf(stdout, "program aborts due to %d illegal color(s)\n", bad_color);
		exit (-1);
	}

//	initializing network
	N = network_init(network_fname, 0, max_node, e_list->size, COLORS, PROFILES);

	//	construct N->e_arr
	if(undirected_flag==FALSE) {
		//	handle the case of a directed graph
		//	fill e_arr according to e_list and free e_list
		for(i=1,l_e=list_get_next(e_list,NULL);i<=N->edges_num;i++,l_e=list_get_next(e_list,l_e)){
			N->e_arr[i].s=((Edge*)(l_e->p))->s;
			N->e_arr[i].t=((Edge*)(l_e->p))->t;
			N->e_arr[i].color=((Edge*)(l_e->p))->color;													//ss	11.13
			if (N->e_arr[i].color >= Maxcolor) {															//ss	11.15
				fprintf(stdout, "edge %d -> %d has illegal commulative color %d.\n", 			//ss	11.14
					N->e_arr[i].s, N->e_arr[i].t, N->e_arr[i].color);									//ss	11.14
				bad_color++;																						//ss	11.14
			}																											//ss	11.14
		}
		if (bad_color) {																							//ss	11.14
			fprintf(stdout, "program aborts due to illegal commulative color(s)\n");			//ss	11.14
			exit (-1);																								//ss	11.14
		}																												//ss	11.14
#if COLORS == 1
	} else {
// the following code, that handls undirected graphs, requires adaptation for handling of color		<<
		//undirected graph - need to duplicate each edge to two : both directions
		//allocate e_arr fill it accordint to e_list and free e_list
		N->e_arr=(Edge*)mycalloc((N->edges_num+1)*2,sizeof(Edge));
			if (DEBUG_LEVEL >=9)
			fprintf(log_fp,"function network_load : N->e_arr allocated at %x\n",N->e_arr);
		for(i=1,l_e=list_get_next(e_list,NULL);i<=N->edges_num;i++,l_e=list_get_next(e_list,l_e)){
			N->e_arr[2*i-1].s=((Edge*)(l_e->p))->s;
			N->e_arr[2*i-1].t=((Edge*)(l_e->p))->t;
			N->e_arr[2*i].s=((Edge*)(l_e->p))->t;
			N->e_arr[2*i].t=((Edge*)(l_e->p))->s;
		}
		N->edges_num*=2;
#endif
	}
	list_free_mem(e_list);

	network_construc_from_edges (N, log_fp);

//	handle vertex names
	if (strlen(network_fname) < sizeof(vrt_names_fname) - 15) {
		strcpy(vrt_names_fname, network_fname);
		strcat(vrt_names_fname,".vrt_names");
		vrt_names_fp  = fopen(vrt_names_fname,"rt");
		if (vrt_names_fp) {
			N->vrt_name = (char **)mycalloc(N->vertices_num+1, sizeof(char *));
			N->vrt_name[0] = NULL;
			for(i=1; i<=N->vertices_num; i++) {
				N->vrt_name[i] = (char *)myalloc(VRT_NAME_LEN+1);
				N->vrt_name[i] = "";
			}
			while ( (rc = fscanf(vrt_names_fp,"%d %s\n", &i, &vrt_name)) != EOF) {
				if(i < 1 || i > N->vertices_num || strlen(vrt_name) > VRT_NAME_LEN) {
					printf ("error in reading names of vertices\n");
					break;
				} else 
					strcpy (N->vrt_name[i], vrt_name);
			}
			fclose(vrt_names_fp);
		}
	}

	if(DEBUG_LEVEL>11)
		network_dump(stdout,N);
	*N_p=N;

#if	DEBUG_TRACE > 3
	printf("%s: returning\n", prog);
#endif
	return rc;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	routine to compute a motif id for a network. the network is assumed to be maintained in FULL format.
//	previously - get_motif_id
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void network_motif_id(MotifID *id, Network *N, int colors, int pcolors)
{
	int i;
	int mat_cells_num=N->vertices_num*N->vertices_num;
	char	*prog = "network_motif_id";

#if	DEBUG_TRACE > 4
	printf("%s: entered with matrix:", prog);
	matrix_dump(stdout, N->mat->full, "", 2);
#endif

//	check that received a valid pointer
	if (!id) {
		printf("%s was called with a null id. program halted\n", prog);
		exit(-1);
	}
//	check that the matrix is of the appropriate type
	if(N->mat->type!=FULL) {
		printf("%s was called with a matrix that is not of type FULL. program halted\n", prog);
		exit(-1);
	}
//	check that the type of the ID is long enough to encode the matrix
	if(mat_cells_num*colors > sizeof(MotifID)*BITINBYTE) {
		printf("%s was called with a matrix on %d vertices - too big to be encoded. program halted\n",
		prog, N->vertices_num);
		exit(-1);
	}

//	do the real work
	motif_id_from_matrix (id, N->mat->full, colors, pcolors);

#if	DEBUG_TRACE > 4
//	motif_id_print (&id, stdout, "network_motif_id: returned with id", "\n");
	motif_id_print (id, stdout, "network_motif_id: returned with id ", "\n");
#endif

	return;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	Given a network and a color, calculate:
//	the number of vertices of the a given color
//	the number of edges that are incident to the a given color
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	network_size_by_color (Network *N, int *vrt, int *edg, int color)
{
	int	vrtx = 0;
	int	edges = 0;
	int	i;
	SparseMatrix *spr;
	int	included;
	list_item *from, *to;
	int	clr;
	Edge	*e;
	char	*prog="network_size_by_color";

	if (color == 0) {
		vrtx = N->vertices_num;
		edges = N->edges_num;
	} else {
		if (N->mat->type == SPARSE) {
			spr = N->mat->spr;
			for (i=1; i<=spr->size; i++) {
				included = FALSE;
				if (spr->m[i].from) 
					for (from=spr->m[i].from->l; from && !included; from=from->next) {
						clr = *((int*)(from->p));
							if (color_is_suitable(clr, color))
								included = TRUE;
					}
				if (spr->m[i].to) 
					for (to=spr->m[i].to->l; to && !included; to=to->next) {
						clr = *((int*)(to->p));
						if (color_is_suitable(clr, color))
							included = TRUE;
					}
				if (included)
					vrtx++;
			}
		} else {
			printf ("%s does not handle non-sparse matrices\n", prog);
		}
		for(i=1;i<=N->edges_num;i++) {
			e = N->e_arr + i;
			if (color_is_suitable(e->color, color))
				edges++;
		}
	}
	*vrt = vrtx;
	*edg = edges;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	an edge profile encodes the out and in colors of an edge
//	dump the edge profiles of a network
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void profile_dump (FILE *fp, Network *N)
{
	int	i,j;
	Edge	*e;
	int	pcolors = (int)pow(2,N->colors);

	if (N) {
		if (N->edgs && N->profs && PROFILES)
			for (i=0; i<PROFILES; i++) {
				if (N->edgs[i] && N->profs[i]) {
					fprintf (fp,"profile %d (%d,%d): ", i, profile_out(i, pcolors), profile_in(i, pcolors)); 
					for (j=0; j<N->profs[i]; j++) {
						e = (N->edgs[i])[j];
						fprintf (fp,"%d->%d (%d)  ", e->s, e->t, e->color); 
					}
					printf("\n");
				}
			}
		else
			fprintf (fp, "network '%s' has no profiles defined\n");
	} else 
		fprintf (fp, "profile_dump: null network\n");
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	outgoing color of a profile
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int profile_out (int prof, int pcolors)
{
	return (prof/pcolors);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	ingoing color of a profile
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int profile_in (int prof, int pcolors)
{
	return (prof%pcolors);
}

