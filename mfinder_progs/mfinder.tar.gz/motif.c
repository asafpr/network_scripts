#include <stdio.h>
#include <stdlib.h>
#include "common.h"
#include "list.h"
#include "motif.h"
#include "arguments.h"
#include "permutation.h"

#define BITINBYTE 8

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	check whether a motif contains an isolated vertex
//	This routine is not capable of handling a MotifID that is not 64 bit. Since it probably will not be used in such
//	cases nothing was done about it except for introducing an announced abort if this is the case.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int motif_contains_isolated_vertex (MotifID *id_motif, int mtf_sz)
{
	int	i, j;
	int	rtn = FALSE;
	VERYLONGINT mask_r;
	VERYLONGINT mask_c;
	VERYLONGINT *id;
	char	*prog="motif_contains_isolated_vertex";

	if (sizeof(VERYLONGINT) != sizeof(MotifID)) {
		printf ("%s cannot handle motifs of size different from VERYLONGINT\n", prog);
		exit (-1);
	}

	id = (VERYLONGINT *)id_motif;

	for(i=0;i<mtf_sz;i++) {
		mask_r=0;
		mask_c=0;
		for(j=0;j<mtf_sz;j++) {
			mask_r |= (VERYLONGINT)pow(2,i*mtf_sz+j);
			mask_c |= (VERYLONGINT)pow(2,i+j*mtf_sz);
		}
		if( ! ((*id & mask_r) || (*id & mask_c)) ) {
			rtn = TRUE;
			break;
		}
	}

	return rtn;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	check whether a motif contains a self loop
//	This routine is not capable of handling a MotifID that is not 64 bit. Since it probably will not be used in such
//	cases nothing was done about it except for introducing an announced abort if this is the case.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int motif_contains_self_loop (MotifID *id_motif, int mtf_sz)
{
	int	i;
	int	rtn = FALSE;
	VERYLONGINT mask_bit;
	VERYLONGINT *id;
	char	*prog="motif_contains_self_loop";

	if (sizeof(VERYLONGINT) != sizeof(MotifID)) {
		printf ("%s cannot handle motifs of size different from VERYLONGINT\n", prog);
		exit (-1);
	}

	id = (VERYLONGINT *)id_motif;

	for(i=0;i<mtf_sz;i++) {
		//bits on the diagonal
		mask_bit=(VERYLONGINT)pow(2,i*mtf_sz+i);
		if(*id & mask_bit) {
			rtn = TRUE;
			break;
		}	
	}
	return rtn;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	routine to count the number of edges in a motif. adjusted for big motifs
//	the num of edges is actually the number of non-zero entries in the ID
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int motif_count_edges_old (Motif *mtf, int colors)
{
	int cnt=0;
	MotifID dummy;
LONGLONGINT	*dummy_int;
	int	i;
	int	*lowint;
	int	pcolors = (int)pow(2,colors);

	if (mtf) {

//	version suitable for motifs of type LONGLONGINT
//		dummy=(MotifID)mtf->id;
//		if (dummy!=0)
////			for(i=0;i<64;i++,dummy>>=1)												//ss	previous, single color, version
////				if (dummy & 1)
//			for(i=0;i<64/colors;i++,dummy>>=colors)									//ss	previous, multi color, version
//				if (dummy & (pcolors -1))
//					cnt++;

	dummy_int = (LONGLONGINT *)&dummy;
//	version suitable for motifs of any type that is a concatenation of 32-bit integers with the leftmost being low-digits.
		memcpy (&dummy, &(mtf->id), sizeof(MotifID));								//	make a copy of the motif
		lowint = (int *)&dummy;																//	make a pointer to the lowest int
//		for(i=0;i<sizeof(MotifID)*BITINBYTE/colors;i++,dummy>>=colors)			//	shift motif by 'colors' bits
		for(i=0;i<sizeof(MotifID)*BITINBYTE/colors;i++,*dummy_int>>=colors)	//	shift motif by 'colors' bits
			if (*lowint & (pcolors -1))													//	if appropriate mask is non-zero
				cnt++;																			//	increment counter

	}
	return cnt;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	routine to count the number of edges in a motif. adjusted for big motifs
//	the num of edges is actually the number of non-zero entries in the ID
//	version suitable for motifs of any type that is a concatenation of 32-bit integers with the leftmost being low-digits.
//	MotifID is assumed to be an integer number of bytes, at least of size sizeof(int)
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int motif_count_edges (Motif *mtf, int colors)
{
	int cnt=0;
	char *mtf_char;
	int	i, edge;
	int	bgnbyte;																						//	the byte in which the edge begins
	int	endbyte;																						//	the byte in which the edge end
	int	shift;																						//	the required bit shift
	int	edge_shifted;
	int	pcolors = (int)pow(2,colors);
	char	*prog="motif_count_edges";

	if (mtf) {																							//	if motif is not null
		mtf_char = (char *)&(mtf->id);															//	set a char pointer to motif id
		for(edge=0;edge<sizeof(MotifID)*BITINBYTE/colors;edge++)	{						//	loop on all edges
			//	edge i starts at bit 'i'*'colors' and takes 'colors' bits.
			bgnbyte = edge*colors/BITINBYTE;														//	calculate bgnByte & endbyte
			if (bgnbyte + sizeof(int) -1 <= sizeof(MotifID)) {								//	calculate bgnByte & endbyte
				endbyte = bgnbyte + sizeof(int) -1;												//	calculate bgnByte & endbyte
			} else {																						//	calculate bgnByte & endbyte
				endbyte = sizeof (MotifID);														//	calculate bgnByte & endbyte
				bgnbyte = endbyte - sizeof(int) + 1;											//	calculate bgnByte & endbyte
			}
			shift = edge*colors - bgnbyte*BITINBYTE;											//	calculate shift
			memcpy (&edge_shifted, mtf_char + bgnbyte, sizeof(int));						//	byte shift
			edge_shifted >>= shift;																	//	bit shift
			if (edge_shifted & (pcolors -1))														//	if appropriate mask is non-zero
				cnt++;																					//	increment counter
		}
	}
#ifdef AUTO_CHECK
	if (sizeof(VERYLONGINT) == sizeof(MotifID))
		if (motif_count_edges_old (mtf, colors) != cnt)
			printf ("%s: count old=%d count new=%d\n", prog, motif_count_edges_old (mtf, colors), cnt);
#endif
	return cnt;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	frees memory of elements hanging on the motif and frees the motif itself
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int motif_delete (Motif *m)
{
	int rtn = 0;

	if(m) {
		if (m->members)
			list_free_mem (m->members);
		myfree(m);
	}
	return rtn;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	print a motif. adjusted for big motifs
// Motif *m		- motif
//	char *msg	- message/identifier to be presented prior to the dump of the motif
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void motif_dump(FILE *fp, Motif *m, char *msg)
{
	int	*p;

	if(m != NULL) {
		p = (int *)&(m->id);
		fprintf(fp, "%s", msg);
		motif_id_print(&(m->id), fp, " id=", " ");
		if (m->members) 
			fprintf(fp, "members=%d ", m->members->size);
		else 
			fprintf(fp, "members is null ");
		fprintf(fp, "count=%f ", m->count);
		if (m->members) 
				if (m->members->size > 0) 
					list_dump(fp, m->members);
		fprintf (fp, "\n");
	} else
		fprintf(fp, "%s motif is NULL\n", msg);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	OLD VERSION of encoding a matrix 'M' to yield its motif ID.
//	the id encodes the matrix as if it was one long array.
//	each element of the matrix consumes several bits in the id. the number of bits depends on 'colors'. 
//	based on void matrix_64_encode. moved from mat.c to motif.c
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void motif_id_from_matrix_old(MotifID *id, Matrix *M, int colors, int pcolors)
{
	int	i;
	int	shift=FALSE;
	int	*lowint;
	LONGLONGINT *int_id;
	int	mat_cells_num=M->size*M->size;

#if	DEBUG_TRACE > 4
//	static int NN=0;
	char	*prog = "motif_id_from_matrix";
//	if (NN++ > 10) exit (-1);
	printf("%s: entered with colors=%d, pcolors=%d matrix is ", prog, colors, pcolors);
	matrix_dump(stdout, M, "", 1);
#endif

	int_id = (LONGLONGINT *)id;
	lowint = (int *)id;
	memset (id, 0, sizeof(MotifID));
	for(i=mat_cells_num-1;i>=0;i--) {
		if (shift)
//			*id <<= colors;
			*int_id <<= colors;
		if (M->m[i])
			*lowint = *lowint | ((pcolors -1) & M->m[i]);
		shift = TRUE;
	}

#if	DEBUG_TRACE > 4
	motif_id_print (id, stdout, " yielding motif:", "\n");
#endif

	return;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	encode a matrix 'M' to yield its motif ID.
//	the id encodes the matrix as if it was one long array.
//	each element of the matrix consumes several bits in the id. the number of bits depends on 'colors'. 
//	History: based on void matrix_64_encode. 
//				transformed to operate on a structure of size 64 bit instead of on 64-bit integers
//				moved from mat.c to motif.c
//				transformed to operate on a structure of any number of integers.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void motif_id_from_matrix(MotifID *id, Matrix *M, int colors, int pcolors)
{
	int	i;																			//	index on integers composing the MotifID
	int	m;																			//	index on matric celss
	int	shift=FALSE;															//	indicator whether to perform a shift
	int	mat_cells_num=M->size*M->size;									//	number of cells in matrix
	int	ints = sizeof(MotifID)/sizeof(int);								//	number of integers in MotifID
	int	*id_int;																	//	an integer pointer to 'id'
	int	lowerint;																//	lower one
	MotifID	id_old_version;													//	id resulting from an old version of this routine

#if	DEBUG_TRACE > 4
//	static int NN=0;
	char	*prog = "motif_id_from_matrix";
//	if (NN++ > 10) exit (-1);
	printf("%s: entered with colors=%d, pcolors=%d matrix is ", prog, colors, pcolors);
	matrix_dump(stdout, M, "", 1);
#endif

	memset (id, 0, sizeof(MotifID));
	id_int = (int *)id;

	for(m=mat_cells_num-1;m>=0;m--) {
		if (shift)
			for (i=ints-1; i>=0; i--)  {
				*(id_int + i) <<= colors;
				if (i > 0) {
					*(id_int + i) = *(id_int + i) | ((*(id_int + i - 1) >> (sizeof(int)*BITINBYTE - colors)) & (pcolors -1));
				}
			}
		if (M->m[m])
			*id_int = *id_int | ((pcolors -1) & M->m[m]);
		shift = TRUE;
	}

#ifdef AUTO_CHECK
	if (sizeof(VERYLONGINT) == sizeof(MotifID)) {
		motif_id_from_matrix_old (&id_old_version, M, colors, pcolors);
		if (memcmp (&id_old_version, id, sizeof(MotifID))) {
			printf ("motif_id_from_matrix: conflict bewteen old and new version:");
			motif_id_print (id, stdout, " new version of motif id:", "\n");
			motif_id_print (&id_old_version, stdout, " old version of motif id:", "\n");
		}
	}
#endif

#if	DEBUG_TRACE > 4
	motif_id_print (id, stdout, " yielding motif:", "\n");
#endif

	return;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	returns the motif id of a motif with no edges
//	This routine is not capable of handling a MotifID that is not 64 bit. Since it probably will not be used in such
//	cases nothing was done about it except for introducing an announced abort if this is the case.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void motif_id_minimal (MotifID *id, int mtf_sz, int colors)
{
	VERYLONGINT	i = 0;
	char	*prog="motif_id_minimal";

	if (sizeof(VERYLONGINT) != sizeof(MotifID)) {
		printf ("%s cannot handle motifs of size different from VERYLONGINT\n", prog);
		exit (-1);
	}

	memcpy (id, &i, sizeof(MotifID));
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	returns the motif id following the one that is given.
//	the return value is true unless the id is the biggest possible.
//	This routine is not capable of handling a MotifID that is not 64 bit. Since it probably will not be used in such
//	cases nothing was done about it except for introducing an announced abort if this is the case.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int motif_id_next(MotifID *id, int mtf_sz, int colors)
{
	char	*prog="motif_id_next";
	VERYLONGINT *id_int;

	if (sizeof(VERYLONGINT) != sizeof(MotifID)) {
		printf ("%s cannot handle motifs of size different from VERYLONGINT\n", prog);
		exit (-1);
	}

	id_int = (VERYLONGINT*)id;

//	if (*id >= pow(2,colors*mtf_sz*mtf_sz)-1)
	if (*id_int >= pow(2,colors*mtf_sz*mtf_sz)-1)
		return FALSE;

//	*id = *id + 1;
	*id_int = *id_int + 1;
	return TRUE;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	print motif id. adjusted for big motifs
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void motif_id_print (MotifID *id, FILE *fp, char* before, char* after)
{

	int	*p;
	int	i=0;
	int	j, oneint;
	int	chunks;

	fprintf(fp, "%s", before);
	chunks = sizeof(MotifID)/sizeof(int);
	p = (int *)id;
	for (j=0; j<chunks; j++) {
		oneint = *(p + chunks - 1 - j);
		if (!oneint)
			continue;
		fprintf (fp, "%u", oneint);
//		fprintf (fp, "%d", oneint);
//		if (j == chunks-1)
//			fprintf (fp, "\t");
//		else
//			fprintf (fp, "-");
		if (j < chunks-1)
			fprintf (fp, "-");
	}
	fprintf(fp, "%s", after);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	routine that receives a motif ID and prepares a matrix that has the given motif ID
//	motif_id_to_matrix is COLORS dependent and has been revised from the simple loop
//
//	for(i=0;i<mat_cells_num;i++,id/=2)
//		M->m[i]=((char)(id & 1));
//
// to a COLORS dependant loop
//	moved fill_mat_id routine from permutation.c to motif.c. renamed fill_mat_id to motif_id_to_matrix
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void motif_id_to_matrix_old(Matrix *M, MotifID *id_p, int colors)
{
	int	i;
	int	mat_cells_num=M->size*M->size;
//	int	significant_bits = (int)pow(2,colors) - 1;
	int	pcolors = (int)pow(2,colors);
	MotifID	id;
	LONGLONGINT *int_id_p;
	int	shift=FALSE;
	int	*lowint;

#if	DEBUG_TRACE > 4
//	static int NN=0;
	char	*prog="motif_id_to_matrix";
//	if (NN++ > 10) exit (-1);
	printf("%s: entered with colors=%d", prog, colors);
	motif_id_print (id_p, stdout, " id=", " ");
#endif

	memcpy (&id, id_p, sizeof(MotifID));

	lowint = (int *)&id;
	int_id_p = (LONGLONGINT *)&id;
	for(i=0; i<mat_cells_num;i++) {
		if (shift)
//			id >>= colors;
			*int_id_p >>= colors;
//printf("i=%d, lowint=%d ", i, *lowint);
		M->m[i]=((char)(*lowint & (pcolors - 1)));
		shift = TRUE;
	}

#if	DEBUG_TRACE > 4
	printf ("yielded matrix ");
	matrix_dump(stdout, M, "", 1);
	printf ("\n");
#endif
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	routine that translates a motif ID to a matrix that has the given motif ID.
//	motif_id_to_matrix is COLORS dependent.
//	History: initially, the rouint had the following ('colors' independent) form
//						for(i=0;i<mat_cells_num;i++,id/=2)
//							M->m[i]=((char)(id & 1));
//				it was modified to a 'colors' dependent form.
//				it was transformed to operate on a structure of size 64 bit instead of on 64-bit integers
//				it was moved from permutation.c to motif.c. 
//				it was renamed from fill_mat_id to motif_id_to_matrix
//				it was transformed to operate on a structure of any number of integers, based on 'motif_count_edges'
//	assumptions: mat_cells_num <= sizeof(MotifID)*BITINBYTE/colors
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void motif_id_to_matrix(Matrix *M, MotifID *id, int colors)
{
	int	mat_cells_num=M->size*M->size;
	int	i;
	char	*id_char;
	int	edge;
	int	bgnbyte;																					//	the byte in which the edge begins
	int	endbyte;																					//	the byte in which the edge end
	int	shift;																					//	the required bit shift
	int	edge_shifted;
	Matrix	*M_old_version;
	int	diff;
	int	pcolors = (int)pow(2,colors);

#if	DEBUG_TRACE > 4
//	static int NN=0;
	char	*prog="motif_id_to_matrix";
//	if (NN++ > 10) exit (-1);
	printf("%s: entered with colors=%d", prog, colors);
	motif_id_print (id, stdout, " id=", " ");
#endif

	id_char = (char *)id;
	for(edge=0;edge<mat_cells_num;edge++)	{												//	loop on all edges
		bgnbyte = edge*colors/BITINBYTE;														//	calculate bgnByte & endbyte
		if (bgnbyte + sizeof(int) -1 <= sizeof(MotifID)) {								//	calculate bgnByte & endbyte
			endbyte = bgnbyte + sizeof(int) -1;												//	calculate bgnByte & endbyte
		} else {																						//	calculate bgnByte & endbyte
			endbyte = sizeof (MotifID);														//	calculate bgnByte & endbyte
			bgnbyte = endbyte - sizeof(int) + 1;											//	calculate bgnByte & endbyte
		}
		shift = edge*colors - bgnbyte*BITINBYTE;											//	calculate shift
		memcpy (&edge_shifted, id_char + bgnbyte, sizeof(int));						//	byte shift
		edge_shifted >>= shift;																	//	bit shift
		M->m[edge]=((char)(edge_shifted & (pcolors -1)));								//	if appropriate mask is non-zero
	}

#ifdef AUTO_CHECK
	if (sizeof(VERYLONGINT) == sizeof(MotifID)) {
		M_old_version = init_matrix(M->size);
		motif_id_to_matrix_old(M_old_version, id, colors);
		diff=FALSE;
		for (i=0; i<mat_cells_num;i++) {
			if (M->m[i] != M_old_version->m[i])
				diff=TRUE;
		}
		if (diff) {
			printf ("motif_id_to_matrix:  conflict bewteen old and new version:");
			matrix_dump(stdout,M, "M", 1);
			matrix_dump(stdout,M_old_version, "M_old_version", 1);
		}
		matrix_free (M_old_version);
	}
#endif

#if	DEBUG_TRACE > 4
	printf ("yielded matrix ");
	matrix_dump(stdout, M, "", 1);
	printf ("\n");
#endif
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	allocate and initialize a motif 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Motif * motif_ini ()
{
	Motif *m ;

	m = (Motif *)myalloc(sizeof(Motif));

	memset (&m->id, 0, sizeof(MotifID));
	m->count = 0.;
	m->prob_count = 0.;
	m->conc = 0.;
	m->members = NULL;

	return m;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	insert a list of vertices ('vrtx_set') into the list of members of a motif 'mtf'
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void motif_insert_members (Motif* mtf, list* vrtx_set, int mtf_sz)
{
	int	i;
	int	unique;
	int	*mtf_vrtx_arr;  //array that store the motif vertices
	list_item *item;
	FILE	*fp = arg_get_fp("log_fp");
	char	*prog="motif_insert_members";

//	allocate an array ('mtf_vrtx_arr') to contain the vertices of the vertex list 'vrtx_set'
	mtf_vrtx_arr = (int*)mycalloc(mtf_sz,sizeof(int));
	if (DEBUG_LEVEL >=9)
		fprintf(fp,"%s: mtf_vrtx_arr allocated at %x\n", prog, mtf_vrtx_arr);

//	convert the list of vertices 'vrtx_set' to an array of vertices 'mtf_vrtx_arr' 
	for(i=0,item=list_get_next(vrtx_set,NULL);item!=NULL;	i++,item=list_get_next(vrtx_set,item))
		mtf_vrtx_arr[i]=item->val;

	if (DEBUG_LEVEL >= 1) {
		fprintf(fp, "%s: ", prog);
		motif_id_print(&(mtf->id), fp, "existing id=", " ");
		fprintf(fp,"new motif members are: ");
		for (i=0;i<mtf_sz;i++)
			fprintf(fp,"%d ",mtf_vrtx_arr[i]);
		fprintf(fp, "\n");
	}

//	handle the case where the motif has no members
	if (mtf->members->size == 0) {

		//	insert mtf_vrtx_arr as an element in the members
		list_insert(mtf->members,1,(void*)mtf_vrtx_arr);

//	handle the case that there are some members
	} else {

		//	if this vertices set is unique (no common vertices with same motif id that already found) then insert to list
		if(motif_members_intersect_array(mtf, mtf_vrtx_arr, mtf_sz)) {
			if (DEBUG_LEVEL >= 1)
				fprintf(fp,"%s: Found unique motif members, going to insert them to list\n", prog);
			list_insert(mtf->members, (int)mtf->count, (void*)mtf_vrtx_arr);		//! comment - is the count OK? (maybe +1)?
		} else {
			myfree (mtf_vrtx_arr);
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	check whether a motif id is equivalent to an int
//	This routine is not capable of handling a MotifID that is not 64 bit. Since it probably will not be used in such
//	cases nothing was done about it except for introducing an announced abort if this is the case.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int motif_is_int (MotifID *id, int i)
{
	int	rtn = FALSE;
	VERYLONGINT	*j;
	char	*prog="motif_is_int";

	if (sizeof(VERYLONGINT) != sizeof(MotifID)) {
		printf ("%s cannot handle motifs of size different from VERYLONGINT\n", prog);
		exit (-1);
	}

	j = (VERYLONGINT *)id;
	if (*j == i)
			rtn = TRUE;
	return rtn;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	Take a list of motifs and replace it with another list where the motifs are pairwise non-isomorphic.
//	previously called calc_motifs_res
//	More specifically:
// Loop through the input list of motifs (as long as it is not empty) and take the first motif (li_res)
// create a list of ALL possible motifs that are isomorphic to li_res (this list is 'iso_id_list')
// create a new motif (rep_mtf)  
// fill rep_mtf with initial data
// loop through elements in iso_id_list 
//		if such element is in the input list of motifs
//			increment the counts in rep_mtf
// 		if required, retain these motifs in the list of members of rep_mtf
//			remove the element from the input list of motifs
//	insert rep_mtf into the final output list
//	free memory
//
//	arguments:
//	list	**motif_list_p	-	on input this points to the input list of motifs. on output it points to the output list
//	int	mtf_sz			-	size of required motifs
//	int	pcolors 			-	the number of color combinations
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void motif_list_unify_isomorphic (list **motif_list_p, int mtf_sz, int colors)
{
	list_item *li_res, *l_res,*l_iso,*l_iso_rep, *l_members;
	MotifID rep_id;
	MotifID curr_id;		//	motif id in the list of isomorphic motifs
	list	*iso_id_list,*members_list;
	list	*out_motif_list;
	list	*inp_motif_list=*motif_list_p;
	Motif *rep_mtf, *mtf;
	int	i;
	int	*mtf_vrtx_arr, *new_vrtx_arr;
	double total_prob_counts=0;
	double total_motifs_counts=0;
	int	prob_app_samples_num = arg_get_int("prob_app_samples_num");
	FILE	*fp = arg_get_fp("log_fp");
	char	*prog = "motif_list_unify_isomorphic";

#if	DEBUG_TRACE > 1
//	static int NN=0;
//	if (NN++ > 2) exit (-1);
	printf("%s: entered with %d motifs of size %d, uniqueness_flag=%d with motif list\n", 
	prog, inp_motif_list->size, mtf_sz, arg_get_int("calc_unique_flag"));
#endif
#if	DEBUG_TRACE > 4
	motifs_dump (stdout, inp_motif_list, "motif_list_unify_isomorphic entry");
#endif

//	initialize the output list of motifs
	list_ini(&out_motif_list, LIST_KEY_GEN);

//	main loop: process motifs in the input list, as long as any remain
//	------------------------------------------------------------------
	while(li_res=list_get_next(inp_motif_list,NULL)) {
//		motif_id_print ((MotifID *)&(li_res->key), stdout, "handling motif id:", " ");

// prepare a list of all possible motifs (not necessarily in 'inp_motif_list') isomorphic to 'li_res' 
		iso_id_list=mtf_id_iso_list((MotifID *)&(li_res->key), mtf_sz, colors);

// prepare a new motif to eventually replace 'li_res' and those isomorphic to it
		rep_mtf = motif_ini();

//	initialize the key and the members in 'rep_mtf'
		l_iso_rep = list_get_next(iso_id_list, NULL);					//	get the first item in the list iso_id_list
		list_element_key_get (l_iso_rep, (void *) &rep_id);			//	extract the key from it (rep_id)
		memcpy (&(rep_mtf->id), &(rep_id), sizeof(MotifID));			//	set that to be the key of 'rep_mtf'
		list_init(&rep_mtf->members);											//	initialize a null list of members of 'rep_mtf'

//	find all other isomorphic id-s in inp_motif_list, remove them from inp_motif_list and sum all iso id counts
//	insert new item with canonical ID to the out_motif_list 

		//	loop through all isomorphic motifs - those in 'iso_id_list' (not necessarily in 'inp_motif_list') 
		for(l_iso=list_get_next(iso_id_list,NULL); l_iso; l_iso=list_get_next(iso_id_list,l_iso)) {
			list_element_key_get (l_iso, (void *) &curr_id);			//	fetch the key of the motif
//			motif_id_print (&curr_id, stdout, "iso-id:", "\n");			//	debug statement
			if(l_res=list_get_by_key (inp_motif_list, (void*)&curr_id)){//	if the motif is also in 'inp_motif_list'
				mtf = (Motif*)l_res->p;												//	take the motif (it needs to be unified)
				rep_mtf->count+=mtf->count;										//	add its count to the motif being constructed 
				rep_mtf->prob_count+=mtf->prob_count;							//	add its prob_count to the motif being constructed 
				if(arg_get_int("calc_unique_flag")) {							//	handle the need to do uniqueness calculation
					if(members_list=mtf->members) {								//	merge list of unique memebers of curr_id to rep_id
						for(l_members=list_get_next(members_list,NULL);
							l_members;l_members=list_get_next(members_list,l_members)){
							//pass through list, if this vertices set is unique (no common vertices with 
							//same motif id that already found) then insert to list
							mtf_vrtx_arr=(int*)l_members->p;
							if (motif_members_intersect_array(rep_mtf,mtf_vrtx_arr,mtf_sz)) {
								new_vrtx_arr=(int*)mycalloc(mtf_sz,sizeof(int));
								for(i=0;i<mtf_sz;i++)								//copy it since shortly all members of l_res are freed
									new_vrtx_arr[i]=mtf_vrtx_arr[i];
								list_insert(rep_mtf->members,rep_mtf->members->size+1,(void*)new_vrtx_arr);
							}
						}
						list_free_mem(members_list);								//free members list from curr_id
					}
				}
				//remove curr_id item from inp_motif_list list
				list_free_mem(((Motif*)(l_res->p))->members);				//ss	<<	an originally missing deallocation 
				list_del(inp_motif_list, &curr_id);
			}
		}
		list_free_mem (iso_id_list);												//ss << originally missing deallocation
		list_ins(out_motif_list,(void*)&rep_id,(void*)rep_mtf);			//	insert the newly created motif into output list
	}

//	at this stage the output list of motifs ('out_motif_list') has been prepared except for some normalization

	//	if probabilistic algorithm then here is the place to renormalize the prob_count field
	if(arg_get_int("run_prob_app")==TRUE) {
		//calc total_prob_count
		for(li_res=list_get_next(out_motif_list,NULL); li_res; li_res=list_get_next(out_motif_list,li_res)) {
			rep_mtf=(Motif*)li_res->p;
			total_prob_counts+=rep_mtf->prob_count;
		}
		//calc count for each motif
		//calc = prob_count/toal_prob_count
		for(li_res=list_get_next(out_motif_list,NULL); li_res; li_res=list_get_next(out_motif_list,li_res)) {
			rep_mtf=(Motif*)li_res->p;
			rep_mtf->count=(double)(((double)rep_mtf->prob_count/(double)total_prob_counts)*(double)prob_app_samples_num);
			rep_mtf->conc=1000*(double)rep_mtf->count/(double)arg_get_int("prob_app_samples_num");
		}

	//	if deterministic algorithm - normalize the concentrations
	} else {

		//	calculate the total of motif counts
		for(li_res=list_get_next(out_motif_list,NULL); li_res; li_res=list_get_next(out_motif_list,li_res)) {
			rep_mtf=(Motif*)li_res->p;
			total_motifs_counts+=rep_mtf->count;
		}
		//calc concentrations
		for(li_res=list_get_next(out_motif_list,NULL); li_res; li_res=list_get_next(out_motif_list,li_res)) {
			rep_mtf=(Motif*)li_res->p;
			rep_mtf->conc=1000*(double)rep_mtf->count/(double)total_motifs_counts;
		}
	}
			
//	free inp_motif_list
	res_tbl_mem_free_single (inp_motif_list);

// make the routine argument point to the output list
	*motif_list_p=out_motif_list;

#if	DEBUG_TRACE > 1
	printf("%s returning with %d motifs:\n", prog, out_motif_list->size);
#endif
#if	DEBUG_TRACE > 4
	motifs_dump (stdout, out_motif_list, "");
#endif
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// dump the matrix of a motif, in 'dim' dimensions
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void motif_matrix_dump (FILE *fp, MotifID *mtf_id, int dim, int colors)
{
	Matrix *m;

	m=init_matrix(arg_get_int("mtf_sz"));
	motif_id_to_matrix(m, mtf_id, colors);
	matrix_dump (fp,m, "", dim);
	free_matrix(m);
	myfree(m);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	check whether an array of vertices ('mtf_vrtx_arr') intersects any of the members of a motif ('mtf').
//	both the arrau and the members of 'mtf' are assumed to be of length 'mtf_sz'.
//	returns :	TRUE - if unique
//					FALSE - otherwise 
//	previously: int	check_if_unique(Motif *mtf,int *mtf_vrtx_arr,int mtf_sz) and motif_member_is_array_unique(...)
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int	motif_members_intersect_array (Motif *mtf,int *mtf_vrtx_arr, int mtf_sz)
{
	int	i,j;
	list_item *item;
	int	*vrtx_arr;
	int	unique=TRUE;
	FILE	*log_fp = arg_get_fp("log_fp");
	
	for(item=list_get_next(mtf->members,NULL); item; item=list_get_next(mtf->members,item)) {
		vrtx_arr=(int*)item->p;
		if (DEBUG_LEVEL >= 1) {
			fprintf(log_fp,"\n");
			for (i=0;i<mtf_sz;i++)
				fprintf(log_fp,"%d ",vrtx_arr[i]);
			fprintf(log_fp,"\n");
		}
		for(i=0;i<mtf_sz && unique;i++) {
			for(j=0;j<mtf_sz && unique;j++) {
				if (vrtx_arr[j]==mtf_vrtx_arr[i]) {
					unique=FALSE;
					break;
				}
			}
		}
	}
	return unique;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	dump a single motif occurenece 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	motif_occurence_dump (FILE *fp, list *vrtx_set, MotifID *mtf_id, int mtf_sz, int colors, list *dmp_mtf_lst,
	int net_num)
{
	list_item *item;
	MotifID mtf_id_cannonical;
	int *permutation;
	int j,k;

#if	DEBUG_TRACE > 5
	static	int itr=0;
	char	*prog = "motif_occurence_dump";
	printf("%s: entered", prog);
	motif_id_print (mtf_id, stdout,  " with motif ", ".\n");
	itr++;
	if (itr > 10) {printf ("%s aborts\n", prog); exit (-1);}
#endif

	if (!fp) {
		printf ("%s: entered with non-existing output file. program aborted\n");
		exit(-1);
	}

//	calculate canonical motif id
	mtf_id_min_iso (&mtf_id_cannonical, mtf_id, mtf_sz, &permutation, colors);

//	skip motif if there is a list of required motifs and it is not in it
	if (dmp_mtf_lst)
		if (!list_includes (dmp_mtf_lst, &mtf_id_cannonical))
			return;
//	if (dmp_mtf_lst) {
//		if (!list_includes (dmp_mtf_lst, &mtf_id_cannonical)) {
//			motif_id_print (&mtf_id_cannonical, stdout,  "the motif ", " is not in the list\n");
//			return;
//		}
//		motif_id_print (&mtf_id_cannonical, stdout,  "the motif ", " is in the list\n");
//	}

//	present network name
	fprintf (fp, "%d ", net_num);

//	present vertex set
	fprintf (fp, "{");
	for (item = list_get_next(vrtx_set,NULL); item; item=list_get_next(vrtx_set, item)){ 
		fprintf (fp, "%d", item->val);
		if (item->next)
			fprintf (fp, " ");
	}
	fprintf (fp, "} ");

//	present motif
	motif_matrix_dump (fp, mtf_id, 1, colors);
	motif_id_print (mtf_id, fp, " motif_id ", "->");

//	present canonical motif
	motif_id_print (&mtf_id_cannonical, fp, "", "");
	motif_matrix_dump (fp, &mtf_id_cannonical, 1, colors);

//	present permutation
	fprintf (fp, " permutation:");
	for (k=0; k<mtf_sz; k++)
			fprintf (fp, "%d ", permutation[k]+1);

//	present properly ordered vertex set
	fprintf (fp, " {");
	for (k=0; k<mtf_sz; k++) {
		for (item = list_get_next(vrtx_set,NULL), j=0; item && j<permutation[k]; item=list_get_next(vrtx_set, item), j++);
		fprintf (fp, "%d", item->val);
		if (k<mtf_sz-1)
			fprintf (fp, " ");
	}
	fprintf (fp, "} ");

//	finish
	fprintf (fp, "\n");

#if	DEBUG_TRACE > 4
	printf("%s: completed\n", prog);
#endif
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	dump a list of motifs
//	previously called:	void	dump_motifs_res(list *res, char *name)
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	motifs_dump(FILE *fp, list *motifs, char *name)
{
	list_item *li;
	Motif *mtf;			//	a repeating motif
	int	i;
//	int	*p;

	fprintf(fp, "motifs results %s, (%d motifs):\n", name, motifs->size);
	if (list_check(motifs) > 0)
		fprintf(fp, "inconsistency between 'size' and length\n");
	if (motifs->size == 0) {
		fprintf(fp, "no motifs\n");
		return;
	}
	for(i=0, li=list_get_next(motifs,NULL); li && i <= motifs->size; i++, li=list_get_next(motifs,li)) {
//			mtf=(Motif*)(li->p);
//			//fprintf(arg_get_fp("out_fp"),"id : %d  %d times.\n",li->val,*(int*)li->p);
//			p = (int *)(&(li->key));
//			fprintf(fp, "id : %d%d  (%p) ", *(p+1), *p, li->p);
//			motif_dump(fp, mtf, "");
			motif_id_print ((MotifID *)&(li->key), fp, "id : ", "");
			motif_dump(fp, (Motif*)(li->p), "");
		}
}

