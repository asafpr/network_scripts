#ifndef __NETWORK_H
#define __NETWORK_H


#include <stdio.h>
#include "mat.h"
#include "motif.h"

#define VRT_NAME_LEN 20

typedef struct _Edge{
	int	s;   					//source vertex
	int	t;   					//target vertex
	int	color; 				//color val
	struct _Edge *reverse;	//pointer to reverse edge									//ss	12.5
	int	profile;				//edge profile													//ss	12.5
}Edge;


typedef struct {
	char*	name;
	int	number;				//	numerical identifier of a network
	int	vertices_num;  	//	total number of vertices
	int	edges_num;     	//	total number of edges
	int	con_vertices_num; //	total connected vertices num 
	Mat*	mat;            	//	Matrix respresents the network
	Edge*	e_arr;      		//	edges array
	int*	indeg;  				//	in degree array (index i related node i)   
	int*	outdeg; 				//	out degree array (index i related node i)
	Edge	***edgs;				// array of array of pointers to edges					//ss	11.19
	int	*profs;				//	array indicating # of edges of each profile		//ss	11.15
	char	**vrt_name;			// array of vertex names. each name is a tring of length VRT_NAME_LEN+1	//ss	12.19
	int	colors;				//	number of colors
}Network;


int				color_is_suitable (int	current, int expected);
void 				dump_network (FILE *fp,Network *N);
int				duplicate_network(Network *SRC, Network **TRG_p, char *trg_name);
void				edge_color_add(list *e_list, int key, Edge *e);
void 				edge_dump (FILE *fp, Network *N, char *msg);
Edge *			edge_get (Network *N, int from, int to);
void				edge_profile_classify(Network *N);
int 				edge_switch_if_can (Network * N, Edge *edg1, Edge *edg2, int act);
void 				edge_switch_source (Network *N, int s, int told, int tnew, int dbg);
void 				edge_switch_target (Network *N, int s, int told, int tnew, int dbg);
void 				free_network_mem(Network *N);
int 				network_check (FILE *fp, Network *N);
void 				network_compare (FILE *fp, Network *N1, Network *N2);
int				network_construc_from_edges (Network *N, FILE* log_fp);
void 				network_dump (FILE *fp, Network *N);
int 				network_duplicate (Network *SRC, Network **TRG_p, char *trg_name, int trg_num);
void 				network_export_pajek (Network *N, FILE *fp);
void 				network_export_standard (Network *N, FILE *fp);
void 				network_free(Network *N);
int				network_generate_from_subset(Network *N, Network **SN, list *vrtx_set, int mtf_sz);
Network * 		network_init(char *name, int num, int vertices, int edges, int colors, int profiles);
int				network_load(Network **N_p, char* network_fname, int undirected_flag, int ts, FILE* log_fp);
void				network_motif_id(MotifID *id_p, Network *N, int colors, int pcolors);
void				network_size_by_color (Network *N, int *vrt, int *edg, int color);
void				profile_dump (FILE *fp, Network *N);
int				profile_out (int prof, int pcolors);
int				profile_in (int prof, int pcolors);


#endif

