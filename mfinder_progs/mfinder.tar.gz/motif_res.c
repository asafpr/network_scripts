#include <stdio.h>
#include <stdlib.h>
#include "common.h"
#include "list.h"
#include "mat.h"
#include "network.h"
#include "motif.h"
#include "motif_res.h"
#include "permutation.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	dump motif results to screen and to file pointer (fp parameter)
//	arguments:
//	FILE *fp				- output stream to which output is written (on top of stdout)
//	list* all_motifs		- list of entities of type Motif_res (full results) which are also to be presented (though they are
//							  sometimes not available due to being switched off because of processing time considerations).
//	int rnd_net_num	- number of random nets processed
//	int mtf_sz			- size of motifs analysed/presented
//	int actual_n_eff	- index of eff_arr used for actuall_n_eff
//	int stn_flag		- flag indicating whether to dump results (also) to stdout.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void dump_final_res(FILE *fp, list *all_motifs, int mtf_sz, int actual_n_eff)
{
	list_item *l_mtf;
	Motif_res *mtf_res;
	Neff_st eff;
	char*	prog="dump_final_res";

#if	DEBUG_TRACE > 1
	printf("%s: entered with fp=%p\n", prog, fp);
#endif

	if (fp) {

	//	do the reporting on 'all_motifs'
	//conc
	//Dump full motif ids list result to output file only if motif size <=4
		if (mtf_sz<=4 && all_motifs) {
			fprintf(fp,"\n\nFull list of motif size %d ids:\n\n", mtf_sz);
			fprintf(fp,"\t( Total num of different motifs size %d is : %d )\n\n",mtf_sz,all_motifs->size);

			fprintf(fp,"MOTIF\tCREAL\tCREAL\tCREAL\tCEFF\tCEFF\tCEFF\tUNIQ\tCRAND\n");
			fprintf(fp,"ID\t[mili]\tZSCORE\tPVAL\tVAL\tZSCORE\tPVAL\t\tSTATS\n");
			for(l_mtf=list_get_next(all_motifs,NULL); l_mtf!=NULL;l_mtf=list_get_next(all_motifs,l_mtf)) {
				mtf_res=(Motif_res*)l_mtf->p;
				eff = mtf_res->eff_arr[actual_n_eff];
				motif_id_print (&mtf_res->id, fp, "", "");
				fprintf(fp,"%.2f\t%.2f\t%.3f\t%.2f\t%.2f\t%.3f\t%d\t%.2f+-%.2f\n",
						mtf_res->conc_real,mtf_res->conc_real_zscore,mtf_res->conc_real_pval,
						eff.c_eff,eff.c_eff_zscore,eff.c_eff_pval,
						(int)mtf_res->unique_appear,
						mtf_res->conc_rand_mean, mtf_res->conc_rand_std_dev);
				fprintf(fp,"\n");
			}
			//counts
			fprintf(fp,"\n\nFull list of motif size %d ids:\n\n", mtf_sz);
			fprintf(fp,"\t( Total num of different motifs size %d is : %d )\n\n",mtf_sz,all_motifs->size);
	
			fprintf(fp,"MOTIF\tNREAL\tNREAL\tNREAL\tNEFF\tNEFF\tNEFF\tUNIQ\tNRAND\n");
			fprintf(fp,"ID\t\tZSCORE\tPVAL\tVAL\tZSCORE\tPVAL\t\tSTATS\n");
			for(l_mtf=list_get_next(all_motifs,NULL); l_mtf!=NULL;l_mtf=list_get_next(all_motifs,l_mtf)) {
				mtf_res=(Motif_res*)l_mtf->p;
				eff = mtf_res->eff_arr[actual_n_eff];
				motif_id_print (&mtf_res->id, fp, "", "");
				fprintf(fp,"%.1f\t%.2f\t%.3f\t%.2f\t%.2f\t%.3f\t%d\t%.2f+-%.2f\n",
						mtf_res->real_count,mtf_res->real_zscore,mtf_res->real_pval,
						eff.n_eff,eff.n_eff_zscore,eff.n_eff_pval,
						(int)mtf_res->unique_appear,
						mtf_res->rand_mean, mtf_res->rand_std_dev);
				fprintf(fp,"\n");
			}
		
		} else {
			fprintf(fp,"\n\nFull list of motif size not analyzeded size=%d results=%p\n\n", mtf_sz, all_motifs);
		}

		fprintf(fp,"\n");
		fflush(fp);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// free memory of a motifs results list
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void final_res_free(list *motif_res_lis)
{
	list_item *item;
	Motif_res *mtf_res;
	char*	prog="final_res_free";

#if	DEBUG_TRACE > 3
	printf("%s: entered to free final results\n", prog);
#endif

	if(motif_res_lis != NULL) {
		for(item=list_get_next(motif_res_lis,NULL);item!=NULL;item=list_get_next(motif_res_lis,item)) {
			if (item->p != NULL)	{
				mtf_res = (Motif_res*)item->p;
				if (mtf_res->eff_arr != NULL)
					myfree(mtf_res->eff_arr);
			}
		}
		list_free_mem(motif_res_lis);
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	calculate the following statistics of a Motif_res* 'mtf_res':
//		.rand_mean , .conc_rand_mean , .rand_std_dev , .conc_rand_std_dev
//	theis is done by looping through the Res_tbl* 'res_tbl' (which summarizes the motifs encountered in rnd_net_num random 
//	networks) and calculating the statistics from the occurances of the motif in each of the random networks.
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	motif_res_calc_deviation (Motif_res *mtf_res, void *rs_tbl, int rnd_net_num)
{
	int i;
	list_item *l_mtf;
	Motif *mtf;
	double counts_sum=0,x;
	double conc_sum=0,y;
	double sigma=0;
	double power;
	int	n;
	Res_tbl *res_tbl=(Res_tbl *)rs_tbl;
	char*	prog="motif_res_calc_deviation";
	
#if	DEBUG_TRACE > 3
	printf("%s: entered mtf_res=%p, res_tbl=%p, rnd_net_num=%d\n", prog, mtf_res, res_tbl, rnd_net_num);
#endif

	// accumulate for calculating counts mean val and concentration mean val
	n = 0;
	for(i=0; i<rnd_net_num; i++) {
		if( (l_mtf=list_get_by_key(res_tbl->rand_arr[i], (void*)&(mtf_res->id))) !=NULL) {		//ss	11.16
			n++;
			mtf=(Motif*)l_mtf->p;
			counts_sum += mtf->count;
			conc_sum += mtf->conc;
		}
	}

	// calculate counts mean val and concentration mean val
	if (n) {
		mtf_res->rand_mean = (double)counts_sum / (double)n;
		mtf_res->conc_rand_mean = (double)conc_sum / (double)n;
	} else {
		mtf_res->rand_mean = (double)0;
		mtf_res->conc_rand_mean = (double)0;
	}

	//calc counts standard deviation
	for(i=0; i<rnd_net_num; i++) {
		l_mtf=list_get_by_key(res_tbl->rand_arr[i], (void*)&(mtf_res->id));							//ss	11.16

		if (l_mtf==NULL)
			x=0;
		else {
			mtf=(Motif*)l_mtf->p;
			x=mtf->count;
		}
		if( (x-mtf_res->rand_mean) == 0)
			power = 0;
		else
			power=pow((double)(x - mtf_res->rand_mean), (double)2);
//		sigma += power/(double)(rnd_net_num-1);																//ss	12.20 deactivated
		sigma += power;																								//ss	12.20
	}
//	mtf_res->rand_std_dev=(double)sqrt(sigma);																//ss	12.20 deactivated
	if (rnd_net_num > 3)																								//ss	12.20
		mtf_res->rand_std_dev=(double)sqrt(sigma/(double)(rnd_net_num-1));							//ss	12.20
	else																													//ss	12.20
		mtf_res->rand_std_dev=(double)sqrt(sigma/(double)(rnd_net_num));								//ss	12.20

	sigma=0;
	//calc concentrations standard deviation
 	for(i=0; i<rnd_net_num; i++) {
		l_mtf=list_get_by_key(res_tbl->rand_arr[i], (void*)&(mtf_res->id));							//ss	11.16
		if (l_mtf==NULL)
			y=0;
		else {
			mtf=(Motif*)l_mtf->p;
			y=mtf->conc;
		}
		if( (y-mtf_res->conc_rand_mean) == 0)
			power = 0;
		else
			power=pow((double)(y - mtf_res->conc_rand_mean), (double)2);
		sigma += power/(double)(rnd_net_num-1);
	}
	mtf_res->conc_rand_std_dev=(double)sqrt(sigma);

#if	DEBUG_TRACE > 3
	printf("%s: returned\n", prog);
#endif
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	motif_res_calc_pval(Motif_res *mtf_res, void *rs_tbl, int rnd_net_num)
{
	int i,j;
	list_item *l_mtf;
	Motif *mtf;
	int real_pval=0;
	int real_conc_pval=0;
	Res_tbl *res_tbl=(Res_tbl *)rs_tbl;
	char*	prog="motif_res_calc_pval";

#if	DEBUG_TRACE > 3
	printf("%s: entered\n", prog);
#endif

	//calc statistics: real pval (real_pval and real_conc_pval) and effective pval (n_eff_pval and )
	for(i=0; i<rnd_net_num; i++) {
		if ( (l_mtf=list_get_by_key(res_tbl->rand_arr[i], (void*)&(mtf_res->id))) !=NULL) {

			mtf=(Motif*)l_mtf->p;
			if(mtf_res->real_count<=(double)(mtf->count))
				real_pval++;
			if(mtf_res->conc_real<=(double)(mtf->conc))
				real_conc_pval++;

			//Neff and Ceff pval for all neff methods
			for(j=1;j<=NEFF_METHODS_NUM;j++) {
				if(mtf_res->eff_arr[j].n_eff<=(double)(mtf->count))
					mtf_res->eff_arr[j].n_eff_pval++;
				if(mtf_res->eff_arr[j].c_eff<=(double)(mtf->conc))
					mtf_res->eff_arr[j].c_eff_pval++;;
			}
		}
	}
	mtf_res->real_pval = (double)real_pval / (double)rnd_net_num;
	mtf_res->conc_real_pval = (double)real_conc_pval / (double)rnd_net_num;
	for(j=1;j<=NEFF_METHODS_NUM;j++) {
		mtf_res->eff_arr[j].n_eff_pval=mtf_res->eff_arr[j].n_eff_pval/(double)rnd_net_num;
		mtf_res->eff_arr[j].c_eff_pval=mtf_res->eff_arr[j].c_eff_pval/(double)rnd_net_num;
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	motif_res_calc_zscore(Motif_res *mtf_res)
{
	int i;
	char*	prog="motif_res_calc_zscore";

#if	DEBUG_TRACE > 3
	printf("%s: entered\n", prog);
#endif

	if (mtf_res->rand_std_dev > 0) {
		mtf_res->real_zscore = (double)(mtf_res->real_count - mtf_res->rand_mean) / (double)mtf_res->rand_std_dev;
		mtf_res->conc_real_zscore = (double)(mtf_res->conc_real - mtf_res->conc_rand_mean) 
			/ (double)mtf_res->conc_rand_std_dev;
		//Neff and Ceff for all Neff methods
		for(i=1;i<=NEFF_METHODS_NUM;i++) {
			mtf_res->eff_arr[i].n_eff_zscore = (double)(mtf_res->eff_arr[i].n_eff - mtf_res->rand_mean) 
			/ (double)mtf_res->rand_std_dev;
			mtf_res->eff_arr[i].c_eff_zscore = (double)(mtf_res->eff_arr[i].c_eff - mtf_res->conc_rand_mean) 
			/ (double)mtf_res->conc_rand_std_dev;
		}
	} else {
		mtf_res->real_zscore = 0;
		mtf_res->conc_real_zscore = 0;
		for(i=1;i<=NEFF_METHODS_NUM;i++) {
			mtf_res->eff_arr[i].n_eff_zscore = 0;
			mtf_res->eff_arr[i].c_eff_zscore = 0;
		}
	}
#if	DEBUG_TRACE > 3
	printf("%s: returned\n", prog);
#endif

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//calculate N effective and C effective according to all Neff methods
//N effective is realted to counts
//C effective is realted to concentrations
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	motif_res_calc_n_eff(Motif_res *mtf_res, list *res_sub_mtf, int colors)
{
	int occurs,i;
	MotifID sub_id;
	double mul=1;
	list *subid_list;
	Motif_res *sub_mtf_res_st;
	list_item *l_sub_id, *l_sub_id_res;
	double *n_eff_arr; //n_eff factors array
	double *c_eff_arr; //c_eff factors_array
	double n_rand_real_ratio,n_min_ratio=INFINITY;
	double c_rand_real_ratio,c_min_ratio=INFINITY;
	int	pcolors = (int)pow(2,colors);
	char*	prog="motif_res_calc_n_eff";

#if	DEBUG_TRACE > 3
	printf("%s: entered\n", prog);
#endif

	n_eff_arr=(double*)mycalloc(NEFF_METHODS_NUM+1,sizeof(double));
	c_eff_arr=(double*)mycalloc(NEFF_METHODS_NUM+1,sizeof(double));

	n_eff_arr[1]=1;
	n_eff_arr[2]=1;
	n_eff_arr[3]=1;
	n_eff_arr[4]=0; //sum of ratios -> need to be init to zero
	n_eff_arr[5]=1;
	
	c_eff_arr[1]=1;
	c_eff_arr[2]=1;
	c_eff_arr[3]=1;
	c_eff_arr[4]=0; //sum of ratios -> need to be init to zero
	c_eff_arr[5]=1;


	// if real count is zero then Neff is zero too
	if(mtf_res->real_count==0) {
		for(i=1;i<=NEFF_METHODS_NUM;i++) {
			n_eff_arr[i]=0;
			c_eff_arr[i]=0;
		}
	}
	else {
		// Neff1 = Nreal(A)* mul of all sub circuits B (Nrand(B)/Nreal(B))
		// Neff2 = Nreal(A)* mul of all sub circuits B (Nrand(B)/Nreal(B)) - no repeats
		// Neff3 = Nreal(A)* min ratio of all sub circuits B (Nrand(B)/Nreal(B))
		// Neff4 = Nreal(A)* sum of all sub circuits B (Nrand(B)/Nreal(B))
		// Neff5 = Nreal(A)* subcircuit B after removing min connectivy node (Nrand(B)/Nreal(B))

		//Ceff[1-5] is the same just that it relates concentrations and not counts

 		//pass through all subsets size-1
		subid_list = get_mtf_subid(&(mtf_res->id), arg_get_int("mtf_sz"), colors);
		for(l_sub_id=list_get_next(subid_list,NULL); l_sub_id !=NULL; l_sub_id=list_get_next(subid_list,l_sub_id)) {
			list_element_key_get (l_sub_id, (void *)&sub_id);
			//num of occurances of this subid in the id
			occurs=*(int*)l_sub_id->p;
			if(res_sub_mtf !=NULL) {
				if( (l_sub_id_res=list_get_by_key(res_sub_mtf,&sub_id)) != NULL) {
					sub_mtf_res_st = (Motif_res*)l_sub_id_res->p;
					n_rand_real_ratio=(double)sub_mtf_res_st->rand_mean/(double)sub_mtf_res_st->real_count;
					c_rand_real_ratio=(double)sub_mtf_res_st->conc_rand_mean/(double)sub_mtf_res_st->conc_real;
					//eff2 -  consider every submotif only once
					//even if the subcircuit occurs few times in the circuit
					n_eff_arr[2]*=n_rand_real_ratio;
					c_eff_arr[2]*=c_rand_real_ratio;

					//for eff3 - consider min ratio only
					if((double)n_rand_real_ratio < (double)n_min_ratio)
						n_min_ratio = n_rand_real_ratio;
					if((double)c_rand_real_ratio < (double)c_min_ratio)
						c_min_ratio = c_rand_real_ratio;

					for (i=0;i<occurs;i++) {
						//eff1 mul of all subcircuitss
						n_eff_arr[1]*=(double)n_rand_real_ratio;
						c_eff_arr[1]*=(double)c_rand_real_ratio;
						//eff4 sum of all subcircuits
						n_eff_arr[4]+=(double)n_rand_real_ratio;
						c_eff_arr[4]+=(double)c_rand_real_ratio;
					}
					//eff3 is the min ratio rand real of all subcircuits
					n_eff_arr[3]=n_min_ratio;
					c_eff_arr[3]=c_min_ratio;
				}
			}
		}
		list_free_mem(subid_list);
		//free((void*)subid_list);
		
		//eff_5 min connectivity N_eff approach
		
		//get id of submotif derived by removing min conn vertex from 'mtf_res'
		get_mtf_subid_min_con_vrtx_less(&sub_id, &(mtf_res->id), arg_get_int("mtf_sz"), colors);
		if( (l_sub_id_res=list_get_by_key(res_sub_mtf,&sub_id)) != NULL) {					//ss	11.16
			sub_mtf_res_st = (Motif_res*)l_sub_id_res->p;
			n_eff_arr[5]=(double)sub_mtf_res_st->rand_mean/(double)sub_mtf_res_st->real_count;
			c_eff_arr[5]=(double)sub_mtf_res_st->conc_rand_mean/(double)sub_mtf_res_st->conc_real;
		}
	}
	//update Neff results in the mtf_res structure
	for(i=1;i<=NEFF_METHODS_NUM;i++) {
		mtf_res->eff_arr[i].n_eff=(double)((double)mtf_res->real_count *(double)n_eff_arr[i]);
		mtf_res->eff_arr[i].c_eff=(double)((double)mtf_res->conc_real *(double)c_eff_arr[i]);
	}
	myfree(n_eff_arr);
	myfree(c_eff_arr);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	frees memory of elements hanging on the motif result and the motif result itself
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int motif_res_delete (Motif_res *mr)
{
	int rtn = 0;

	if(mr) {
		if (mr->eff_arr)
			myfree(mr->eff_arr);
		myfree(mr);
	}
	return rtn;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// dump the Motif_res list 'res' to stream fp
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void motif_res_dump (FILE *fp, void *NN, list *res, int rnd_net_num, int colors)
{
	list_item	*l_mtf;
	Motif_res	*mtf_res;
	Neff_st 		eff;
	int			found;
	Network		*N = (Network *)NN;
	int			pr;				//	# of edges in current profile
	int			stat_motif_distribution = arg_get_int("stat_motif_distribution");
	char*	prog="motif_res_dump";

	if (!res) {
		printf("%s: entered with null results. returned upon entry\n", prog);
		return;
	}

#if	DEBUG_TRACE > 3
	printf("%s: entered with a lists result of size %d\n", prog, res->size);
#endif

//	present motif distribution, if required
	if (stat_motif_distribution >= 0) {

		fprintf(fp,"\n\tMotif frequency table");
		if (stat_motif_distribution > 1)
			fprintf(fp," for motifs that appear at least %d times in the real network", stat_motif_distribution);
		fprintf(fp,"\n");
		fprintf(fp,"\tNote that self isomorphic motifs are counted more than once\n\n");
		fprintf(fp,"\t Real");
		if (arg_get_int("rnd_net_num")>1)
			fprintf(fp,"\t RndAvg\t RndStD\t Zscore");
		if (arg_get_int("rnd_net_num")>=10)
			fprintf(fp,"\t Pvalue");
		fprintf(fp,"\t Motif");
		fprintf(fp,"\n");

		for(l_mtf=list_get_next(res,NULL); l_mtf!=NULL; l_mtf=list_get_next(res,l_mtf)) {
			mtf_res=(Motif_res*)l_mtf->p;
			if (stat_motif_distribution > 1 && mtf_res->real_count < stat_motif_distribution) 
				continue;
			fprintf(fp,"\t%5.0f", mtf_res->real_count);
			if (arg_get_int("rnd_net_num")>1) {
				if (mtf_res->rand_mean > 10) 
					fprintf(fp,"\t%7.0f\t", mtf_res->rand_mean);
				else 
					fprintf(fp,"\t%7.1f\t", mtf_res->rand_mean);
				fprintf(fp,"%7.1f\t", mtf_res->rand_std_dev);
				if (mtf_res->rand_std_dev > EPSILON) fprintf(fp,"%7.1f\t", mtf_res->real_zscore);
				else fprintf(fp,"%s\t", "  ---  ");
				if (arg_get_int("rnd_net_num")>=10)
					fprintf(fp,"%7.4f\t", mtf_res->real_pval);
			}
			motif_matrix_dump (fp, &(mtf_res->id), 1, colors);
			motif_id_print (&(mtf_res->id), fp, "\t", " ");
			fprintf(fp,"\n");
		}
		fprintf(fp,"\n");
	}

#if	DEBUG_TRACE > 3
	printf("%s: returned\n", prog);
#endif

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// dump the significant Motif_res list 'res' to stream fp
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void motif_res_dump_significnat (FILE *fp, void *NN, list *res, int rnd_net_num, int colors)
{
	list_item	*l_mtf;
	Motif_res	*mtf_res;
	Neff_st 		eff;
	int			found;
	Network		*N = (Network *)NN;
	int			pr;				//	# of edges in current profile
	int			stat_motif_distribution = arg_get_int("stat_motif_distribution");
	char*	prog="motif_res_dump";

	if (!res) {
		printf("%s: entered with null results. returned upon entry\n", prog);
		return;
	}

#if	DEBUG_TRACE > 3
	printf("%s: entered with a lists result of size %d\n", prog, res->size);
#endif

	fprintf(fp,"The following 'significant' motifs were found (out of %d motifs altogether):\n\n", res->size);
	//according to concentrations
	fprintf(fp,"Criteria taken : Creal Zscore > %.2f\n",arg_get_double("zfactor_th"));
	fprintf(fp,"                 Ceff method : %d\n", arg_get_int("actual_n_eff"));
	fprintf(fp,"                 Mfactor > %.2f\n",arg_get_double("mfactor_th"));
	fprintf(fp,"                 Pval,Uniquness ignored\n\n");
			
	fprintf(fp,"MOTIF\tCREAL\tCREAL\tCREAL\tCEFF\tCEFF\tCEFF\tUNIQ\tCRAND\n");
	fprintf(fp,"ID\t[mili]\tZSCORE\tPVAL\tVAL\tZSCORE\tPVAL\t\tSTATS\n");
			
	found = 0;
	for(l_mtf=list_get_next(res,NULL); l_mtf!=NULL; l_mtf=list_get_next(res,l_mtf)) {
		mtf_res=(Motif_res*)l_mtf->p;
		eff = mtf_res->eff_arr[arg_get_int("actual_n_eff")];
		//if short printing format output only motifs that pass the threshold tests
		if( (mtf_res->conc_real_zscore > arg_get_double("zfactor_th")) 
			&& (mtf_res->conc_real >=mtf_res->conc_rand_mean*arg_get_double("mfactor_th")) ) {
			motif_id_print (&(mtf_res->id), fp, "", "\t");
			fprintf(fp,"%.2f\t%.2f\t%.3f\t%.2f\t%.2f\t%.3f\t%d\t%.2f+-%.2f\n",
				mtf_res->conc_real,mtf_res->conc_real_zscore,mtf_res->conc_real_pval,
				eff.c_eff,eff.c_eff_zscore,eff.n_eff_pval,
				(int)mtf_res->unique_appear,
				mtf_res->conc_rand_mean, mtf_res->conc_rand_std_dev);
			motif_matrix_dump (fp, &(mtf_res->id), 2, colors);
			fprintf(fp,"\n");
			found++;
		}
	}
	fprintf(fp,"\n");
	if (!found)
		fprintf(fp,"no motifs met the criteria\n\n");

	fprintf(fp,"Criteria taken : Nreal Zscore > %.2f\n",arg_get_double("zfactor_th"));
	fprintf(fp,"                 Neff method : %d\n", arg_get_int("actual_n_eff"));
	fprintf(fp,"                 Mfactor > %.2f\n",arg_get_double("mfactor_th"));
	fprintf(fp,"                 Pval,Uniquness ignored\n\n");
		
	fprintf(fp,"MOTIF\tNREAL\tNREAL\tNREAL\tNEFF\tNEFF\tNEFF\tUNIQ\tNRAND\n");
	fprintf(fp,"ID\t\tZSCORE\tPVAL\tVAL\tZSCORE\tPVAL\t\tSTATS\n");
			
	found = 0;
	for(l_mtf=list_get_next(res,NULL); l_mtf!=NULL;	l_mtf=list_get_next(res,l_mtf)) {
		mtf_res=(Motif_res*)l_mtf->p;
		eff = mtf_res->eff_arr[arg_get_int("actual_n_eff")];
		//if short printing format output only motifs that pass the threshold tests
		if( (mtf_res->real_zscore > arg_get_double("zfactor_th")) 
			&& (mtf_res->real_count >=mtf_res->rand_mean*arg_get_double("mfactor_th")) ) {
			motif_id_print (&(mtf_res->id), fp, "", "\t");
			fprintf(fp,"%.0f\t%.2f\t%.3f\t%.0f\t%.2f\t%.3f\t%d\t%.2f+-%.2f\n",
				mtf_res->real_count,mtf_res->real_zscore,mtf_res->real_pval,
				eff.n_eff,eff.n_eff_zscore,eff.n_eff_pval,
				(int)mtf_res->unique_appear,
				mtf_res->rand_mean, mtf_res->rand_std_dev);
			motif_matrix_dump(fp, &(mtf_res->id), 2, colors);
			fprintf(fp,"\n");
			found++;
		}
	}
	fprintf(fp,"\n");
	if (!found)
		fprintf(fp,"no motifs met the criteria\n\n");

#if	DEBUG_TRACE > 3
	printf("%s: returned\n", prog);
#endif

}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	initializes a motif result
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
Motif_res * motif_res_ini ()
{
	Motif_res	*mtf_res;
	Neff_st		*eff;
	int			i;

	mtf_res=(Motif_res*)mycalloc(1,sizeof(Motif_res));
	mtf_res->eff_arr=(Neff_st*)mycalloc(NEFF_METHODS_NUM+1,sizeof(Neff_st));

//	mtf_res->id = 0;
	memset (&mtf_res->id, 0, sizeof(MotifID));
	mtf_res->real_count = (double)0;
	mtf_res->real_pval = (double)0;
	mtf_res->real_zscore = (double)0;
	mtf_res->conc_real = (double)0;
	mtf_res->conc_real_pval = (double)0;
	mtf_res->conc_real_zscore = (double)0;
	eff = mtf_res->eff_arr;
	for (i=0; i<NEFF_METHODS_NUM+1; i++) {
		eff[i].n_eff = (double)0;
		eff[i].n_eff_zscore = (double)0;
		eff[i].n_eff_pval = (double)0;
		eff[i].c_eff = (double)0;
		eff[i].c_eff_zscore = (double)0;
		eff[i].c_eff_pval = (double)0;
	}
	mtf_res->unique_appear = 0;
	mtf_res->rand_mean = (double)0;
	mtf_res->rand_std_dev = (double)0;
	mtf_res->conc_rand_mean = (double)0;
	mtf_res->conc_rand_std_dev = (double)0;

	return mtf_res;
}
