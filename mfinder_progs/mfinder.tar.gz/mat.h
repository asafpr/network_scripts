#ifndef __MAT_H
#define __MAT_H


#include <stdio.h>
#include "list.h"

/************************ DEFS ************************/

#define FULL          0
#define SPARSE        1

//maximum size of full matrix representation
#define MAT_MAX_SIZE  6

typedef struct {
	int size; //size of matrix (num of rows/collumns)
	char *m;  //full matrix - 2 dim array of chars
}Matrix;

typedef struct{
	list *to;
	list *from;
}Edges_lists;

typedef struct {
	int size; //size of matrix (num of rows/collumns)
	Edges_lists *m; //sparse matrix - array of lists of edges
}SparseMatrix;

typedef struct {
	int type;  //FULL or SPARSE
	union {
	Matrix *full; //full matrix 
	SparseMatrix *spr; //sparse matrix
	};
}Mat;


/************************ MACROS ************************/


//M should be of type Matrix 
#define MTRX(M,i,j)      ( *(char*)(M->m+((i-1)*(M->size))+(j-1)) )


/************************ PROTOTYPES ************************/
// Matrix functions
void 				clear_matrix(Matrix *M);
void 				free_matrix(Matrix *M);
Matrix*			init_matrix(int size);
void 				matrix_dump(FILE *fp,Matrix *M, char *name, int dim);
void				matrix_free (Matrix *M);

// SparseMatrix functions
void 				dump_spr_matrix(FILE *fp,Mat *M, char *name);
void 				free_spr_matrix(SparseMatrix *M);
SparseMatrix*	init_spr_matrix(int size);

//general matrix functions
//void			mat_edges_switch (Mat *mat, int s1, int t1, int s2, int t2);
int				mat_check (Mat *mat, int vertices, int edges);
void				mat_dump (FILE *fp, Mat *mat, char *name);
void				MatAsgn(Mat *mat, int i, int j, int val);
void				MatFree(Mat *mat);
int				MatGet(Mat *mat,int i, int j);
int				MatInit(Mat **mat_p,int size);


//MACROS

//#define MAT(N,i,j)      ( *(char*)(N->m+((i-1)*(N->vertices_num))+(j-1)) )








#endif
