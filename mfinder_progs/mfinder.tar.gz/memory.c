#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include "switches.h"
#include "utilities.h"

//	the program can run in 'memory control' mode. in such mode the program maintains a list of allocated memory and
//	a. confirms that any deallocated memory refers to allocated memory. in case this is not the case the situation
//		is reported and the program halts.
//	b.	if a high level of memory control is required - any memory status (call to mymemory) includes a list of all
//		allocated memory (that has not been deallocated).
//
// to activate memory control define MEMCONTROL. setting it to a value hugher then 5 produces the effect mentioned in
//	b. above

//#define	MEMCONTROL 1
//#define	MEMCONTROL 6

// allocation constants
VERYLONGINT	allocs=0;
VERYLONGINT	alloc_req_size=0;
VERYLONGINT	alloc_act_size=0;
VERYLONGINT	deallocs=0;
VERYLONGINT	dealloc_size=0;
VERYLONGINT	tracealloc = 0;
VERYLONGINT	alloc_count = 0;

#ifdef MEMCONTROL
typedef struct _mlist_item{
	int val;
	long lng;
	struct _mlist_item *next;
}mlist_item;

typedef struct{
	int size;
	mlist_item *l;
}mlist;

mlist	memcontrol;				//ss
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	setting memory tracking operations
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void myalloc_track(int flag1, int flag2)
{
	tracealloc=flag1;
	alloc_count=flag2;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	initialize my... memory operations
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void mymem_init (int flag1, int flag2, char	*msg)
{

myalloc_track(flag1, flag2);

#ifdef	MEMCONTROL
	memcontrol.l=NULL;
	memcontrol.size=0;

	printf("%s\n", msg);
#endif

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	free allocated memory
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void myfree(void *p)
{
#ifdef MEMCONTROL
	mlist_item *chunk, *prv;
	int found=0;
	
//	printf("freeing memory %p %ld\n", p, p);
	for (prv=NULL, chunk=memcontrol.l; chunk!=NULL; prv=chunk, chunk=chunk->next) {
		if ((long)p==chunk->lng) {
			found=1;
			break;
		}
	}
	if (!found) {
		printf("requested release of %p which was not allocated\n", p);
		exit(-1);
	}
	memcontrol.size--;
	if (prv==NULL) {
		memcontrol.l = chunk->next;
	} else {
		prv->next = chunk->next;
	}
	free(chunk);
#endif

	if (alloc_count) {
		deallocs++;
		dealloc_size+=pointer_size(p);
	}
	if (tracealloc)
		printf("freeing %p size %d\n", p, pointer_size(p));

	free(p);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// allocate memory
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void *myalloc(int size)
{
//	void	*p;
	int	*p;
	int	*q;
	int	*rtn;
#ifdef MEMCONTROL
	mlist_item *chunk, *prv, *nxt;
#endif

	if (alloc_count) {
		allocs++;
		alloc_req_size+=size;
	}
//	p = malloc(size);
	p = (int *)malloc(size);
	rtn = p;

	if (alloc_count)
		alloc_act_size+=pointer_size(rtn);

	if (tracealloc)
		printf("allocating %p %d/%d\n", rtn, size, pointer_size(rtn));

#ifdef MEMCONTROL
//	printf("allocating memory of size %d\n", size);
	memcontrol.size++;
	chunk = malloc(sizeof(mlist_item));
	chunk->val=allocs;
	chunk->lng=(long)rtn;
	chunk->next=NULL;
	for (prv=NULL, nxt=memcontrol.l; nxt!=NULL; prv=nxt, nxt=nxt->next) {
//	printf("prv=%p nxt=%p\n", prv, nxt);
	}
	if (prv==NULL) {
		memcontrol.l = chunk;
	} else {
		prv->next = chunk;
	}
#endif
	return rtn;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// allocate memory in 'calloc' style
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void *mycalloc(int many, int size)
{
	return myalloc (many * size);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	producing a complete memory status report
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void mymemory (char *msg)
{
#ifdef MEMCONTROL
	mlist_item *chunk;
#endif
	printf("memory de/allocation status %s:\n", msg);
//	printf("allocs=%d alloc_req_size=%d alloc_act_size=%d deallocs=%d dealloc_size=%d\n", 
//	allocs, alloc_req_size, alloc_act_size, deallocs, dealloc_size);
	verylongint_print(stdout, allocs,         "allocs=", " ");
	verylongint_print(stdout, alloc_req_size, "alloc_req_size=", " ");
	verylongint_print(stdout, alloc_act_size, "alloc_act_size=", " ");
	verylongint_print(stdout, deallocs,       "deallocs=", " ");
	verylongint_print(stdout, dealloc_size,   "dealloc_size=", "\n");
#if MEMCONTROL > 5
	for (chunk=memcontrol.l; chunk!=NULL; chunk=chunk->next) {
		printf("allocated: %d, %p\n", chunk->val, chunk->lng);
	}
#endif

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	short presentation of memory status
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void mymemory_check (FILE *fp, char *msg, int type)
{
#ifdef MEMCONTROL
	mlist_item *chunk;
#endif

	if (!fp)
		return;

	switch (type) {
	case 2:	//full report
		fprintf(fp, "memory de/allocation status %s:\n", msg);
//		fprintf(fp, "allocs=%d alloc_req_size=%d alloc_act_size=%d deallocs=%d dealloc_size=%d\n", 
//		allocs, alloc_req_size, alloc_act_size, deallocs, dealloc_size);
		verylongint_print(fp, allocs,         "allocs=", " ");
		verylongint_print(fp, alloc_req_size, "alloc_req_size=", " ");
		verylongint_print(fp, alloc_act_size, "alloc_act_size=", " ");
		verylongint_print(fp, deallocs,       "deallocs=", " ");
		verylongint_print(fp, dealloc_size,   "dealloc_size=", "\n");
#if MEMCONTROL > 5
		for (chunk=memcontrol.l; chunk!=NULL; chunk=chunk->next) {
			fpprintf(fp, "allocated: %d, %p\n", chunk->val, chunk->lng);
		}
#endif
		break;
	case 1:	//short report
		if (allocs == deallocs && alloc_req_size <= dealloc_size && dealloc_size <= alloc_act_size) {
			fprintf(fp, "memory de/allocation status %s is perfect: ", msg);
			verylongint_print(fp, allocs,   "", " allocations & ");
			verylongint_print(fp, deallocs, "", " deallocs\n");
		} else if (allocs > deallocs && alloc_req_size <= dealloc_size && dealloc_size <= alloc_act_size) {
//			fprintf(fp, "memory de/allocation status %s: diff = %d (%d allocations & %d deallocations)\n", 
//			msg, allocs-deallocs, allocs, deallocs);
			fprintf(fp, "memory de/allocation status %s: ", msg);
			verylongint_print(fp, allocs-deallocs, "diff = ", " (");
			verylongint_print(fp, allocs, "", " allocations & ");
			verylongint_print(fp, deallocs, "", " deallocs)\n");
		} else {
			fprintf(fp, "memory de/allocation status %s problem:\n", msg);
//			fprintf(fp, "allocs=%d alloc_req_size=%d alloc_act_size=%d deallocs=%d dealloc_size=%d\n", 
//			allocs, alloc_req_size, alloc_act_size, deallocs, dealloc_size);
			verylongint_print(fp, allocs,         "allocs=", " ");
			verylongint_print(fp, alloc_req_size, "alloc_req_size=", " ");
			verylongint_print(fp, alloc_act_size, "alloc_act_size=", " ");
			verylongint_print(fp, deallocs,       "deallocs=", " ");
			verylongint_print(fp, dealloc_size,   "dealloc_size=", "\n");
		}
		break;
	default:
		if ( !(allocs >= deallocs && alloc_req_size <= dealloc_size && dealloc_size <= alloc_act_size)) {
			fprintf(fp, "memory de/allocation status %s problem:\n", msg);
//			fprintf(fp, "allocs=%d alloc_req_size=%d alloc_act_size=%d deallocs=%d dealloc_size=%d\n", 
//			allocs, alloc_req_size, alloc_act_size, deallocs, dealloc_size);
			verylongint_print(fp, allocs,         "allocs=", " ");
			verylongint_print(fp, alloc_req_size, "alloc_req_size=", " ");
			verylongint_print(fp, alloc_act_size, "alloc_act_size=", " ");
			verylongint_print(fp, deallocs,       "deallocs=", " ");
			verylongint_print(fp, dealloc_size,   "dealloc_size=", "\n");
		}
		break;
	}

}
