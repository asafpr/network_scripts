#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include "switches.h"
#include "common.h"
#include "list.h"
#include "mat.h"
#include "network.h"

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	Check whether a network has more of a bipartiate structure then expected randomly
//	i.e. if s->t & s->u & v->t imply, more then randomly, that v->u
//	the analysis is performed only for a single color.
//	arguments:
//	Network *N		-	network to be analysed
//	FILE *f			-	output file. If not null the results of the analysis are written here
//	int color		-	the color to be analysed
//	int *success	-	if not a null pointer, it receives 'bipartiate' - the number of bipartiate quadrouples
//							as of 3/2003 called only with null pointer
//	int *quad		-	if not a null pointer, it receives 'situations' - the number of  quadrouples
//							as of 3/2003 called only with null pointer
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static void bipartiate_check(Network *N, FILE *f, int color, int *success, int *quad)
{
	int	s,t,u,v;	//	node indexes
	int	i;
	int	situations = 0;
	int	bipartiate = 0;
	int	colr;
	Mat 	*M;
	Edges_lists	*el;

	list_item *sto, *tfrom;
	char *prog="bipartiate_check";

#if	DEBUG_TRACE > 4
	printf("%s: entered with %p, %p\n", prog, N, f);
#endif

	M = N->mat;
	el = M->spr->m;

	for(i=1;i<=N->edges_num;i++) {

		s=N->e_arr[i].s;
		t=N->e_arr[i].t;
		colr = MatGet(M,s,t);
		if (!color_is_suitable (colr, color))
			continue;

		for (sto=list_get_next (el[s].to, NULL); sto; sto=list_get_next(el[s].to, sto)) {
			u = sto->val;
			colr = MatGet(M,s,u);
			if (u != t && color_is_suitable (colr, color)) {
				for (tfrom=list_get_next (el[t].from, NULL); tfrom; tfrom=list_get_next(el[t].from, tfrom)) {
					v = tfrom->val;
					colr = MatGet(M,v,t);
					if (v != s && color_is_suitable (colr, color)) {
						situations++;
						colr = MatGet(M,v,u);
						if (color_is_suitable (colr, color)) 
							bipartiate++;
					}
				}
			}
		}
	}

	if (f)
		fprintf (f, "%s: Network '%s' %d/%d quadrouples(%5.1f \%) fulfil the bipartiate condition\n", 
		prog, N->name, bipartiate, situations, bipartiate*100./situations);

	if (success)
		*success = bipartiate;
	if (quad)
		*quad = situations;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	Check whether a network has more of a bipartiate structure then expected randomly
//	i.e. if s->t & s->u & v->t imply, more then randomly, that v->u
//	the actual work is performed by the static routine 'bipartiate_check'
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void bipartiate_analysis (Network *N, FILE *f, int color, int *success, int *quad)
{
	char *prog="bipartiate_analysis";

#if	DEBUG_TRACE > 4
	printf("%s: entered with %p, %p, %p, %p\n", prog, N, f, success, quad);
#endif

#ifdef TEST_SUITABLE_COLOR
	printf ("0, 0, %d\n", color_is_suitable (0,0));
	printf ("1, 0, %d\n", color_is_suitable (1,0));
	printf ("2, 0, %d\n", color_is_suitable (2,0));
	printf ("3, 0, %d\n", color_is_suitable (3,0));
	printf ("0, 1, %d\n", color_is_suitable (0,1));
	printf ("1, 1, %d\n", color_is_suitable (1,1));
	printf ("2, 1, %d\n", color_is_suitable (2,1));
	printf ("3, 1, %d\n", color_is_suitable (3,1));
	printf ("0, 2, %d\n", color_is_suitable (0,2));
	printf ("1, 2, %d\n", color_is_suitable (1,2));
	printf ("2, 2, %d\n", color_is_suitable (2,2));
	printf ("3, 2, %d\n", color_is_suitable (3,2));
#endif

	bipartiate_check(N, f, color, success, quad);

#if	DEBUG_TRACE > 4
	printf("%s: returned\n", prog);
#endif

	return;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	complementary_features_analysis
//	generate a complementation graphs and analyse them.
//	the complementation graphs are generasted using:
//	1. Vrtx - number of vertices in the generated net. 
//		This is taken as the number of vertices in the input net N.
//	2. Plrf - size of the set of polar features in the generated complementary-feature net. 
//		This number is chosen randomly in the range 0.5-2 * number of vertices in N.
//	3. Draw - number of times polar features are drawn (randomly) and assigned to vertices. 
//		This number is fitted so that it is the first number of draws where the number of edges in the resulting 
//		graph exceeds the number of edges in N. 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	complementary_features_analysis (Network *N, FILE *fp, int rnd_net_num)
{
	int	i, j, k;
	Network	*RN;
	int	vrtx[1+COLORS];
	int	edges[1+COLORS];
	int	edge[1+COLORS];
	int	color;
	int	iterrations=4;
	double	factor;
	int		vrt,  edg,  drw;		//	actual values of random network
	double	svrt, sedg, sdrw;		//	sum (& mean) of values of random network
	int		qud,   suc;				// values returned from bipartiate analysis
	double	squd,  ssuc;			// sum (& mean) of values returned from bipartiate analysis
	int	quiet_mode = arg_get_int("quiet_mode");
	char	*prog="complementary_features_analysis";

#if	DEBUG_TRACE > 0
	printf("%s: entered\n", prog);
#endif

	for (color=0; color<1+COLORS; color++) 
		bipartiate_analysis(N, fp, color, NULL, NULL);
	fprintf (fp, "bipartiate analysis completed ----------------------\n");

//	calculate number of vertices and edges;
	for (color=0; color<1+COLORS; color++) {
		network_size_by_color (N, &vrtx[color], &edges[color], color);
		edge[color] = FALSE;
		if (color == 2) {
			edges[color] /= 2;		//	<<	this assumes that color 2 indicates edges (and not arcs)
			edge[color] = TRUE;
		}
		fprintf (fp, "The input network has %d vertices and %d %s of color %d\n", 
		vrtx[color], edges[color], edge[color] ? "edges" : "arcs", color);
	}

//	generate random complementation networks and analyze them
	for (j=0; j<1+COLORS; j++) {
//		if (!i%10 && !quiet_mode)
//			printf ("doing complementation analysis on random network %d\n", i+1);
		for (i=0; i<rnd_net_num; i++) {
			factor = 0.5+i*1./rnd_net_num;
			svrt = 0.; sedg = 0.; sdrw = 0.; squd = 0.; ssuc = 0.;
			for (k=0; k<iterrations; k++) { 
				gen_rand_network_complementation(&RN, vrtx[j], edges[j], (int) (vrtx[j]*factor), edge[j], fp, 
					&vrt, &edg, &drw);
				svrt += vrt; sedg += edg; sdrw += drw;
				bipartiate_analysis(RN, NULL, 1, &suc, &qud);
				squd += qud; ssuc += suc;
				network_free(RN);
			}
			fprintf (fp, "complementation anal:");
			fprintf (fp, " %d/%.0f vertices %d/%.0f %s",
			vrtx[j], svrt/iterrations, edges[j], sedg/iterrations, edge[j] ? "edges" : "arcs");
			fprintf (fp, " %d features %.0f draws - bip-quad %.0f/%.0f (%.0f\%)\n",
			(int) (vrtx[j]*factor), sdrw/iterrations, ssuc/iterrations, squd/iterrations, ssuc/squd*100);
		}
	}
}

