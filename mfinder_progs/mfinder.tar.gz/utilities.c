#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include <fcntl.h>
#include "arguments.h"
#include "utilities.h"

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// dump run time measurement results
//	arguments:
//	fp - file pointer to dump to
// text to print 
// runtime structure to dump time measuremnt from
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	dump_time_measure(FILE* fp,char *text, Runtime *runtime)
{
	double run_time = runtime->elapsed;	

	if (runtime->elapsed > 3600) {
		//display message in hours
		run_time /=(double)3600;
		fprintf(fp,"\n (%s %6.2f hours.)\n", text, run_time);
	}
	else if (run_time > 60) {
		//display message in minutes 
		run_time /=(double)60;
		fprintf(fp,"\n (%s %6.2f minutes).\n", text, run_time);
	}
	else {
		//display message in seconds
		fprintf(fp,"\n (%s %6.1f seconds.)\n", text, run_time );
	}
}	

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
FILE * myfopen (char *file_name, char * type)
{
	FILE *fp;
        fp = fopen64(file_name,type);
	if (fp == NULL)
		printf ("file '%s' cannot be opened with type %s\n", file_name, type);
//	else 
//		printf ("opened file %s with type %s, pointer %p\n", file_name, type, fp);
	return fp;

}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void myfopenw_using_arg (char *arg_file_name, char *arg_fp)
{
	FILE	*fp;
	fp=myfopen(arg_get_char(arg_file_name), "w");
	arg_put_fp (arg_fp, fp);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int pointer_size(int *p) // note that p must be declared  int *p  and not  void *p 
{
	int	*q;
	q = p-1;
	return *q;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//start time measuring.
//get as an argument a pointer to time_t where to store the start time
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	time_measure_start(char *type, Runtime *runtime)
{
	time(&runtime->start);
	arg_put_rt(type, runtime);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void time_measure_stop(char *type, Runtime *runtime)
{
	time(&runtime->end);
	runtime->elapsed = difftime( runtime->end, runtime->start);
	arg_put_rt(type, runtime);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void verylongint_print(FILE *fp, VERYLONGINT vli, char *before, char *after)
{
	int	*p;
	p = (int *)&vli;
	if (!(*(p+1)))
		fprintf(fp, "%s%d%s", before, *p, after);
	else
		fprintf(fp, "%s%d-%d%s", before, *(p+1), *p, after);
}


