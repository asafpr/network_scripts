#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include "common.h"
#include "list.h"
#include "mat.h"
#include "network.h"
//#include "hash.h"
//#include "permutation.h"
#include "arguments.h"
#include "utilities.h"

#define COMBINATIONS 100

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	routine to randomize a given network (N) by edge switching while preserving edge profile (assuming multiple colors).
//	the generated random network is used for exhaustive search.
//	the routine is based on gen_rand_network_conserve_double_edges
//	arguments:
//	Network **RN_p			-	pointer to pointer of generated random network
//	Network *N				-	real_net
//	int rnet					-	(sequence) number of random network
//	FILE *fp					-	file handle for progress report 
//	int switch_factor
//	int quiet_mode			-	flag indicating whether to log information to user
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int gen_rand_network_conserve_profiles(Network **RN_p, Network *N, int rnet, FILE *fp, int switch_factor, int quiet_mode)
{
	int	num_of_switchs;
	int	s1,s2,t1,t2;
	int	i,j,w;
	int	k = 0;
	int	tries; //number of tries to find proper pair of edges to exchange
	int	twin_i,twin_j;
	Network	*RN;
//	Network	*NC=NULL;								// for debugging
	int	rand_network_checked=FALSE;
	int	prof;				//	index on profiles
	int	pr;				//	# of edges in current profile
	int	ProgressReport = 100000;
	int	pcolors = (int)pow(2,N->colors);
	char*	prog="gen_rand_network_conserve_profiles";
	
#if	DEBUG_TRACE > 3
	printf("%s: entered\n", prog);
#endif

	while (!rand_network_checked) {

		// duplicate source network
		network_duplicate (N, &RN, "random_network", rnet);
		
		//	loop on profiles to perform switches within each type of edge profile
		for (prof = 0; prof < PROFILES; prof++) {

			pr = N->profs[prof];

			//	calculate number of required switches
			if(pr<=1)
				num_of_switchs=0;
			else
				// num of switches is round(10*(1+rand)*#edges)
				num_of_switchs=(switch_factor+get_rand(switch_factor))*pr;

			//	initialize for switching edges within a profile
			k=0;	// # of succussful switches
			w=0;	//	# of attempted switches

			// loop to switch edges within a profile
			//	-------------------------------------
			while(k<num_of_switchs && w<num_of_switchs*DESPAIR_RATIO) {

//				// duplicate network 																				//for debugging
//				if (!w)	{																								//for debugging
//					if (NC) network_free(NC);																		//for debugging
//					network_duplicate (RN, &NC, "random_network copy for testing", RN->number);	//for debugging
//				}																											//for debugging

				w++;

				// progress report
				if(!(w % ProgressReport) && !quiet_mode) {
					if (w==ProgressReport) {
						fprintf(fp, "%s: random network %d profile %d (%d,%d) ", 
						prog, rnet, prof, profile_out(prof, pcolors), profile_in(prof, pcolors));
						fprintf(fp, "has %d edges and requires %d switches, switches done -", 
						pr, num_of_switchs);
						fprintf(fp, " %d/%d ", k,w);
					} else {
						fprintf(fp, " %d/%d ", k,w);
					}
				}

				//	get two random distinct indexes of edges (i and j)
				i=get_rand(pr); 
				while ((j=get_rand(pr)) == i);

				//	perform switching
				if (edge_switch_if_can (RN, (RN->edgs[prof])[i-1], (RN->edgs[prof])[j-1], 1)) {
					k++;
//					if (k < 2) {																				//for debugging
//						printf ("checking edge switch w=%d, k=%d, prof=%d(%d-%d)\n", 			//for debugging
//						w, k, prof, profile_in(prof, pcolors), profile_out(prof, pcolors));	//for debugging
//						printf ("after having switched (%d->%d) with (%d->%d)\n",		 		//for debugging
//						(RN->edgs[prof])[i-1]->s, (RN->edgs[prof])[i-1]->t, 						//for debugging
//						(RN->edgs[prof])[j-1]->s, (RN->edgs[prof])[j-1]->t);						//for debugging
//						network_compare (stdout, RN, NC);												//for debugging
//						network_free(NC);																		//for debugging
//						network_duplicate(RN, &NC, "random_network", RN->number);				//for debugging
//					}																								//for debugging
				}
			}
				
			if (w>=ProgressReport)
				fprintf(fp, "\n");

			// report if too many failed attempts
			if(w==num_of_switchs*DESPAIR_RATIO && num_of_switchs>0)
				if(!quiet_mode) {
					fprintf(stdout,"net %d reached Despair Ratio: profile %d-%d ", 
					rnet, profile_out(prof,pcolors), profile_in(prof,pcolors));
					fprintf(stdout,"appears %d times, requires %d switches, %d/%d done\n", pr, num_of_switchs, k, w);
				}
		}
		
//		network_free(NC);																				//for debugging

		//check that there are no self edges. If there are any then start again
		rand_network_checked = TRUE;
		for(i=1;i<=RN->vertices_num;i++) {
			if( MatGet(RN->mat,i,i)==1 ) {
				printf("Self edges still exist building random graph again\n");
				rand_network_checked=FALSE;
				network_free(RN);
				break;
			}
		}
	}

	if(DEBUG_LEVEL>11)
		network_dump(stdout,RN);
	*RN_p=RN;

#if	DEBUG_TRACE > 0
	printf("%s: returning %s\n", prog, network_check(stdout, RN) ? "OK": "with error");
#endif

	return RC_OK;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	Routine to generate a random network based on complementary features
// A random graph is generated on Vrtx vertices in the following process:
//	Polar features are drawn randomly from a set of Plrf * 2 polar features. 
//	The drawn features are assigned, randomly (uniformly), to the Vrtx vertices. This is done with two constraints:
//	a. two complementary features cannot be assigned to the same vertex
//	b.	the number of resulting edges should be the minimal number that does not fall from 'N_edges_num'.
//	The resulting complementary features graph is the network generated by the procedure.
//	arguments:
//	Network **RN_p			-	pointer to pointer of generated random network
//	int Vrtx					-	number of vertices in the generated net
//	int N_edges_num		-	number of required edges
//	int Plrf					-	size of the set of polar features in the generated complementary-feature net
//	int edge					-	if true - the network is to be comosed of edges, otherwise - of arcs		
//	FILE *fp					-	file handle for progress report 
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int gen_rand_network_complementation(Network **RN_p, int Vrtx, int N_edges_num, int Plrf, int edge, FILE *fp,
	int *act_vrt, int *act_edg, int *act_drw)
{
	int	Draw = 0;	//	number of times polar features are drawn (randomly) and assigned to vertices. 
	list	**vrtx_with_feature;
	list	*vrtx_lst_1, *vrtx_lst_2;
	list_item *vrtx1, *vrtx2;
	int	i, j, k, v;
	int	feature, dual_feature;
	int	edges = 0;
	Network	*RN;
	int	combination[COMBINATIONS];
	int	vrt, edg;
	int	quadrouples = 0;
	char*	prog = "gen_rand_network_conserve_signature";

#if	DEBUG_TRACE > 3
	printf("%s: entered with Vrtx=%d N_edges_num=%d Plrf=%d edge=%d\n", prog, Vrtx, N_edges_num, Plrf, edge);
#endif

//	allocate lists for assignement of features to vertices
	vrtx_with_feature = (list **)mycalloc(Plrf*2+1, sizeof(list *));
	for (i=0; i<Plrf*2+1; i++)
		list_ini(&vrtx_with_feature[i], LIST_KEY_INT);

//	main loop of drawing polar features and assigning them to vertices
	while (edges < N_edges_num) {
		feature = get_rand(Plrf*2);			//	draw a feature - a value between 1 and Plrf*2 (inclusive)
		v = get_rand(Vrtx);						//	draw a vertex - a value between 1 and Vrtx (inclusive)
		dual_feature = (feature <= Plrf ? feature + Plrf : feature - Plrf);
		if (!list_get (vrtx_with_feature[feature], v) && 
			 !list_get (vrtx_with_feature[dual_feature], v)) {
			edges -= vrtx_with_feature[feature]->size * vrtx_with_feature[dual_feature]->size;
			list_insert (vrtx_with_feature[feature], v, NULL);
			edges += vrtx_with_feature[feature]->size * vrtx_with_feature[dual_feature]->size;
			Draw++;
		}
	}

//	generate random network
	RN = network_init("Random complementation", 0, Vrtx , edges*(1+edge), COLORS, PROFILES);

//	construct the network edges from the polar features assigned to vertices
	j = 0;
	for (i=1; i<=Plrf; i++) {
		vrtx_lst_1 = vrtx_with_feature[i];
		vrtx_lst_2 = vrtx_with_feature[i+Plrf];
		for (vrtx1 = list_get_next (vrtx_lst_1, NULL); vrtx1; vrtx1 = list_get_next (vrtx_lst_1, vrtx1))
			for (vrtx2 = list_get_next (vrtx_lst_2, NULL); vrtx2; vrtx2 = list_get_next (vrtx_lst_2, vrtx2)) {
				j++;
				RN->e_arr[j].s = vrtx1->val;
				RN->e_arr[j].t = vrtx2->val;
				RN->e_arr[j].color = 1;
				if (edge) {
					j++;
					RN->e_arr[j].s = vrtx2->val;
					RN->e_arr[j].t = vrtx1->val;
					RN->e_arr[j].color = 1;
				}
			}
	}

//	compute multiplicity
	for (i=0; i<COMBINATIONS; i++)
		combination[i]=0;
	for (i=1; i<=Plrf; i++) {
		j = vrtx_with_feature[i]->size * vrtx_with_feature[i+Plrf]->size;
		k = (j < COMBINATIONS ? j : COMBINATIONS - 1);
		combination[k] += j;
	}

//	quadrouples
	for (i=1; i<=Plrf; i++) {
		j = vrtx_with_feature[i]->size;
		k = vrtx_with_feature[i+Plrf]->size;
		if (j > 1 && k > 1)
			quadrouples += k*(k-1) * j*(j-1);
	}
	if (edge)
		quadrouples *= 2;

//	deallocate lists retaining the assignment of features to vertices
	for (i=0; i<Plrf*2+1; i++)
		list_free_mem(vrtx_with_feature[i]);
	myfree (vrtx_with_feature);

//	construct the network from its edges
	network_construc_from_edges (RN, fp);

//	log
	network_size_by_color (RN, &vrt, &edg, 1);
#ifdef EXTENDED_LOG
	fprintf (fp, "generated a random complementation network with");
	fprintf (fp, " %d/%d vertices and %d/%d %s via %d features and %d draws\n",
	Vrtx, vrt, N_edges_num, edge ? edg/2 : edg, edge ? "edges" : "arcs", Plrf, Draw);
	fprintf (fp, "%d generic quadrouples from combinations: ", quadrouples);
	for (i=0; i<COMBINATIONS; i++)
		if (combination[i])
			fprintf (fp, "%d:%d ", i, combination[i]);
	fprintf (fp, "\n");
#endif

	*act_vrt = vrt;
	*act_edg = edg;
	*act_drw = Draw;

	*RN_p=RN;

}

