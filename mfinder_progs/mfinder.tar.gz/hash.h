#ifndef __HASH_H
#define __HASH_H

#include <stdio.h>

//Hash table size - should be a prime number
#define HASH_SIZE      1013

typedef struct {
	int size;    // hash table size
	int bckt_sz; //backet array size
	list **h;
}Hash;


void
hash_init(Hash *hash,int size,int bckt_sz);

Hash*
multi_hash_init(int hash_tbl_num);

int
hash_get_key(Hash *hash,int *p);

void
hash_insert(Hash *hash,int *p);

void
hash_free_mem(Hash *hash);

void
multi_hash_free_mem(Hash *multi_hash, int hash_tbl_num);





#endif




