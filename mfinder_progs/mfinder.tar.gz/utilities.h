#ifndef __UTILITIES_H
#define __UTILITIES_H

#define _LARGEFILE_SOURCE
#define _LARGEFILE64_SOURCE

#include <stdio.h>
#include "common.h"

void	dump_time_measure(FILE* fp,char *text, Runtime *runtime);
FILE	* myfopen (char *file_name, char * type);
void	myfopenw_using_arg (char *arg_file_name, char *arg_fp);
int	pointer_size(int *p);
void	time_measure_start(char *type, Runtime *runtime);
void	time_measure_stop(char *type, Runtime *runtime);
void	verylongint_print(FILE *fp, VERYLONGINT vli, char *before, char *after);

#endif
