#include <stdio.h>
#include <stdlib.h>
#include "common.h"
#include "list.h"
#include "utilities.h"

#ifdef ENABLE_PROFILE
extern VERYLONGINT calls_to_list_get;
extern VERYLONGINT calls_to_list_insert;
extern VERYLONGINT while_length_list_get;
extern VERYLONGINT while_length_list_insert;
#endif

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	previously: int*	create_subset_arr(list *org)
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int*	list_2_array(list *org)
{
	int i;
	int *arr;
	list_item *org_item=NULL;

	if (org != NULL) {
		arr=(int*)mycalloc(org->size,sizeof(int));
		for(i=0,org_item=list_get_next(org,NULL); i<org->size;i++,org_item = list_get_next(org,org_item)) {
			arr[i]=org_item->val;
		}
		return arr;
	} else {
		return NULL;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	this is a memory comparison routine that really emulates comparison of integers
//	it is used to compare the order of list keys.
//	this mode of comarison is used (and not the straigtforward one) in order to retain continuity with previous
// versions where list keys were very long integers.
//	the difference between straigntforward memory comparison and integer comparison is that integers are arranged in 
//	memory in the order from less significant to more significant whereas chars are arranged the other way arround. 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
static int _memcmp (char *c1, char *c2, int len)
{
	int	i;
	long	long int *i1, *i2;
	int	result = 0;
	int	j1, j2;

	for (i=len-1; i>=0 && !result; i--) {
		j1 = c1[i];
		j2 = c2[i];
		if (j1 < 0) j1 += 256;
		if (j2 < 0) j2 += 256;
		if (j1 < j2)
			result = -(i+1);
		else if (j1 > j2)
			result = i+1;
	}
	return result;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//void dump_list(list *L)
//{
//	list_dump (stdout, L);
//}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// list_check confirms that the length of a linked list is consistent with its size.
// the routine is given a pointer to a list and it returns
// 0	- to indicate that the list is not initialized (this can be considered TRUE or False depending on the situation)
// 1	- size != length (but length=0)
// 2	- size != length (but length>0)
//	-1	- OK: size == length > 0
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int list_check (list *L)
{
	list_item *li;
	int	ll=0;				// list length (number of list elements)
	int	rtn = -1;		// return value
	int	size=L->size;	// size according to the header of the list

	if (L == NULL) {
		rtn = 0;
	} else if (L->l == NULL) {
		if (size != 0)
			rtn = 1;
	} else {
		for(li=L->l; li!=NULL && ll <= size + 1; li=li->next)
			ll++;
		if (size != ll)
			rtn = 2;
	}
//	printf("list_check: returning with size=%d, length>=%d, rtn=%d\n", size, ll, rtn);
	return rtn;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	delete an item from a list. the item is by provided via a pointer to the key value. adjusted for big motifs
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int list_del(list *L, void* key)
{
	list_item *t1,*t2;
	int pos_found=0;
	int *val;

	if (L->type == LIST_KEY_INT) {
		val = (int*)key;
		return list_delete(L, *val);
	} else {
		//if empty list
		if (!L->l) {
			return -1;
		} else {
			t1 = L->l;
			t2 = t1->next;
			//if first item
			if (!memcmp(&(t1->key), key, sizeof(ListKey))) {
				L->l = t1->next;
				L->size--;
				if (t1->p) 
					myfree(t1->p);
				myfree(t1);
				return 0;
			}
			if (t2) { 
				while(t2->next && memcmp(&(t2->key),key, sizeof(ListKey))) {
					t1=t1->next;
					t2=t2->next;
				}
				if (!memcmp (&(t2->key), key, sizeof(ListKey))) {
					t1->next=t2->next;
					L->size--;
					if (t2->p != NULL) 
						myfree(t2->p);
					myfree(t2);
				} else
					//not in the list
					return -1;
			}
			else return -1;
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	delete an element from a list that has an int key (the int key to be deleted is provided)
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int list_delete(list *L, int val)
{
	list_item *t1,*t2;
	int pos_found=0;

	if (L->type != LIST_KEY_INT) {
		printf("list_delete: list type mismatch\n");
		exit(-1);
	}

	//if empty list
	if (L->l == NULL) {
		return -1;
	} else {
		t1 = L->l;
		t2 = t1->next;
		//if first item
		if (t1->val == val) {
			L->l = t1->next;
			L->size--;
			if (t1->p != NULL) 
				myfree(t1->p);
			myfree(t1);
			return 0;
		}
		if (t2 != NULL) { 
			while(t2->next != NULL && t2->val!=val) {
				t1=t1->next;
				t2=t2->next;
			}
			if (t2->val == val) {
				t1->next=t2->next;
				L->size--;
				if (t2->p != NULL) 
					myfree(t2->p);
				myfree(t2);
			} else
				//not in the list
				return -1;
		}
		else return -1;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	dump a list. adjusted for big motifs
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void list_dump(FILE *fp, list *L)
{
	list_item *tmp;
	int	*p1, *p2;
	int	i=0;
	int	j;
	char	*prog="list_dump";

#if	DEBUG_TRACE > 8
	printf("%s: entered, size=%d\n", prog, L->size);
#endif

	if (L == NULL) {
		printf("null list");
	} else {
		fprintf (fp, "dumping list of size %d located at %p\n", L->size, L);
		for(tmp=L->l; tmp!=NULL && i<L->size; tmp=tmp->next) {
			i++;
			if (L->type == LIST_KEY_INT)
				fprintf(fp, "item %p, val=%d nxt=%p ", tmp, tmp->val, tmp->next);
			else if (L->type == LIST_KEY_GEN) {
				motif_id_print ((MotifID *)&(tmp->key), fp, "key=", "\t");
			} 
			p1 = tmp->p;
			if (p1!=NULL) {
				p2 = p1 - 1;
			 	fprintf (fp, "p=%p\tpointer_size~x%x\n", p1, *p2);
			}
		}
	}
	fprintf(fp, "\n");
#if	DEBUG_TRACE > 8
	printf("%s: returned\n", prog);
#endif
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	produce a short dump of a list. 
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void list_dump_short(FILE *fp, list *L, char *before, char *after)
{
	list_item *itm;
	int	i=0;

	fprintf(fp, "%s", before);
	if (L == NULL) {
		printf("null list");
	} else {
		for(itm=L->l; itm!=NULL && i<L->size; itm=itm->next) {
			i++;
			if (L->type == LIST_KEY_INT)
				fprintf(fp, "%d ", itm->val);
			else if (L->type == LIST_KEY_GEN) {
				motif_id_print ((MotifID *)&(itm->key), fp, "", " ");
			} 
		}
	}
	fprintf(fp, "%s", after);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
ListKey * list_element_key (list_item *li)
{
	if (!li)
		return NULL;
	return &(li->key);
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void list_element_key_get (list_item *li, ListKey *key)
{
	*key = li->key;
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//ss frees the memory of the content of a list and of the list header itself
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void list_free_mem(list *L)
{
	list_free_content(L);
	myfree((void*)L);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	frees the memory of the content of a list (retaining the list header itself)
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void list_free_content(list *L)
{
	list_item *item,*tmp;
	for(item=list_get_next(L,NULL); item!=NULL;) {
		tmp=item;
		item=list_get_next(L,item);
		if(tmp->p !=NULL)
			myfree(tmp->p);
		myfree(tmp);
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	receive a file with one list key value in a line and create a list from the key values.
//	the key values should be all integers, not too very long.
//	the pointers of the created list are all null.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void list_from_file(list **L, FILE *fp, int type)
{
	long	key_val;
	int	rc;
	VERYLONGINT	vli;
	char	*prog="list_from_file";

#if	DEBUG_TRACE >= 0
	printf("%s: entered with type=%d\n", prog, type);
#endif

	if (sizeof(VERYLONGINT) != sizeof(MotifID)) {
		printf ("%s cannot handle motifs of size different from VERYLONGINT\n", prog);
		exit (-1);
	}

	if (type ==0)
		list_ini(L, LIST_KEY_GEN);
	else
		list_ini(L, type);

	while ( (rc = fscanf(fp,"%d\n", &key_val) != EOF) ) {
		vli = key_val;
		list_ins ((*L), &vli, NULL);
	}

	list_dump (stdout, (*L));
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	get an item from a list with keys of type integer, when the key value is given
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
list_item* list_get(list *L, int val)
{
	list_item *tmp;

#ifdef ENABLE_PROFILE
	calls_to_list_get++;
#endif

	if (L->type != LIST_KEY_INT) {
		printf("list_get: list type mismatch\n");
		exit(-1);
	}

	//if list is NULL
	if (L == NULL)
		return NULL;
	//if empty list
	if (L->l == NULL) {
		return NULL;
	} else
		tmp = L->l;

	while(tmp->next != NULL && tmp->val!=val){
		tmp=tmp->next;
#ifdef ENABLE_PROFILE
		while_length_list_get++;
#endif
	}
	if (tmp->val == val)
		return tmp;
	else
	//not in the list
		return NULL;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	get a list item by key. adjusted for big motifs
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
list_item* list_get_by_key(list *L, void *key)
{
	list_item *tmp;

#ifdef ENABLE_PROFILE
	calls_to_list_get++;
#endif

	int *val;

	if (L->type == LIST_KEY_INT) {
		val = (int*)key;
		return list_get(L, *val);
	} else {

		//if list is NULL
		if (!L)
			return NULL;
		if (!L->l) {				//if empty list
			return NULL;
		} else {
			tmp = L->l;
			while(tmp->next && memcmp (&(tmp->key), key, sizeof(ListKey))) {
				tmp=tmp->next;
#ifdef ENABLE_PROFILE
				while_length_list_get++;
#endif
			}
			if (!memcmp (&(tmp->key), key, sizeof(ListKey)))
				return tmp;
			else
				return NULL;		//not in the list
		}
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	get a list item by index
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
list_item* list_get_by_indx(list *L, int indx)
{
	list_item *tmp;
	int i;

	//if list is NULL
	if (L == NULL)
		return NULL;
	//if empty list
	if (L->l == NULL) {
		return NULL;
	} else
		tmp = L->l;

	if(indx==0)
		return NULL;

	for(tmp=L->l,i=1;(tmp!=NULL) && (i<indx);tmp=tmp->next,i++);
	
	if (i==indx)
		return tmp;
	else
		return NULL;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	return next element in list.
// to get the first item - the second parameter should be NULL
//	if end of list returns NULL
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
list_item * list_get_next(list *L, list_item *item)
{
	if(L==NULL)
		return NULL;
	if(item==NULL)
		return L->l;
	else 
		return item->next;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	check whether a list includes a key
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int list_includes (list *L, void *id)
{
	list_item *itm;
	int	type = L->type;
	int	rtn = FALSE;

#if	DEBUG_TRACE > 6
	char	*prog = "list_includes";
	printf("%s: entered ", prog);
	motif_id_print (id, stdout,  " with motif ", ".\n");
	list_dump (stdout, L);
#endif

	for (itm=list_get_next(L, NULL); itm; itm=list_get_next(L, itm)) {
		switch (type) {
		case LIST_KEY_INT:
			if (*((int *)id) == itm->val)
				rtn = TRUE;
			break;
		case LIST_KEY_GEN:
			if (!memcmp (id, itm->key.key, sizeof(ListKey)))
				rtn = TRUE;
			break;
		default:
//			printf("list_ini: illegal type %d. program aborted\n", type);
			rtn = FALSE;
			break;
		}
	}
	return rtn;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//initialize a list with default key type (int)
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void list_init(list **L)
{
	list_ini (L, LIST_KEY_INT);
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//initialize a list with key type. in case of wrong type, the default key type is used (int) but a return error is set
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int list_ini(list **L, int type)
{
	int	rtn = TRUE;

	*L = (list*)myalloc(sizeof(list));
//	(list*)(*L)->size=0;
//	(list*)(*L)->l=NULL;
	(*L)->size=0;
	(*L)->l=NULL;

	switch (type) {
	case LIST_KEY_INT:
//		(list*)(*L)->type=LIST_KEY_INT;
		(*L)->type=LIST_KEY_INT;
		break;
	case LIST_KEY_GEN:
//		(list*)(*L)->type=LIST_KEY_GEN;
		(*L)->type=LIST_KEY_GEN;
		break;
	default:
//		(list*)(*L)->type=LIST_KEY_INT;
		(*L)->type=LIST_KEY_INT;
//		printf("list_ini: illegal type %d. program aborted\n", type);
		rtn = FALSE;
		break;
	}

	return rtn;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	inserting an new item into a list, with general type of key (a new item is created).
//	this routine creates a list elment, assigns the appropriate values to it and adds it to the list.
//	arguments:
//	list *L		-	list to which a new item needs to be inserted
//	void *key	-	key of the new item. the routine assumes that the (void) type of this pointer xorreponds to the
//						type expected for the list (i.e. as indicated by the list type).
//	void *p		-	pointer to additional value of the list element.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void list_ins(list *L, void *key, void *p)
{
	list_item *item,*tmp;
	int pos_found=0;
	ListKey	*keyp;	//	properly casted equivalent of the input argument 'key'
	ListKey	k;
	int *val;

#ifdef ENABLE_PROFILE
	calls_to_list_insert++;
#endif

	if (L->type == LIST_KEY_INT) {
		val = (int*)key;
		list_insert(L, *val, p);

	} else {
		keyp = (ListKey *)key;
		memcpy (&k, keyp, sizeof(ListKey));
		item = (list_item*)myalloc(sizeof(list_item));
		memcpy (&(item->key), keyp, sizeof(ListKey));
		item->p=p;
		item->next=NULL;

		if (L->l == NULL) {		//if empty list
			L->l = item;
		} else {
			tmp = L->l;
			//if smaller then first item
			if (_memcmp ((char *)&(item->key), (char *)&(L->l->key), sizeof(ListKey)) <= 0) {
				item->next=L->l;
				L->l=item;
			} else { 
				while( tmp->next!=NULL && !pos_found){
#ifdef ENABLE_PROFILE
					while_length_list_insert++;
#endif
					if( _memcmp ((char *)&(tmp->next->key), (char *)&k, sizeof(ListKey)) <= 0)
						tmp=tmp->next;
					else
						pos_found=1;
				}
				item->next=tmp->next;
				tmp->next=item;
			}
		}
		L->size++;
	}
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	inserting an new element into a list, with key of type integer (a new item is created)
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void list_insert(list *L, int val, void *p)
{
	list_item *item,*tmp;
	int pos_found=0;
	item = (list_item*)myalloc(sizeof(list_item));
	item->val = val;
	item->p=p;
	item->next=NULL;

#ifdef ENABLE_PROFILE
	calls_to_list_insert++;
#endif

	if (L->type != LIST_KEY_INT) {
		printf("list_insert: list type mismatch\n");
		exit(-1);
	}

	//if empty list
	if (L->l == NULL) {
		L->l = item;
	} else {
		tmp = L->l;
		//if smaller then first item
		if (item->val <= L->l->val) {
			item->next=L->l;
			L->l=item;
		} else { 
			while( tmp->next!=NULL && !pos_found){
#ifdef ENABLE_PROFILE
				while_length_list_insert++;
#endif
			if( tmp->next->val <= item->val )
				tmp=tmp->next;
			else
				pos_found=1;
			}
			item->next=tmp->next;
			tmp->next=item;
		}
	}
	L->size++;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	inserting an existing list_item into a list. adjusted for big motifs.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void list_item_ins(list *L, list_item *item)
{
	list_item *first, *prv, *nxt;
	ListKey	key;
	int val;
	char	*prog="list_item_ins";

#if	DEBUG_TRACE > 8
	printf("%s: entered list of size %d with item %p\n", prog, L->size, item);
	list_dump (stdout, L);
#endif

	if (!item)
		return;

	item->next = NULL;

	if (L->type == LIST_KEY_INT) {
		val = item->val;
		first = L->l;
		if (!first) {																			//	if empty list
			L->l = item;
			L->size++;
		} else if (val <= first->val) {													//	if smaller then first item
			item->next = L->l;
			L->l = item;
			L->size++;
		} else {
			prv = first;
			for (nxt=prv->next; nxt; nxt=prv->next) {
				if (val <= nxt->val) {
					prv->next = item;
					item->next = nxt;
					L->size++;
					break;
				} else
					prv = nxt;
			}
			if (!item->next) {																// if after last
				prv->next = item;
				L->size++;
			}
		}

	} else {
		memcpy (&key, &(item->key), sizeof(ListKey));
		first = L->l;
		if (!first) {																			//	if empty list
			L->l = item;
			L->size++;
		} else if (_memcmp ((char *)&key, (char *)&(first->key), sizeof(ListKey)) <= 0) {	//if smaller then first item
			item->next = L->l;
			L->l = item;
			L->size++;
		} else {
			prv = first;
			for (nxt=prv->next; nxt; nxt=prv->next) {
				if (_memcmp ((char *)&key, (char *)&(nxt->key), sizeof(ListKey)) <= 0) {
					prv->next = item;
					item->next = nxt;
					L->size++;
					break;
				} else
					prv = nxt;
			}
			if (!item->next) {																// if after last
				prv->next = item;
				L->size++;
			}
		}
	}
#if	DEBUG_TRACE > 8
	printf("%s: treminated with list of size %d:\n", prog, L->size);
	list_dump (stdout, L);
#endif
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	remove a list_item from a list (without destroying it). 
//	if the key of the list_item is not found in the list nothing is done (and no error message issued)
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void list_item_rmv(list *L, list_item *item)
{
	list_item *first, *prv, *nxt;
	ListKey	key;
	int val;
	int found = FALSE;

#if	DEBUG_TRACE > 8
	printf("list_item_rmv: entered list of size %d with item %p\n", L->size, item);
	list_dump (stdout, L);
#endif

	if (!item)
		return;
	if (!L)
		return;

	if (L->type == LIST_KEY_INT) {
		val = item->val;
		first = L->l;
		if (val == first->val) {
			L->l = item->next;
			L->size--;
		} else {
			prv = first;
			for (nxt=prv->next; nxt && !found; nxt=prv->next) {
				if (val == nxt->val) {
					prv->next = item->next;
					found = TRUE;
					L->size--;
				} else
					prv = nxt;
			}
			// if want to check that something was found - it should be done here: if(!found) ...
		}

	} else {
		memcpy (&key, &item->key, sizeof(ListKey));
		first = L->l;
		if (memcmp (&key, &(first->key), sizeof(ListKey)) == 0) {
			L->l = item->next;
			L->size--;
		} else {
			prv = first;
			for (nxt=prv->next; nxt && !found; nxt=prv->next) {
				if (memcmp (&key, &(nxt->key), sizeof(ListKey)) == 0) {
					prv->next = item->next;
					found = TRUE;
					L->size--;
				} else
					prv = nxt;
			}
			// if want to check that something was found - it should be done here: if(!found) ...
		}
	}

	item->next = NULL;

#if	DEBUG_TRACE > 8
	printf("list_item_rmv: on return, list is of size %d:\n", L->size);
	list_dump (stdout, L);
#endif
}


