#ifndef __SWITCHES_H
#define __SWITCHES_H

//number of colors the program can handle. the original version can handle only one
//#define	COLORS 1
#define	COLORS 3
#define	PCOLORS (int)pow(2,COLORS)
#define	PROFILES PCOLORS*PCOLORS

//	switch to control activation of code that has to do with in/out degrees of vertices.
//	if defined  - handling of indegree and outdegree is removed from the code. more specifically - the progrma ignores:
//	a.	in/out degrees
//	b. N->con_vertices_num
#define NODEG 1

//flag that cOntrols level of debugging
#define	DEBUG_TRACE 0
//#define	DEBUG_TRACE 3
//#define	DEBUG_TRACE 6

//switch to control the activation of code segments that are intended to count usage of code
//#define ENABLE_PROFILE 

//	PROBAPPROACH activates the probabilistic analysis
// controls the exclusion/inclusion of some code that has to do with probabilistic analysis
//#define	PROBAPPROACH 1

// METROAPPROACH activates the metropolis routines
// controls the exclusion/inclusion of some code that has to do with metropolis analysis
//#define	METROAPPROACH 1

//	MOTIF_ID_AND_LIST_KEY_SIZE is the size (in bytes) of a motif ID and a list key. It must be a multiple of sizeof(int) (4)
#define MOTIF_ID_AND_LIST_KEY_SIZE 8

// VERYLONGINT should be defined as 'long long int' on unix and as '__int64' in microsoft
#define VERYLONGINT long long int
#define LONGLONGINT long long int

//debug level will in the future may be changed by command line
#define DEBUG_LEVEL 0

//set a compiler switch to ignore self-edges when loading a network
//if set to 1 it reports every case
//if set to 2 it reports only total number of self edges
//if set to 3 it reports nothing
#define IGNORESELFEDGES 2

//	set a compiler switch to control parts of code that check the proper behaviour of the program.
//	after everything is proven to run properly, undefine.
//	setting the value to 2 does a logging in subset_search
#define AUTO_CHECK 1
//#define AUTO_CHECK 2

#endif
