///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// metropolis routines - those required for the metropolis approach
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

double sin_metrop_switches(Network **RN,int nover,int nlimit,double init_t,int real_vec13[14],int rand_vec13[14])
/* perform metropolis iteration exchanging single edges. Output the temperature */
{

	double t=init_t;
	register int w,k,num_at_t;
	int s1,t1,s2,t2;
	int i,j,l;
	int sub13[14];
	int add13[14];
	double E1,E2,dE;
	int make_change;

#if	DEBUG_TRACE > 2
	printf("sin_metrop_switches: entered\n");
#endif

	printf("\nBeginning single switches\n");	

	k=0,w=0,num_at_t=0;
	t=init_t;
	
	for (i=1;i<14;i++)
	{
		sub13[i]=0;
		add13[i]=0;
	}

	E1=energy(real_vec13,rand_vec13);
	
	if ((w%1000)==0)
		fprintf(arg_get_fp("mat_metrop_fp"),"\nEsin :\n");

	while ((w<nover)&&(E1>arg_get_double("e_thresh"))) 
	{
		w++;
		num_at_t++;
	
		if ((k>nlimit)||(num_at_t>nlimit))
		{
			num_at_t=0;
			k=0;
			t *= TFACTR;		// lower temperature
		}
	
		//get random indexes for edges
		i=get_rand((*RN)->e_sin_num); 
		while ((j=get_rand((*RN)->e_sin_num)) == i);
		
		s1=(*RN)->e_arr_sin[i].s;
		t1=(*RN)->e_arr_sin[i].t;
		s2=(*RN)->e_arr_sin[j].s;
		t2=(*RN)->e_arr_sin[j].t;
		
		//check : 1.that there are no crossing edges,
		//		  2.there are no common vertices of these 2 edges
		//if hasnt passed the check then have to find other pair to switch

		if ( !(MatGet((*RN)->mat,s1,t2) || MatGet((*RN)->mat,s2,t1)|| MatGet((*RN)->mat,t2,s1) || MatGet((*RN)->mat,t1,s2))
				&&(s1!=s2) && (s1!=t2) && (t1!=s2) && (t1!=t2) ) 
		{
			fill_13((*RN),s1,t1,s2,t2,sub13,add13);
			update(rand_vec13,sub13,add13,1);
			E2=energy(real_vec13,rand_vec13);
			dE=E2-E1;
			//	printf("k=%d E=%lf\n",k,E1);
			make_change=metrop(dE,t);
		
		
			if (make_change)
			{
				if ((w%1000)==0)
				{
					fprintf(arg_get_fp("mat_metrop_fp"),"%lf\n",E1);						
					printf("success=%d k=%d E1=%lf T=%lf\n",k,w,E1,t);
				}
				
				if(DEBUG_LEVEL>1)
				{
					fprintf(arg_get_fp("mat_metrop_fp"),"The network :\n\n");
					for (l=1;l<=(*RN)->e_sin_num;l++)
						fprintf(arg_get_fp("mat_metrop_fp"),"%d %d %d\n",(*RN)->e_arr_sin[l].t,(*RN)->e_arr_sin[l].s,1);
				}			
				
				
				E1=E2;
				//make the switch
				//update edges array
				(*RN)->e_arr_sin[i].t=t2;
				(*RN)->e_arr_sin[j].t=t1;
				//update matrix
				MatAsgn((*RN)->mat,s1,t1,0);
				MatAsgn((*RN)->mat,s2,t2,0);
				MatAsgn((*RN)->mat,s1,t2,1);
				MatAsgn((*RN)->mat,s2,t1,1);
				//fprintf(arg_get_fp("mat_metrop_fp"),"%lf %lf\n  ",E1,t);
				if(DEBUG_LEVEL>1)
				{
					fprintf(arg_get_fp("mat_metrop_fp"),"Changed to  :\n\n");
					for (l=1;l<=(*RN)->e_sin_num;l++)
						fprintf(arg_get_fp("mat_metrop_fp"),"%d %d %d\n",(*RN)->e_arr_sin[l].t,(*RN)->e_arr_sin[l].s,1);
							
					fprintf(arg_get_fp("mat_metrop_fp"),"rand_vec : \n");
					output13(rand_vec13,arg_get_fp("mat_metrop_fp"));
					fprintf(arg_get_fp("mat_metrop_fp"),"- : \n");
					output13(sub13,arg_get_fp("mat_metrop_fp"));
					fprintf(arg_get_fp("mat_metrop_fp"),"+ : \n");
					output13(add13,arg_get_fp("mat_metrop_fp"));
					fprintf(arg_get_fp("mat_metrop_fp"),"The network :\n\n");
					for (l=1;l<=(*RN)->e_sin_num;l++)
						fprintf(arg_get_fp("mat_metrop_fp"),"%d %d %d\n",(*RN)->e_arr_sin[l].t,(*RN)->e_arr_sin[l].s,1);
					fprintf(arg_get_fp("mat_metrop_fp"),"\n\n");
				}
				k++;
			}
			else
			/* change rand_vec13 back */
			{
				update(rand_vec13,sub13,add13,0);
				
			}
		}
	}
	fprintf(arg_get_fp("mat_metrop_fp"),"%lf\n",E1);						
	printf("success=%d k=%d E1=%lf T=%lf\n",k,w,E1,t);
	return(t);
}


double dbl_metrop_switches(Network **RN,int nover,int nlimit,double init_t,int real_vec13[14],int rand_vec13[14])
/* perform metropolis iteration exchanging double edges. Output the temperature */
{
	
	double t=init_t;
	register int w,k,num_at_t;
	int s1,t1,s2,t2;
	int i,j,l;
	int sub13[14];
	int add13[14];
	double E1,E2,dE;
	int make_change;
	int tries; //number of tries to find proper pair of edges to exchange
	int twin_i,twin_j;

#if	DEBUG_TRACE > 2
	printf("dbl_metrop_switches: entered\n");
#endif

	printf("\nBeginning double switches\n");	
	k=0,w=0,num_at_t=0;
	t=init_t;
	
	for (i=1;i<14;i++)
	{
		sub13[i]=0;
		add13[i]=0;
	}
	
	E1=energy(real_vec13,rand_vec13);

	while ((w<nover)&&(E1>arg_get_double("e_thresh"))) 
	{
		w++;
		num_at_t++;
		if ((k>nlimit)||(num_at_t>nlimit))
		{
			num_at_t=0;
			k=0;
			t *= TFACTR;		// lower temperature
		}
		w++;
		// random edges to choose : until finding a proper pair of edges which can be candidates
		// should not choose the same edge or the twin one (of the double)
		// try this for 100 times if not getting good candidate then probably
		// there is a only one double edge in the netwprk
		for(i=get_rand((*RN)->e_dbl_num),j=get_rand((*RN)->e_dbl_num),tries=0;
		((j==i) || (j==twin_i)) && (tries<100) ;i=get_rand((*RN)->e_dbl_num),j=get_rand((*RN)->e_dbl_num),tries++);
		//the way out of deadlock
		if(tries==100 || (*RN)->e_dbl_num==2)
			break;
		//this is needed to know if the twin is i-1 or i+1
		if(i & 0x1) 
			twin_i=i+1;
		else
			twin_i=i-1;
		if(j & 0x1)
			twin_j=j+1;
		else
			twin_j=j-1;
		
		s1=(*RN)->e_arr_dbl[i].s;
		t1=(*RN)->e_arr_dbl[i].t;
		s2=(*RN)->e_arr_dbl[j].s;
		t2=(*RN)->e_arr_dbl[j].t;
		
		//check : 1.that there are no crossing edges in the network,
		//		  2.there are no common vertices of these 2 edges
		//if hasnt passed the check then have to find other pair to switch
		if (( !( MatGet((*RN)->mat,s1,t2) || MatGet((*RN)->mat,s2,t1) || MatGet((*RN)->mat,t1,s2)|| MatGet((*RN)->mat,t2,s1)) 
			&& (s1!=t2) &&(s2!=t1) && (s1!=s2) && (t1!=t2)) ) 
		{
			// make fill13_dbl - new function
			fill_13_dbl((*RN),s1,t1,s2,t2,sub13,add13);
			update(rand_vec13,sub13,add13,1);
			E2=energy(real_vec13,rand_vec13);
			dE=E2-E1;
			//	printf("k=%d E=%lf\n",k,E1);
			make_change=metrop(dE,t);
		
			if (make_change)
			{
				if(DEBUG_LEVEL==1) {
					fprintf(arg_get_fp("log_fp"),"switch #%d: (%d %d) (%d %d)\n", k,s1,t1,s2,t2);
					fprintf(arg_get_fp("log_fp"),"i: %d, twin i %d , j: %d twin j : %d\n", i,twin_i,j,twin_j);
				}
				if ((w%1000)==0)
				{
					fprintf(arg_get_fp("mat_metrop_fp"),"%lf\n",E1);						
					printf("success=%d k=%d E1=%lf T=%lf\n",k,w,E1,t);
				}
				E1=E2;
				if ((w%1000)==0)
						printf("success=%d k=%d E1=%lf T=%lf\n",k,w,E1,t);
				//make the switch
				//update edges array
				(*RN)->e_arr_dbl[i].t=t2;
				(*RN)->e_arr_dbl[twin_i].s=t2;
				(*RN)->e_arr_dbl[j].t=t1;
				(*RN)->e_arr_dbl[twin_j].s=t1;
				if(DEBUG_LEVEL==1) {
					fprintf(arg_get_fp("log_fp"),"(%d %d) (%d %d) (%d %d) (%d %d)\n",
					(*RN)->e_arr_dbl[i].s,(*RN)->e_arr_dbl[i].t,
					(*RN)->e_arr_dbl[twin_i].s,(*RN)->e_arr_dbl[twin_i].t,
					(*RN)->e_arr_dbl[j].s,(*RN)->e_arr_dbl[j].t,
					(*RN)->e_arr_dbl[twin_j].s,(*RN)->e_arr_dbl[twin_j].t
					);
				}
			
				//update matrix
				MatAsgn((*RN)->mat,s1,t1,0);
				MatAsgn((*RN)->mat,t1,s1,0);
				MatAsgn((*RN)->mat,s2,t2,0);
				MatAsgn((*RN)->mat,t2,s2,0);
				if(DEBUG_LEVEL==1)
					dump_network(arg_get_fp("log_fp"),(*RN));
				MatAsgn((*RN)->mat,s1,t2,1);
				MatAsgn((*RN)->mat,t2,s1,1);
				MatAsgn((*RN)->mat,s2,t1,1);
				MatAsgn((*RN)->mat,t1,s2,1);
				if(DEBUG_LEVEL==1)
					dump_network(arg_get_fp("log_fp"),(*RN));
				if (DEBUG_LEVEL>1)
				{
					fprintf(arg_get_fp("mat_metrop_fp"),"%lf %lf  ",E1,t);
					output13(rand_vec13,arg_get_fp("mat_metrop_fp"));
				}
				k++;
			}
			else
			/* change rand_vec13 back */
			{
				update(rand_vec13,sub13,add13,0);
			}
		}
	}
	fprintf(arg_get_fp("mat_metrop_fp"),"%lf\n",E1);						
	printf("success=%d k=%d E1=%lf T=%lf\n",k,w,E1,t);
	return(t);	
}


int
gen_rand_network_metrop(Network **RN_p,int real_vec13[14])
{
	int sin_num_of_switchs,dbl_num_of_switchs,num_at_t;
	int s1,s2,t1,t2;
	int i,j,l;
	int k;  // number of succesful switches
	int w;  // total number of switches
	int tries; //number of tries to find proper pair of edges to exchange
	int twin_i,twin_j;
	Network *RN;
	int rand_network_checked=FALSE;
	Res_tbl met_res_tbl;
	//int real_vec13[14];
	int rand_vec13[14];
	int sub13[14];
	int add13[14];
	double E1,E2,dE;
	int	nover,snover,dnover; // maximum # of graph changes at any temperature
	int nlimit,snlimit,dnlimit; // maximum # of succesful graph changes at any temperature
	int make_change;
	int numsucc; // how many successful switches already made
	double t;  // the temperature
	
#if	DEBUG_TRACE > 1
	printf("gen_rand_network_metrop: entered\n");
#endif

	t=arg_get_double("t_init");


	while (!rand_network_checked) {
		//duplicate source network
		duplicate_network(G_N,&RN,"random_network");
		if (DEBUG_LEVEL>11)
			dump_network(stdout,RN);
		
		//Switch double edges
		
		if(RN->e_dbl_num<=2)
			dbl_num_of_switchs=0;
		else
			// num of switches is round(10*(1+rand)*#edges)
			//num of edges in undirfecetd is actually *2 therefore divided by 2
			dbl_num_of_switchs=(10+get_rand(10))*RN->e_dbl_num/2;
		
		k=0,w=0;
		
		//dont allow switches that cause self_edges
		while(k<dbl_num_of_switchs && w<dbl_num_of_switchs*DESPAIR_RATIO) {			
			w++;
			// random edges to choose : until finding a proper pair of edges which can be candidates
			// should not choose the same edge or the twin one (of the double)
			// try this for 100 times if not getting good candidate then probably
			// there is a only one double edge in the netwprk
			for(i=get_rand(RN->e_dbl_num),j=get_rand(RN->e_dbl_num),tries=0;
			((j==i) || (j==twin_i)) && (tries<100) ;i=get_rand(RN->e_dbl_num),j=get_rand(RN->e_dbl_num),tries++);
			//the way out of deadlock
			if(tries==100 || RN->e_dbl_num==2)
				break;
			//this is needed to know if the twin is i-1 or i+1
			if(i & 0x1) 
				twin_i=i+1;
			else
				twin_i=i-1;
			if(j & 0x1)
				twin_j=j+1;
			else
				twin_j=j-1;
			
			s1=RN->e_arr_dbl[i].s;
			t1=RN->e_arr_dbl[i].t;
			s2=RN->e_arr_dbl[j].s;
			t2=RN->e_arr_dbl[j].t;
			
			
			//check : 1.that there are no crossing edges in the network,
			//		  2.there are no common vertices of these 2 edges
			//if hasnt passed the check then have to find other pair to switch
			if ( !( MatGet(RN->mat,s1,t2) || MatGet(RN->mat,s2,t1) || MatGet(RN->mat,t1,s2)|| MatGet(RN->mat,t2,s1)) 
				&& (s1!=t2) &&(s2!=t1) && (s1!=s2) && (t1!=t2) ) {
				if(DEBUG_LEVEL==1) {
					fprintf(arg_get_fp("log_fp"),"switch #%d: (%d %d) (%d %d)\n", k,s1,t1,s2,t2);
					fprintf(arg_get_fp("log_fp"),"i: %d, twin i %d , j: %d twin j : %d\n", i,twin_i,j,twin_j);
				}
				//make the switch
				//update edges array
				RN->e_arr_dbl[i].t=t2;
				RN->e_arr_dbl[twin_i].s=t2;
				RN->e_arr_dbl[j].t=t1;
				RN->e_arr_dbl[twin_j].s=t1;
				if(DEBUG_LEVEL==1) {
					fprintf(arg_get_fp("log_fp"),"(%d %d) (%d %d) (%d %d) (%d %d)\n",
						RN->e_arr_dbl[i].s,RN->e_arr_dbl[i].t,
						RN->e_arr_dbl[twin_i].s,RN->e_arr_dbl[twin_i].t,
						RN->e_arr_dbl[j].s,RN->e_arr_dbl[j].t,
						RN->e_arr_dbl[twin_j].s,RN->e_arr_dbl[twin_j].t
						);
				}
				
				//update matrix
				MatAsgn(RN->mat,s1,t1,0);
				MatAsgn(RN->mat,t1,s1,0);
				MatAsgn(RN->mat,s2,t2,0);
				MatAsgn(RN->mat,t2,s2,0);
				if(DEBUG_LEVEL==1)
					dump_network(arg_get_fp("log_fp"),RN);
				MatAsgn(RN->mat,s1,t2,1);
				MatAsgn(RN->mat,t2,s1,1);
				MatAsgn(RN->mat,s2,t1,1);
				MatAsgn(RN->mat,t1,s2,1);
				if(DEBUG_LEVEL==1)
					dump_network(arg_get_fp("log_fp"),RN);
				k++;
			}
		}
		if(w==dbl_num_of_switchs*DESPAIR_RATIO && dbl_num_of_switchs>0) {
			if(arg_get_int("quiet_mode")==FALSE)
				fprintf(stdout,"Reached Despair ratio\n");
			else
				fprintf(arg_get_fp("log_fp"),"Reached Despair ratio\n");
		}
		
		
		
		//Switch single edges	
		
		if(RN->e_sin_num<=1)
			sin_num_of_switchs=0;
		else
			// num of switches is round(10*(1+rand)*#edges)
			sin_num_of_switchs=(10+get_rand(10))*RN->e_sin_num;
		k=0,w=0;
		
		while(k<sin_num_of_switchs && w<sin_num_of_switchs*DESPAIR_RATIO) {
			w++;
			//get random indexes for edges
			i=get_rand(RN->e_sin_num); 
			while ((j=get_rand(RN->e_sin_num)) == i);
			
			s1=RN->e_arr_sin[i].s;
			t1=RN->e_arr_sin[i].t;
			s2=RN->e_arr_sin[j].s;
			t2=RN->e_arr_sin[j].t;
			
			//check : 1.that there are no crossing edges,
			//		  2.there are no common vertices of these 2 edges
			//if hasnt passed the check then have to find other pair to switch
			if ( !(MatGet(RN->mat,s1,t2) || MatGet(RN->mat,s2,t1)|| MatGet(RN->mat,t2,s1) || MatGet(RN->mat,t1,s2))
				&&(s1!=s2) && (s1!=t2) && (t1!=s2) && (t1!=t2) ) {
				//make the switch
				//update edges array
				RN->e_arr_sin[i].t=t2;
				RN->e_arr_sin[j].t=t1;
				//update matrix
				MatAsgn(RN->mat,s1,t1,0);
				MatAsgn(RN->mat,s2,t2,0);
				MatAsgn(RN->mat,s1,t2,1);
				MatAsgn(RN->mat,s2,t1,1);
				
				k++;
			}
		}
		if(DEBUG_LEVEL>1)
			dump_network(stdout,RN);
		
		if(w==sin_num_of_switchs*DESPAIR_RATIO && sin_num_of_switchs>0) {
			if(arg_get_int("quiet_mode")==FALSE)
				fprintf(stdout,"Reached Despair ratio\n");
			else
				fprintf(arg_get_fp("log_fp"),"Reached Despair ratio\n");
		}
		
		
		
		//check that there are no self edges. If there are any then start again
		rand_network_checked = TRUE;
		for(i=1;i<=RN->vertices_num;i++) {
			if( MatGet(RN->mat,i,i)==1 ) {
				printf("Self edges still exist building random graph again\n");
				rand_network_checked=FALSE;
				free_network_mem(RN);
				break;
			}
		}
	}

	//merge lists to RN->e_arr
	//
	j=0;
	for(i=1;i<=RN->e_dbl_num;i++) {
		RN->e_arr[++j].s=RN->e_arr_dbl[i].s;
		RN->e_arr[j].t=RN->e_arr_dbl[i].t;
	}
	for(i=1;i<=RN->e_sin_num;i++) {
		RN->e_arr[++j].s=RN->e_arr_sin[i].s;
		RN->e_arr[j].t=RN->e_arr_sin[i].t;
	}
	

	
	/**************************************************************/
	/**************************************************************/
	/**************************************************************/
	/* Part II - metropolis algorithm. Perform switches with probability*/
	/**************************************************************/
	/**************************************************************/
	/**************************************************************/
	
	/**************************************************************/
		/* metropolis parameters depend on num_of _switches*/
	
	
	/* otuput real network to _METROP file */

	
	
	res_tbl_ini(&met_res_tbl);
	list_init(&met_res_tbl.real);
	met_motifs_search_real(RN,&met_res_tbl,rand_vec13);
	list_free_mem(met_res_tbl.real);
	
	E1=energy(real_vec13,rand_vec13);
	
	w=0;
	fprintf(arg_get_fp("mat_metrop_fp"),"\nreal network\n");
	fprintf(arg_get_fp("mat_metrop_fp"),"E=%lf T=%lf\n",E1,t);
	fprintf(arg_get_fp("mat_metrop_fp"),"Real triadic census :\n ");
	output13(real_vec13,arg_get_fp("mat_metrop_fp"));
	fprintf(arg_get_fp("mat_metrop_fp"),"random network\n");
	fprintf(arg_get_fp("mat_metrop_fp"),"%lf,%lf \n",E1,t);
	fprintf(arg_get_fp("mat_metrop_fp"),"Initial random triadic census :\n ");
	output13(rand_vec13,arg_get_fp("mat_metrop_fp"));


/*	nover=sin_num_of_switchs*arg_get_double("iteration_factor");
	nlimit=nover/10;
	k=0;
	num_at_t=0;
	sin_metrop_switches(&RN,nover,nlimit,arg_get_double("t_init"),real_vec13,rand_vec13);
*/	
	if (dbl_num_of_switchs==0)
	{
		snover=sin_num_of_switchs*arg_get_double("iteration_factor");
		snlimit=snover/10;
		t=sin_metrop_switches(&RN,snover,snlimit,arg_get_double("t_init"),real_vec13,rand_vec13);
	}
	else
	{
		
		dnover=dbl_num_of_switchs*arg_get_double("iteration_factor")/10;
		dnlimit=dnover/10;
		if (dnover<10)
		{
			
			dnover=dbl_num_of_switchs;
			dnlimit=dnover;
		}
		t=dbl_metrop_switches(&RN,dnover,dnlimit,arg_get_double("t_init"),real_vec13,rand_vec13);
	
		snover=sin_num_of_switchs*arg_get_double("iteration_factor")/10;
		snlimit=snover/10;
		k=0;
		num_at_t=0;
		t=sin_metrop_switches(&RN,snover,snlimit,t,real_vec13,rand_vec13);
		fprintf(arg_get_fp("mat_metrop_fp"),"End E\n");
		printf("End E\n");
		for (i=1;i<10;i++)
		{
			E2=energy(real_vec13,rand_vec13);
			if (E2>0)
			{
				t=dbl_metrop_switches(&RN,dnover,dnlimit,t,real_vec13,rand_vec13);
				t=sin_metrop_switches(&RN,snover,snlimit,t,real_vec13,rand_vec13);
			}
		}
	}

	//check that there are no self edges. If there are any then start again
	rand_network_checked = TRUE;
	for(i=1;i<=RN->vertices_num;i++) {
		if( MatGet(RN->mat,i,i)==1 ) {
			printf("Self edges still exist building random graph again\n");
			rand_network_checked=FALSE;
			free_network_mem(RN);
			break;
		}
	}
	
	//merge lists to RN->e_arr
	//
	j=0;
	for(i=1;i<=RN->e_dbl_num;i++) {
		RN->e_arr[++j].s=RN->e_arr_dbl[i].s;
		RN->e_arr[j].t=RN->e_arr_dbl[i].t;
	}
	for(i=1;i<=RN->e_sin_num;i++) {
		RN->e_arr[++j].s=RN->e_arr_sin[i].s;
		RN->e_arr[j].t=RN->e_arr_sin[i].t;
	}
	
	if(DEBUG_LEVEL>1) {
		fprintf(arg_get_fp("mat_metrop_fp"),"The network :\n");
		for (i=1;i<=RN->edges_num;i++)
			fprintf(arg_get_fp("mat_metrop_fp"),"%d %d %d\n",RN->e_arr[i].t,RN->e_arr[i].s,1);
		fprintf(arg_get_fp("mat_metrop_fp"),"End of network\n");
		fprintf(arg_get_fp("mat_metrop_fp"),"\n\n");
	}
	fprintf(arg_get_fp("mat_metrop_fp"),"Real triadic census :\n ");
	output13(real_vec13,arg_get_fp("mat_metrop_fp"));
	fprintf(arg_get_fp("mat_metrop_fp"),"Final random triadic census :\n ");
	output13(rand_vec13,arg_get_fp("mat_metrop_fp");
	
	*RN_p=RN;
	return RC_OK;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// end of metropolis routines
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
