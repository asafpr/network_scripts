#include <stdio.h>
#include "list.h"

#ifndef __PERMUTATION_H
#define __PERMUTATION_H


list		*get_mtf_subid(MotifID *id, int mtf_sz, int colors);
int		get_mtf_subid_min_con_vrtx_less(MotifID *sub_id_p, MotifID *id, int mtf_sz, int colors);
list		*mtf_id_iso_list(MotifID *id, int mtf_sz, int colors);
void		mtf_id_min_iso (MotifID *idc, MotifID *id, int mtf_sz, int **permutation, int colors);	

#endif
