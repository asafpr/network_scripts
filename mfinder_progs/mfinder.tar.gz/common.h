#ifndef __COMMON_H
#define __COMMON_H

#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include "switches.h"
#include "list.h"
#include "mat.h"
#include "motif.h"
#include "motif_res.h"

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// constants
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//general algorithm definitions
#define ZSCORE_TH       2  //z-score threshold
#define PVAL_TH         0.01 // p-value threshold
#define MFACTOR_TH      1.1 // mfactor threshold

#define DEFAULT_NEFF    2  //NEFF type to actually use 
#define NEFF_METHODS_NUM 5 //number of methods to calculate Neff

#define PROB_APP_TOTAL_OPS 7000
//#define PROB_APP_TOTAL_OPS 5188 //coli
//#define PROB_APP_TOTAL_OPS 13150 //yeast

//Random network generating despair ratio
//this value used to calculate the maximum tries to find proper candidates to exchnage
//despair num=switchs_num*DESPAIR_RATIO
#define DESPAIR_RATIO     50

//general
#define TRUE        1
#define FALSE       0

// error codes
#define RC_ERR      -1
#define RC_OK        0

#define INFINITY     0x0fffffff
#define EPSILON		0.000001

#define DEFAULT_RAND_NETWORK_NUM 10

#define REAL_NET     1
#define RAND_NET     2


#define SINGLE_EDGE   0
#define DOUBLE_EDGE   1

#define R_SWITCH_FACTOR      10

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// structures
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

typedef struct {
	list *real;				//	a list of motifs for the real network
	list **rand_arr;		//	a list of motifs for each random network
}Res_tbl;					//	each of the lists are such that the ->p is a *Motif and the key is MotifID.

typedef struct {
	time_t start; //start time;
	time_t end; //end time
	double elapsed; //elapsed time
} Runtime;


void	dump_time_measure(FILE* fp,char *text, Runtime *runtime);
FILE * myfopen (char *file_name, char * type);


////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//MACROS
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

#define MAT(N,i,j)      ( *(char*)(N->mat->full.m+((i-1)*(N->vertices_num))+(j-1)) )
//#define ASGN_MAT(N,i,j,val) ( *(char*)(N.m+(i*(N.vertices_num-1))+(j-1)) = val )
//#define GET_MAT(N,i,j)      ( *(char*)(N.m+(i*(N.vertices_num-1))+(j-1)) )




#endif
