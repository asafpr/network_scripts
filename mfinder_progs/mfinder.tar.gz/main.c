#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <math.h>
#include <string.h>
#include "common.h"
#include "list.h"
#include "mat.h"
#include "network.h"
#include "hash.h"
#include "permutation.h"
#include "metropolis.h"
#include "arguments.h"
#include "utilities.h"
#include "gen_rand_network.h"
#include "complementarity.h"

//	debug
// The following macros set and clear, respectively, given bits
// of the C runtime library debug flag, as specified by a bitmask.
#ifdef   _DEBUG
#define  SET_CRT_DEBUG_FIELD(a) \
            _CrtSetDbgFlag((a) | _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG))
#define  CLEAR_CRT_DEBUG_FIELD(a) \
            _CrtSetDbgFlag(~(a) & _CrtSetDbgFlag(_CRTDBG_REPORT_FLAG))
#else
#define  SET_CRT_DEBUG_FIELD(a)   ((void) 0)
#define  CLEAR_CRT_DEBUG_FIELD(a) ((void) 0)
#endif


/*************************** Global variables ****************************/

// seed for random number generator (to be replaced by user input)
long	seed=98765432;			//ss  yields 11700 switches on standard test input

//result table.	
Res_tbl RES_TBL, RES_TBL_SUB;

time_t start_time, end_time;

//if profiling is anabled
#ifdef ENABLE_PROFILE
int calls_to_list_get;
int calls_to_list_insert;
int calls_to_check_hist_hash;
int calls_to_hash_insert;
int while_length_list_get;
int while_length_list_insert;
#endif

/******************************* Externs *********************************/
extern void
init_random_seed();
extern void seed_set(long);

// return random integer in the interval 1 to max_val
extern int
get_rand(int max_val);
extern double get_rand_double();

/******************************* Declerations ****************************/
//void	init_res_tbl(Res_tbl *res);
int	motif_size_n_search_network(Network *N, int mtf_sz,list *res,int net_type, int motif_occr_dump, list *mtf_lst);
int calc_final_results(Res_tbl*res_tbl, int flag, list *res_sub_mtf, list **res_p, list **res_all_p, int rnd, int colors);
void	bipartiate_analysis (Network *N, FILE *f, int color, int *success, int *quad);


///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	initialize a structure of type 'Res_tbl'
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	res_tbl_ini(Res_tbl *res)
{
	int i;
	int	rnd_net_num = arg_get_int("rnd_net_num");

	list_ini(&res->real, LIST_KEY_GEN);
	res->rand_arr=(list**)mycalloc(rnd_net_num, sizeof(list*));
	for(i=0; i<rnd_net_num; i++)
		list_ini((list**)&res->rand_arr[i], LIST_KEY_GEN);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void res_tbl_mem_free_single(list *L)
{
	list_item *item;
	Motif*	mtf;

	for(item=list_get_next(L,NULL);item!=NULL;item=list_get_next(L,item)) {
		if (item->p != NULL)	{
			mtf = (Motif*)item->p;
			if (mtf->members != NULL)
				list_free_mem(mtf->members);
		}
	}
	list_free_mem(L);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void res_tbl_mem_free(Res_tbl *res)
{
	int i;

// handling results of random networks
	for(i=0;i<arg_get_int("rnd_net_num");i++)
		res_tbl_mem_free_single (res->rand_arr[i]);
	myfree(res->rand_arr);

// handling results of the real network
	res_tbl_mem_free_single (res->real);
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// check if equivalent set is in the hash
// important assumption - lists are sorted in increasing order
// returns :	TRUE - if yes
//		FALSE - if not
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int	check_hist_hash(Hash *hash, int *set_arr)
{
	int key,i;
	list_item *tmp;
	int *hist_set_arr;
#ifdef ENABLE_PROFILE
	calls_to_check_hist_hash++;
#endif
	if (set_arr==NULL)
		return FALSE;

	key=hash_get_key(hash,set_arr);
	if (hash->h[key] == NULL)
		return FALSE;

	for(tmp=list_get_next(hash->h[key],NULL); tmp; tmp=list_get_next(hash->h[key],tmp) ) {
			hist_set_arr=(int*)tmp->p;
			//compare the lists. if all item vals are equal then return TRUE otherwise return FALSE
			for(i=0;i<hash->bckt_sz;  i++) {
					if(set_arr[i] != hist_set_arr[i])
						break;
			}
			//if reached end of arrays - means they are identical
			if(i==hash->bckt_sz)
				return TRUE;
	}
	return FALSE;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// (recursive) function : search_subset 
// Recursively, loop through connected subsets of vertices, the recursion ends when the vertex set has motif size.
// For vertex sets of the required size (motif size) the vertex set is encoded in the list of motifs.
// results are returned in 'mtf_lst'
// arguments:
// N: Network to be searched								inp
// vrtx_set: list of vertices that should be processed					inp
// hist_hash : hash table includes all sets of vertices already searched		inp
// mtf_sz: motif size									inp
// mtf_lst : list of motifs to which the routine should add the encountered motif	inp/out
// net_type :	REAL_NET - if real network						inp
// 		RAND_NET - if random network						inp
// int motif_occr_dump	- flag indicating whether to dump occurence of motifs		inp
// list *dmp_mtf_lst	- list of motifs that need to be dumped				inp
// FILE *log_fp		- file handle where logging is performed			inp
// return values:
// RC_OK - if not error occured
// RC_ERR - if error occured
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int search_subset(Network *N, list *vrtx_set, Hash *hist_hash, int mtf_sz, list *mtf_lst, int net_type, 
	int motif_occr_dump, list *dmp_mtf_lst, FILE *log_fp)
{
	int	i,k;
	list_item *item,*l_res_id,*l_edge;
	list	*lst;
	Network *SN;
	Motif	*mtf;
	MotifID mtf_id, mtf_id_min;
	Hash	*subset_hash;
	int	*cur_subset_arr;
	FILE	*motif_occr_fp = arg_get_fp("motif_occr_fp");
	int	calc_unique_flag = arg_get_int("calc_unique_flag");
	int	pcolors = (int)pow(2,N->colors);
	int	*permutation;
	char	*prog="search_subset";

#if	DEBUG_TRACE > 2
	printf("%s: entered to search for motifs of size %d in net type %d motif_occr_dump=%d\n", 
	prog, mtf_sz, net_type, motif_occr_dump);
#endif

#if AUTO_CHECK == 2
	fprintf(log_fp, "%s: entered to search for motifs of size %d in net type %d, vertex size=%d, N->mat->type=%d, FULL=%d\n",
		prog, mtf_sz, net_type, vrtx_set->size, N->mat->type, FULL);
	list_dump_short(log_fp, vrtx_set, "ss entered with vertex set: ", "");
	fprintf(log_fp, "(%d,%d)\n", mtf_sz, vrtx_set->size);
	fflush(log_fp);
#endif

// A. handle the case where the number of vertices in the vertex set is equal to motif size (this is the recursive base)
//    ------------------------------------------------------------------------------------------------------------------
// In this case (contrary to B. below) it is necessary to 
// * find the motif_id of the the vertex set (for that a network is generated from the vertex set)
// * add the motif_id to the results list 'mtf_lst' 
//   (distinguishing between the case that it is the first of its type and the case it is not)

	if (mtf_sz == vrtx_set->size) {
//	  printf("found motif\n");

// generate a sub-net ('SN' - it is, essentially, a submatrix) from the vertices set vrtx_set
	  network_generate_from_subset(N, &SN, vrtx_set, mtf_sz);// << >> there might be a more efficient way of doing that

//calculate the motif id of 'SN'
	  network_motif_id(&mtf_id, SN, N->colors, pcolors);

#if AUTO_CHECK == 2
	  fprintf(log_fp, "0 "); fflush(log_fp);
#endif

// The following old comment appeared here (applying to the case of two colors only):
// at the moment list "val" field is int means 32 bit therefore limited to motif size of 5
// will change val field to VERYLONGINT - then limited to motif size of 8

// dump motifs (if required). 
// Each motif is dumped as it is encountered so the dumped file includes each vertex set several times 
// (according to the number of sequences of edges that generates the vettex set).
// To elimiate this duplication the files needs to be sorted and unique values should be retained.
// The exact command line to perform this is presented in stdout when motif-occurence-dump is requested.

	  if (motif_occr_dump) {
#if AUTO_CHECK == 3
		fprintf(motif_occr_fp, "%s: when searching for motifs of size %d in net type %d, vertex size=%d, N->mat->type=%d, FULL=%d\n",
			prog, mtf_sz, net_type, vrtx_set->size, N->mat->type, FULL);
		list_dump_short(motif_occr_fp, vrtx_set, "vertex set: ", "");
		fprintf(motif_occr_fp, "(%d,%d)", mtf_sz, vrtx_set->size);
		motif_id_print (&mtf_id, motif_occr_fp,  "going to call motif_occurence_dump with the motif ", " ");
		motif_matrix_dump (motif_occr_fp, &mtf_id, 1, N->colors);
		mtf_id_min_iso(&mtf_id_min, &mtf_id, mtf_sz, &permutation, N->colors);
		motif_id_print (&mtf_id_min, motif_occr_fp,  "min motif ", "");
		motif_matrix_dump (motif_occr_fp, &mtf_id_min, 1, N->colors);
		fprintf (motif_occr_fp, "\n");
#endif
		// actually dump the motif to stream 'motif_occr_fp', unless its canonical ID doesn't appear 
		// in the nonempty list 'dmp_mtf_lst'.
		motif_occurence_dump(motif_occr_fp, vrtx_set, &mtf_id, mtf_sz, N->colors, dmp_mtf_lst, N->number);
	  }

// update mtf_lst list. note that mtf_lst is used (which is not necessarily minimal).
// the non-minimal motif IDs are eventually translated to minimal IDs by routine motif_size_n_search_network
// in a process that is somewhat more efficient than translating each motif individually to its minimal value.
// 1. handle the case that the motif does NOT appear in the results list 'mtf_lst'
	  if (!(l_res_id=list_get_by_key(mtf_lst, &mtf_id))){

#if AUTO_CHECK == 2
		fprintf(log_fp, "1 "); 	fflush(log_fp);
#endif
		mtf=motif_ini();
		memcpy (&(mtf->id), &mtf_id, sizeof(MotifID));
		mtf->count=1;
		list_init(&mtf->members);
		if(calc_unique_flag == TRUE && net_type == REAL_NET)
			motif_insert_members (mtf, vrtx_set, mtf_sz);
		list_ins(mtf_lst, &mtf_id, (void*)mtf);

// 2. handle the case that the motif DOES appear in the results list 'mtf_lst'
	  } else {

#if AUTO_CHECK == 2
	        fprintf(log_fp, "2 "); 	fflush(log_fp);
#endif

		mtf=(Motif*)l_res_id->p;
		mtf->count+=1;														//	increase count by one
		if(calc_unique_flag == TRUE && net_type == REAL_NET)	//	if calc unique option is on - 
			motif_insert_members (mtf, vrtx_set, mtf_sz);	//	add the new motif vertices set to motif memebers list 
	  }

// 3. cleanup & return
	  network_free(SN);				//free SN
	  //	motifs_dump (stdout, mtf_lst, "after search_subset completion");

#if AUTO_CHECK == 2
	  list_dump_short(log_fp, vrtx_set, "ss return recursive base ", "\n"); 	fflush(log_fp);
#endif

	  return RC_OK;
	}

// B. number of vertices in vrtx_set is smaller than the required motif size. increase vrtx_set and call again.
//    ---------------------------------------------------------------------------------------------------------
// There is a unique hash table for each subset size (according to the recursive depth).
// It is used to prevent inclusion of the same vertex set twice WHEN STARTING FROM A FIXED EDGE. 
// It DOES NOT prevent inclusion of the same vertex set twice WHEN STARTING FROM DIFFERENT EDGES.

	subset_hash=&hist_hash[vrtx_set->size+1];
	
// loop through neighbors of all vertices in vrtx_set, add them to the vertex set and call search_subset recursively

#if AUTO_CHECK == 2
	list_dump_short(log_fp, vrtx_set, "ss continue 1: ", "\n"); 	fflush(log_fp);
#endif
	item = vrtx_set->l;					// set initial value of current item in vertex set
	for(k=1; k<=vrtx_set->size; k++) {			// loop on vertex set (at the end of the loop 'item' is replaced by the next item in the vertex set)
	  if(N->mat->type == FULL) {				// handle the case of N having a FULL structure
	    for(i=1;i<=N->vertices_num;i++) {			// loop through row
		if(MatGet(N->mat,item->val,i)==1) {		// if a neighbor of the current item is in the vertices set
		  if(!list_get(vrtx_set,i)) {			// check if this neighbor is already in the vrtx_set. 
		    list_insert(vrtx_set,i,NULL);
		    cur_subset_arr=list_2_array(vrtx_set);			
		    if (check_hist_hash(subset_hash, cur_subset_arr)==FALSE) {	// check if such a subset was encountered 
			hash_insert(subset_hash,cur_subset_arr);		// if not encountered then add this neighbor to set
/* recursion */	        search_subset(N,vrtx_set,hist_hash,mtf_sz,mtf_lst,net_type, motif_occr_dump, dmp_mtf_lst, log_fp);

#if AUTO_CHECK == 2
			list_dump_short(log_fp, vrtx_set, "ss continue 2: ", "\n"); 	fflush(log_fp);
#endif
		    } else							// if already encountered - then just free
			myfree(cur_subset_arr);												
		    list_delete(vrtx_set,i);			// remove the last added edge so as to continue the main loop
		  }
		}
	    }	// end of for ...
#if AUTO_CHECK == 2
	    list_dump_short(log_fp, vrtx_set, "ss continue 3: ", "\n"); 	fflush(log_fp);
#endif
	    for(i=1;i<=N->vertices_num;i++) {			// loop through column
		if(MatGet(N->mat,i,item->val)==1) {		// if a neighbor of the current item is in the vertices set
		  if(!list_get(vrtx_set,i)) {			// check if this neighbor is already in the vrtx_set.
		    list_insert(vrtx_set,i,NULL);		// if not encountered: add neighbour to vertex set
		    cur_subset_arr=list_2_array(vrtx_set);			
		    if (check_hist_hash(subset_hash, cur_subset_arr)==FALSE) {	// check if a such a subset was encountered 
			hash_insert(subset_hash, cur_subset_arr);		// if not encountered then add this neighbor to set 
/* recursion */	        search_subset(N,vrtx_set,hist_hash,mtf_sz,mtf_lst,net_type, motif_occr_dump, dmp_mtf_lst, log_fp);
#if AUTO_CHECK == 2
			list_dump_short(log_fp, vrtx_set, "ss continue 4: ", "\n"); 	fflush(log_fp);
#endif
		    } else							// if already encountered - then just free
			myfree(cur_subset_arr);
		    list_delete(vrtx_set,i);			// remove the last added edge so as to continue the main loop
		  }
		}
	    }
	  } else {						// handle the case where the structure is sparse (not FULL) 
	    lst = N->mat->spr->m[item->val].to;			// loop through row on "to" neighbors of the current item
	    for(l_edge=list_get_next(lst,NULL);	l_edge; l_edge=list_get_next(lst,l_edge)) {
		if(!list_get(vrtx_set,l_edge->val)) {		// check if this neighbor is already in the vrtx_set.
		  list_insert(vrtx_set,l_edge->val,NULL);	// if not encountered: add neighbour to vertex set
		  cur_subset_arr=list_2_array(vrtx_set);			 
		  if (check_hist_hash(subset_hash, cur_subset_arr)==FALSE) {	// check if such a subset was encountered
			hash_insert(subset_hash, cur_subset_arr);		// if not encountered then add this neighbor to set
/* recursion */		search_subset(N,vrtx_set,hist_hash,mtf_sz,mtf_lst,net_type, motif_occr_dump, dmp_mtf_lst, log_fp);
#if AUTO_CHECK == 2
			list_dump_short(log_fp, vrtx_set, "ss continue 5: ", "\n"); 	fflush(log_fp);
#endif
		  } else							// if already encountered - then just free
			myfree(cur_subset_arr);
		  list_delete(vrtx_set,l_edge->val);		// remove the last added edge so as to continue the main loop
		}
	    }
#if AUTO_CHECK == 2
	    list_dump_short(log_fp, vrtx_set, "ss continue 6: ", "\n"); 	fflush(log_fp);
#endif
	    lst = N->mat->spr->m[item->val].from;		// loop through column on "from" neighbors of the current item
	    for(l_edge=list_get_next(lst,NULL);	l_edge; l_edge=list_get_next(lst,l_edge)) {
		if(!list_get(vrtx_set,l_edge->val)) {		// check if this neighbor is already in the vrtx_set.
		  list_insert(vrtx_set,l_edge->val,NULL);	// if not encountered: add neighbour to vertex set
		  cur_subset_arr=list_2_array(vrtx_set);			 
		  if (check_hist_hash(subset_hash, cur_subset_arr)==FALSE) {	// check if such a subset was encountered 
			hash_insert(subset_hash, cur_subset_arr);		// if not encountered then add this neighbor to set
/* recursion */		search_subset(N,vrtx_set,hist_hash,mtf_sz,mtf_lst,net_type, motif_occr_dump, dmp_mtf_lst, log_fp);
#if AUTO_CHECK == 2
			list_dump_short(log_fp, vrtx_set, "ss continue 7: ", "\n"); 	fflush(log_fp);
#endif
		  } else							// if already encountered - then skip
			myfree(cur_subset_arr);
		  list_delete(vrtx_set,l_edge->val);		// remove the last added edge so as to continue the main loop
		}
	    }
	  }
#if AUTO_CHECK == 2
	list_dump_short(log_fp, vrtx_set, "ss continue 8: ", "\n"); 	fflush(log_fp);
#endif
	  item = item->next;
	} // end of loop on vertex set   for(k=1; k<=vrtx_set->size; k++) {
#if AUTO_CHECK == 2
	list_dump_short(log_fp, vrtx_set, "ss returning to search_motifs after handling connected vertex sets including: ", "\n");
	fflush(log_fp);
#endif
	return RC_OK;
}

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// function : search motifs
// results are returned in res list
//
// arguments:
// N				-	(input) Network to be searched
// mtf_sz			-	(input) motif size
// res				-	(output) list pointer of results
// net_type	REAL_NET 	-	if real network
// 		RAND_NET 	-	if random network
// int motif_occr_dump		-	flag indicating whether to dump occurence of motifs
// list *mtf_lst_to_dump	-	list of motifs that need to be dumped
// return values:
// RC_OK - if not error occured
// RC_ERR - if error occured
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int	search_motifs(Network *N, int mtf_sz, list *res, int net_type, int motif_occr_dump, list *mtf_lst_to_dump)
{
	int	s,t,cnt,i;
	list	*vrtx_set;
	list_item *l_id;
	Hash	*hist_hash;	//history hash for subsets
	Motif	*mtf;
	static	tracer=0;
	FILE	*log_fp = NULL;
//	FILE	*ss_log_fp = NULL;
	char	*prog="search_motifs";

#if	DEBUG_TRACE > 2
	printf("%s: entered to search for motifs of size %d in net type %d, %d edges\n", 
	prog, mtf_sz, net_type, N->edges_num);
#endif
#if AUTO_CHECK == 2
//	ss_log_fp = fopen("search_subset_log", "w");
	log_fp = arg_get_fp("log_fp");
//	network_dump (ss_log_fp, N);
#endif
	
	list_init(&vrtx_set);
	//hist_hash=multi_hash_init(mtf_sz, N->vertices_num+1);

// loop through all edges in N, insert their two incident vertices into a vertex set and 
// extend this vetex set to all possible connected vertex sets of size mtf_sz
	for(i=1;i<=N->edges_num;i++) {

// 1. insert the two vertices of the edge to a vertices set and call search_subset
		s=N->e_arr[i].s;
		t=N->e_arr[i].t;
		list_insert(vrtx_set, s, NULL);
		list_insert(vrtx_set, t, NULL);

// 2. initialize several hash tables, one table for each of the values 1,...,mtf_sz.
//    each hash table holds the history of all subsets that have already been searched, starting from this edge
		hist_hash=multi_hash_init(mtf_sz);

// 3. search subsets
		//printf("going to search with : %d  %d", s, t);
//		search_subset(N, vrtx_set, hist_hash, mtf_sz, res, net_type, motif_occr_dump, mtf_lst_to_dump, ss_log_fp);
		search_subset(N, vrtx_set, hist_hash, mtf_sz, res, net_type, motif_occr_dump, mtf_lst_to_dump, log_fp);

// 4. free memory (free hash history table and then remove these vertices from vertices set)
		multi_hash_free_mem(hist_hash, mtf_sz);
		list_delete(vrtx_set, s);
		list_delete(vrtx_set, t);

#if AUTO_CHECK == 2
//		if (i %10 == 0) {
			printf ("%s: after handling vertex %d \n", prog, i);
//			fclose(ss_log_fp);
//			ss_log_fp = fopen("search_subset_log", "w");
			fprintf (log_fp, "%s: after handling vertex %d \n", prog, i);
//			mymemory_check(log_fp, " - ", 1);
			fflush(log_fp);
//		}
#endif
	}
	list_free_mem(vrtx_set);

// loop through 'res' list and finalise the number of times each id appears.
// note that in the counting performed thus far there is a multiple counting: every motif occurence is counted once 
// for every edge that it has. To correct that, it is required to divide its count by the number of edges it has.
	for(l_id=list_get_next(res,NULL); l_id!=NULL; l_id=list_get_next(res,l_id)) {
		mtf = (Motif*)l_id->p;
		cnt = motif_count_edges (mtf, N->colors);
		if (cnt)
			mtf->count=(double)(mtf->count/cnt);
	}

#if	DEBUG_TRACE > 2
	printf("%s returning with %d motifs\n", prog, res->size);
#endif
#if	DEBUG_TRACE > 4
	motifs_dump (stdout, res, "");
#endif
	return RC_OK;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// probabilistic routines - those required for the probabilistic approach
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef PROBAPPROACH
#include "main_prob.c"
#endif
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// end of probabilistic routines
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// metropolis routines - those required for the metropolis approach
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
#ifdef METROAPPROACH
#include "main_metropolis.c"
#endif
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// end of metropolis routines
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	process_rand_networks is the main routine for handling the random networks (generating them and processing them).
//	it can operate in several modes (exhaustive, metropolis, proabilistic)
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int process_rand_networks(Network *G_N, Res_tbl *res_tbl, Res_tbl *sub_res_tbl, int mtf_sz, 
	list **final_res, list **final_res_all, list *mtf_lst_to_dump)
{
	int	rc=RC_OK;
	int	i,j,k,l;
	Network *RN;
	int	time_display_flag=0;
	int	sub_motif_flag;
	time_t strt_time, curr_time;
	double elapsed_time, estimated_time;
	Res_tbl met_res_tbl;
	int	real_vec13[14];
	list	*res_sub_motif = NULL;
	Runtime rt;
	int	quiet_mode = arg_get_int("quiet_mode");
	int	rnd_net_num = arg_get_int("rnd_net_num");
	char	*rnd_mode = arg_get_char("rnd");
	FILE	*log_fp = arg_get_fp("log_fp");
	int	stat_bipartiate = arg_get_int("stat_bipartiate");
	int	motif_occr_dump = arg_get_int("motif_occr_dump");
	int	pcolors = (int)pow(2,G_N->colors);
	char	rnd_net_file_name[25];
	FILE	*rnd_net_fp;
	char*	prog="process_rand_networks";

#if	DEBUG_TRACE > 0
	printf("%s: entered with out_intermediate flag=%d\n", prog, arg_get_int("out_intermediate"));
#endif

	for (i=1;i<=13;i++)
		real_vec13[i]=0;

//	set a flag required to control display
	sub_motif_flag = (arg_get_int("mtf_sz")!=mtf_sz) ? TRUE : FALSE;

// initialize random seed
	if(seed==0)					//ss	- logic of random seed was modified
		init_random_seed();			//ss	- so that consistent results can be achieved

//	initialize time monitoring
	time_measure_start("rand_net_time", &rt);	//for run time of random networks processing
	time(&strt_time);				//for time left approximation to the user


// major loop of generating random networks and processing them
// ------------------------------------------------------------

	for (i=0; i<rnd_net_num; i++) {

// generate a random network (the mode of generation varies according to several aspects of requirements)

#ifdef METROAPPROACH
		//if metropolis, use only for motif size >=4
		//if((arg_get_int("use_metropolis")==TRUE) && (arg_get_int("mtf_sz")>3) && !(sub_motif_flag))
		// shalev changed ^ so that neff is also claclulated for the same triadic census ensamble.
		if((arg_get_int("use_metropolis")==TRUE) && (arg_get_int("mtf_sz")>3))		
		{
			/* metropolis check - compute the 13 element vec on real network */
			fprintf(arg_get_fp("mat_metrop_fp"),"%d",G_N->vertices_num);
			fprintf(arg_get_fp("mat_metrop_fp"),"\nThe real network :\n");
			for (l=1;l<=G_N->edges_num;l++)
				fprintf(arg_get_fp("mat_metrop_fp"),"%d %d %d\n",G_N->e_arr[l].t,G_N->e_arr[l].s,1);
			fprintf(arg_get_fp("mat_metrop_fp"),"End of real network\n");

			res_tbl_ini(&met_res_tbl);
			met_motifs_search_real(G_N,&met_res_tbl,real_vec13);
			printf("real ok\n");
			list_free_mem(met_res_tbl.real);
			
			gen_rand_network_metrop(&RN,real_vec13);
		}
		else
#endif

		if (rnd_mode[0]==' ' || rnd_mode[0]=='d' || rnd_mode[0]=='p') {
			gen_rand_network_conserve_profiles(&RN, G_N, i+1, log_fp, arg_get_int("r_switch_factor"), quiet_mode);
		} else {
			printf ("illegal randomization mode. program aborted\n");
			exit (-1);
		}

		// output random network, if required
		if (arg_get_int("out_random_flag")) {
			sprintf (rnd_net_file_name, "random_network_%4.4d\0", i+1);
			rnd_net_fp = fopen(rnd_net_file_name, "w");
			network_export_standard (RN, rnd_net_fp);
			fclose(rnd_net_fp);
		}

#ifndef NODEG
// check degrees of vertices
		if (DEBUG_LEVEL>=0) {
			fprintf(log_fp,"----random network %d\n",i);
			//network_dump(stdout, RN);

			for(j=1;j<=RN->vertices_num;j++) {
				RN->indeg[j]=0;
				RN->outdeg[j]=0;
			}
			for (j=1; j<=G_N->vertices_num;j++){
				for(k=1;k<=G_N->vertices_num;k++){
					RN->outdeg[j]+=MatGet(RN->mat,j,k);
				}
			}
			for (j=1; j<=G_N->vertices_num;j++){
				for(k=1;k<=G_N->vertices_num;k++){
					RN->indeg[j]+=MatGet(RN->mat,k,j);
				}
			}
			//check real and rand all nodes degree are equal
			for(j=1; j<=G_N->vertices_num;j++){
				if(G_N->indeg[j]!=RN->indeg[j]) {
					fprintf(stdout,"single node statistics not conserved ! , in deg node %d\n",j);
					fprintf(log_fp,"single node statistics not conserved ! , in deg node %d\n",j);
				}

				if(G_N->outdeg[j]!=RN->outdeg[j]) {
					fprintf(stdout,"single node statistics not conserved ! , out deg node %d\n",j);
					fprintf(log_fp,"single node statistics not conserved ! , out deg node %d\n",j);
				}
			}
		}
#endif

// this section is intended to test bugs in profile-based-swiching, for a limited period.
#ifdef AUTO_CHECK
		if (!i%5) {	//	note that the check is sporadic

			//	check that the random network is consistent
			if (!network_check (stdout, RN))
				printf("random network %d is inconsistent\n", i+1);
			else
				printf("confirmed random network %d is OK. eventually remove this\n", i+1);

			//	check that the random network has the same edge degrees as the real network
			edge_profile_classify (RN);
			for (j=0; j<PROFILES; j++)
				if(G_N->profs[j] != RN->profs[j])
					fprintf (stdout, "profile %d has frequency %d in real network and %d in random network\n",
					j, G_N->profs[j], RN->profs[j]);
		}
#endif

//	bipartiate analysis
		if (stat_bipartiate) {
			for (j=0; j<1+G_N->colors; j++) 
				bipartiate_analysis(RN, log_fp, j, NULL, NULL);
			fprintf (log_fp, "bipartiate analysis completed ----------------------\n");
		}

// analyze the random network
// 1. handle for motifs of size n-1	
//	a. search for motifs								motif_size_n_search_network
//	b. aggregate these motifs							motif_list_unify_isomorphic
// 	c. produce statistics on them 							calc_final_results
//			(if intermediate cummulative statistics are required)
// 2. handle for motifs of size n
//	a. search for motifs								motif_size_n_search_network
//	b. aggregate these motifs							motif_list_unify_isomorphic
// 	c. produce statistics on them 							calc_final_results
//			(if intermediate cummulative statistics are required)
// 3. free memory of motif results (unless final round)
// the logic is slightly more complex than described above since the program can work in a mode where the statistics
// are required after each random network (so that it can be stopped at any time) or, alternatively, the statistics
// are required only once - at the end.

//search for subgraph size n-1 (actually sub_res_tbl->rand_arr[i] is RES_TBL_SUB.rand_arr[i])
		motif_size_n_search_network(RN, mtf_sz-1, sub_res_tbl->rand_arr[i], RAND_NET, 0, NULL);
#ifdef AUTO_CHECK
		// sanity check: confirm that the motif results of the random network have an acceptable structure
		if (list_check (sub_res_tbl->rand_arr[i]) > 0) {
			printf ("RES_TBL_SUB.rand_arr[%d] has an error\n", i);
			return -1;
		}
#endif
		motif_list_unify_isomorphic(&sub_res_tbl->rand_arr[i], mtf_sz-1, G_N->colors);
		//calculate final results, if required
		if(arg_get_int("out_intermediate") || i==rnd_net_num-1) 
			calc_final_results(&RES_TBL_SUB, TRUE, NULL, &res_sub_motif, NULL, i+1, G_N->colors);

//search for subgraph size n (actually res_tbl->rand_arr[i] is RES_TBL.rand_arr[i])
		motif_size_n_search_network(RN, mtf_sz, res_tbl->rand_arr[i], RAND_NET, motif_occr_dump, mtf_lst_to_dump);
//		motif_size_n_search_network(RN, mtf_sz, res_tbl->rand_arr[i], RAND_NET, 0, NULL);
#ifdef AUTO_CHECK
		// sanity check: confirm that the motif results of the random network have an acceptable structure
		if (list_check (res_tbl->rand_arr[i]) > 0) {
			printf ("RES_TBL.rand_arr[%d] has an error\n", i);	
			return -1;
		} 
#endif
		motif_list_unify_isomorphic(&res_tbl->rand_arr[i], mtf_sz, G_N->colors);
		//	calculate final results
		if(arg_get_int("out_intermediate") || i==rnd_net_num-1) {
			calc_final_results(&RES_TBL, FALSE, res_sub_motif, final_res, final_res_all,i+1, G_N->colors);
			final_res_free (res_sub_motif);
		}
		//	dump final results to the results file, if required
		if(arg_get_int("out_intermediate") && i<rnd_net_num-1) {
			dump_final_res(arg_get_fp("inter_out_fp"), *final_res_all, arg_get_int("mtf_sz"), arg_get_int("actual_n_eff"));
			final_res_free (*final_res);
			final_res_free (*final_res_all);
		}

// deallocation
		network_free(RN);

// time monitoring
		time_measure_stop("total_time", &rt);
//
		if(!quiet_mode)
			printf(".");
		time_display_flag++;
		//throw some hint about time left (do not through if submotif searching)
		if((time_display_flag==rnd_net_num/10) && !sub_motif_flag ) {
			time(&curr_time);
			elapsed_time = difftime( curr_time, strt_time );
			estimated_time = elapsed_time * (rnd_net_num-(i+1)) / (i+1);
			if (estimated_time > 18000) {
				//display message in hours
				estimated_time /=3600;
				if (!quiet_mode)
					printf("\n Estimated run time left : %6.0f hours.\n", estimated_time);
			}
			else if (estimated_time > 300) {
				//display message in minutes 
				estimated_time /=60;
				if (!quiet_mode)
					printf("\n Estimated run time left : %6.0f minutes.\n", estimated_time);
			}
			else {
				//display message in seconds
				if (!quiet_mode)
					printf("\n Estimated run time left : %6.0f seconds.\n", estimated_time );
			}
			time_display_flag=0;
			printf("\n");
		}
	}
	time_measure_stop("rand_net_time", &rt);

	printf("\n");
#if	DEBUG_TRACE > 2
	printf("%s: returned with final_res=%p\n", prog, *final_res);
#endif

	return rc;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// the routine is given, as input, a structure of motif results (a list of motifs for the real network and 
// an array of lists of motifs (one for each random network)). It has two separate functions:
// A. Calculating results for motifs encountered in the real network - summarize the motifs into a Motif_res structure.
//	for each motif encountered in the real network, the results are aggregated in a Motif_res structure. 
//	All the Motif_res structures are maintained in a list which is returned in 'res_p'.
// B. Calculating results of all possible IDs. 
//	this part is performed conditionally if sub_flag == FALSE and if motif size < 4 (otherwise takes too much time).
//	the flow is as follows:
//		generate a list ('all_pos_ids') composed of all possible motif id's for the given motif size.
//		more specifically: loop through all integers that can serve as motif-id
//			check if legal id , 
//				1. check if do not contain self edges
//				2. check there is no isolated vertex (a vertexs with no edges at all)
//					this is done by checking that there is at list one edge at each row i or column i of the matrix
//					(by bit manipulation)
//				3.	check - connectivity
//				nadav - to add here
//			if legal - add the cannonical motif isomorphic to the given motif into 'all_pos_ids', 
//			unless it is already there.
//		pass through all possible ids ('all_pos_ids', the list prepared above) and collect the results in 'all_ids_res'.
//		more specifically: loop through 'all_pos_ids'
//			for each .val in the list (which indicates a motif), establish a Motif_res
//			if found in real network then get its score else the score is zero
//			calculate the motif results statistics
//			add the motif result to the list 'all_ids_res' 
//		point the output argument 'res_all_p' to 'all_ids_res'
//
// called by: process_rand_networks, in the following contexts -
//	//search for subgraph size n-1
//	motif_size_n_search_network(RN, mtf_sz-1, sub_res_tbl->rand_arr[i], RAND_NET, ...);
//	motif_list_unify_isomorphic(&sub_res_tbl->rand_arr[i], mtf_sz-1, colors);
//	calc_final_results(&RES_TBL_SUB, TRUE, NULL, &res_sub_motif, NULL, i+1, colors);
//	//search for subgraph size n
//	motif_size_n_search_network(RN, mtf_sz, res_tbl->rand_arr[i], RAND_NET, ...);
//	motif_list_unify_isomorphic(&res_tbl->rand_arr[i], mtf_sz, colors);
//	calc_final_results(&RES_TBL, FALSE, res_sub_motif, &final_res, &final_res_all,i+1, colors);
// in the first call the 1-st input argument is RES_TBL_SUB and the second argument indicates it is a processing of 
// sub-motifs and there is no need to produce results of sub motifs (3-rd argument).
// in the second call the 1-st input argument is RES_TBL and the second argument indicates it is not a processing of 
// sub-motifs and the results of sub motifs are provided in  the 3-rd argument.
//
// arguments:
// Res_tbl*res_tbl		//	input - results table. a list of motifs for the real network and 
//				//		an array of lists of motifs (one list for every random network)
// int sub_flag			//	input - flag indicating whether the routine is to process sub motifs. 
// list *res_sub_mtf		//	input - list of motif results for sub motifs. not always provided.
// list **res_p			//	output - list of entities of type Motif_res for motifs encountered in res_tbl->real
// list **res_all_p		//	output - list of entities of type Motif_res for all possible motifs
// int rnd_net_num		//	input - number of random nets
// int colors			//	input - colors
//
// comments on the historical code (need to confirm all was handled properly): 
// 1. all_pos_ids is allocated memory and that memory is not freed.
// 2. when the routine is called beyond the 1-st time the pointers list **res_p and list **res_all_p
//	point to initialized structures. these need to be freed when called again.
// 3. the routine calls the global results structures RES_TBL and RES_TBL_SUB
//
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int calc_final_results(Res_tbl *res_tbl, int sub_flag, list *res_sub_mtf, list **res_p, list **res_all_p, 
			int rnd_net_num, int colors)
{
	list_item *l_id_res,*l_tmp;
	Motif_res *mtf_res;
	list	*final_res;	// a list of entities of type Motif_res for real motifs. Eventually it becomes *res_p
	list	*all_ids_res;	// a list of entities of type Motif_res for all possible motifs. Eventually becomes *res_all_p
	list	*all_pos_ids;	// a list of all possible (legal) motifs
	MotifID id;		// motif id to loop through all possible motif IDs
	MotifID idc;		// cannonical id 
	int	i,j;
	int	illegal_id;
	int	*permutation;
	FILE	*log_fp = arg_get_fp("log_fp");
	int	mtf_sz = arg_get_int("mtf_sz");
	char	*prog="calc_final_results";
	
#if	DEBUG_TRACE > 2
	printf("%s: entered with %d real motifs, sub_flag=%d, res_sub_mtf=%p, rnd_net_num=%d, colors=%d\n", 
	prog, res_tbl->real->size, sub_flag, res_sub_mtf, rnd_net_num, colors);
#endif

//	Part A - loop on motifs encountered in the real network and, for each, establish a motif result.
// Calculate the appropriate statistics composing it and add it to the output list.

	list_ini(&final_res, LIST_KEY_GEN);

	for(l_id_res=list_get_next(res_tbl->real,NULL); l_id_res; l_id_res=list_get_next(res_tbl->real,l_id_res)) {
			mtf_res = motif_res_ini();
			list_element_key_get(l_id_res, (void *)&(mtf_res->id));
			mtf_res->real_count=(double)((Motif*)(l_id_res->p))->count;
			mtf_res->conc_real=((Motif*)(l_id_res->p))->conc;
			//subset motif results
			if (sub_flag==TRUE) {
				motif_res_calc_deviation(mtf_res,&RES_TBL_SUB,rnd_net_num);
				motif_res_calc_pval(mtf_res,&RES_TBL_SUB,rnd_net_num);
				motif_res_calc_zscore(mtf_res);
				//Neff of submotif is zero no need to call motif_res_calc_n_eff;
			} else {
				//full set motif results
				motif_res_calc_deviation(mtf_res, &RES_TBL, rnd_net_num);
				if (res_sub_mtf) motif_res_calc_n_eff(mtf_res, res_sub_mtf, colors);
				motif_res_calc_pval(mtf_res,&RES_TBL,rnd_net_num);
				motif_res_calc_zscore(mtf_res);
				mtf_res->unique_appear=((Motif*)(l_id_res->p))->members->size;
			}
			list_ins(final_res, &(mtf_res->id), (void*)mtf_res);
	}
	*res_p=final_res;

//	Part B - (performed conditionally) calculating results for all possible IDs
//	if the routine was called to process submotifs or if the processing would take too long then this is skipped
//	
	//	if motif size is greater than 4 or COLORS > 1 then skip this (takes too much time)
//	if ((sub_flag == FALSE) && mtf_sz<=4){
	if ((sub_flag == FALSE) && mtf_sz<=4 && COLORS == 1){

		//	B.1 generate a list ('all_pos_ids') with all possible legal motifs id for the motif size
		list_ini(&all_pos_ids, LIST_KEY_GEN);

		motif_id_minimal (&id, mtf_sz, colors);
		while (TRUE) {

			//	check if legal id
			illegal_id=FALSE;

			//	B.1.1 First check - confirm the motif does not contain self edges
			if (motif_contains_self_loop (&id, mtf_sz))
				illegal_id = TRUE;

			//	B.1.2 Second check - confirm there is no isolated vertices (a vertex with no edges at all)
			if (motif_contains_isolated_vertex (&id, mtf_sz))
				illegal_id = TRUE;

			//	B.1.3 third check - connectivity
			//nadav - to add here
			//temporary :nadav just for 4 size motifs - to be removed when I write a proper general third check
			if((mtf_sz==4) && (motif_is_int (&idc, 72) || motif_is_int (&idc, 388) || motif_is_int (&idc, 4680)))
				illegal_id = TRUE;

			//	B.1.4 skip illegal motif IDs
			if(illegal_id)
				continue;

			//	B.1.5 for legal motif IDs - add their canonical ID to the list (if not there already)
			mtf_id_min_iso (&idc, &id, mtf_sz, &permutation, colors);		//	get the canonical ID of 'id'
			if(!list_get_by_key(all_pos_ids, &idc)) 								//	if the cannonical key is not in 'all_pos_ids'
				list_ins(all_pos_ids, &idc, NULL);									//	insert the canonical key into the list

			if (!motif_id_next(&id, mtf_sz, colors))
				break;
		}

		//	B.2 loop through the list of all possible IDs and get all the results (collect the result in all_ids_res)
		list_ini(&all_ids_res, LIST_KEY_GEN);
		for(l_tmp=list_get_next(all_pos_ids,NULL); l_tmp; l_tmp=list_get_next(all_pos_ids,l_tmp)) {
			mtf_res=(Motif_res*)mycalloc(1,sizeof(Motif_res));
			list_element_key_get (l_tmp, (void *)&(mtf_res->id));
			mtf_res->eff_arr=(Neff_st*)mycalloc(NEFF_METHODS_NUM+1,sizeof(Neff_st));
			//	if te motif is found in the real network then get its score, else the score is zero
			if(l_id_res=list_get_by_key(res_tbl->real,&(mtf_res->id))) {
				mtf_res->real_count=(double)((Motif*)(l_id_res->p))->count;
				mtf_res->conc_real=((Motif*)(l_id_res->p))->conc;
			}else{
				mtf_res->real_count=0;
				mtf_res->conc_real=0;
			}
			//mtf_res->unique_appear=((Motif*)(l_id_res->p))->members->size;

			//subset motif results
			if (sub_flag==TRUE) {
				motif_res_calc_deviation(mtf_res, &RES_TBL_SUB, rnd_net_num);
				motif_res_calc_pval(mtf_res, &RES_TBL_SUB, rnd_net_num);
				motif_res_calc_zscore(mtf_res);
				//Neff of submotif is zero no need to call motif_res_calc_n_eff;
			} else {
				//full set motif results
				motif_res_calc_deviation(mtf_res, &RES_TBL, rnd_net_num);
				if (res_sub_mtf) motif_res_calc_n_eff(mtf_res, res_sub_mtf, colors);
				motif_res_calc_pval(mtf_res, &RES_TBL, rnd_net_num);
				motif_res_calc_zscore(mtf_res);
			}
			list_ins(all_ids_res,&(mtf_res->id),(void*)mtf_res);
		}
		*res_all_p=all_ids_res;
		list_free_mem(all_pos_ids);		//ss	<<	added a required memory deallocation
	}

#if	DEBUG_TRACE > 2
	printf("%s: returned final_res=%p, final_res_all=%p\n", prog, final_res, all_ids_res);
#endif

	return RC_OK;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// function : motif_size_n_search_network
// Search network for subgraphs (motifs) of size 'mtf_sz' and collect them into a list of motifs 'res'
// arguments:
// Network *N		-	Network to be searched
// int mtf_sz		-	motif size
// list *res		-	list pointer of results
// int net_type		-	REAL_NET - if real network
//             			RAND_NET - if random network
// int motif_occr_dump	-	flag indicating whether to dump occurence of motifs
// list *mtf_lst_to_dump-	list of motifs that need to be dumped
//
// return values	-	RC_OK - if not error occured
//				RC_ERR - if error occured
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int motif_size_n_search_network(Network *N, int mtf_sz, list *res, int net_type, int motif_occr_dump, list *mtf_lst_to_dump)
{
	int rc=RC_OK;
	char	*prog="motif_size_n_search_network";

#if	DEBUG_TRACE > 1
	printf("%s: entered to search for motifs of size %d in net_type=%d motif_dump=%d\n", 
	prog, mtf_sz, net_type, motif_occr_dump);
#endif

	if(arg_get_int("run_prob_app")==FALSE)
		search_motifs(N, mtf_sz, res, net_type, motif_occr_dump, mtf_lst_to_dump);
#ifdef PROBAPPROACH
	else
		search_motifs_prob(N, mtf_sz, res, net_type);
#endif

#if	DEBUG_TRACE > 1
	printf("%s: returning with %d motifs\n", prog, res->size);
#endif
	return rc;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// search for motifs in the real network
// arguments:
// Network *N			- inp network to be analysed
// list** motif_list_size_n	- out list to contain motifs of size n
// list** motif_list_size_n_1	- out list to contain motifs of size n-1
// list *mtf_lst_to_dump	- inp list of motifs to be dumped, if at all any dumping is required. 
//				-     if this list is not empty only the motifs in this list are, if at all, to be dumped
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int	motifs_search_real(Network *N, list **motif_list_size_n, list **motif_list_size_n_1, list *mtf_lst_to_dump)
{
	int	rc=RC_OK;
	Runtime	rt;
	int	mtf_sz=arg_get_int("mtf_sz");
	int	motif_occr_dump = arg_get_int("motif_occr_dump");
	char	*prog="motifs_search_real";

#if	DEBUG_TRACE > 0
	printf("%s: entered with mtf_sz=%d *motif_list_size_n=%p *motif_list_size_n_1=%p where RES_TBL.real=%p RES_TBL_SUB.real=%p\n", 
	prog, mtf_sz, *motif_list_size_n, *motif_list_size_n_1, RES_TBL.real, RES_TBL_SUB.real);
#endif

	time_measure_start("real_net_time", &rt);

//search motif size n (search motifs and unify isomorphic motifs)
	motif_size_n_search_network(N, mtf_sz, *motif_list_size_n, REAL_NET, motif_occr_dump, mtf_lst_to_dump);	
	motif_list_unify_isomorphic(motif_list_size_n, mtf_sz, N->colors);

//search motif size n-1 (search motifs and unify isomorphic motifs)
	motif_size_n_search_network(N, mtf_sz-1, *motif_list_size_n_1, REAL_NET, 0, NULL);
	motif_list_unify_isomorphic(motif_list_size_n_1, mtf_sz-1, N->colors);

//	time monitoring
	time_measure_stop("real_net_time", &rt);
	if(arg_get_int("quiet_mode")==FALSE)
		dump_time_measure(stdout, "Processing motifs in real network took:", arg_get_rt("real_net_time"));

#if	DEBUG_TRACE > 0
	printf("%s: returning with %d motifs of size %d and %d motifs of size %d\n", 
	prog, (*motif_list_size_n)->size, mtf_sz, (*motif_list_size_n_1)->size, mtf_sz-1);
#endif

	return rc;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	initialization of motif analysis
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int	motif_analysis_init()
{
	int rc=RC_OK;
	char	*prog = "motif_analysis_init";

#if	DEBUG_TRACE > 0
	printf("%s: entered\n", prog);
#endif

//	open files
	if(arg_get_int("out_s_mat_flag"))
		myfopenw_using_arg ("mat_s_fname", "mat_s_fp");

	if(arg_get_int("out_l_mat_flag"))
		myfopenw_using_arg ("mat_l_fname", "mat_l_fp");

	if(arg_get_int("out_metrop_mat_flag"))
		myfopenw_using_arg ("mat_metrop_fname", "mat_metrop_fp");

	if(arg_get_int("out_intermediate"))
		myfopenw_using_arg ("inter_out_fname", "inter_out_fp");

	if(arg_get_int("motif_occr_dump"))
		myfopenw_using_arg ("motif_occr_fname", "motif_occr_fp");

//	initialize results
	res_tbl_ini(&RES_TBL);
	res_tbl_ini(&RES_TBL_SUB);

	return rc;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	finalize resources used for motif analysis (close files)
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int	motif_analysis_close()
{
	if(arg_get_int("out_s_mat_flag"))		fclose(arg_get_fp("mat_s_fp"));
	if(arg_get_int("out_metrop_mat_flag"))		fclose(arg_get_fp("mat_metrop_fp"));
	if(arg_get_int("out_l_mat_flag"))		fclose(arg_get_fp("mat_l_fp"));
//	if(arg_get_int("out_intermediate"))		fclose(arg_get_fp("inter_out_fp"));
	if(arg_get_int("motif_occr_dump"))		fclose(arg_get_fp("motif_occr_fp"));
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// receive a file with one motif-id value in a line and create a list from these values.
// the pointers of the created list are all null.
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void motif_list_from_file(list **L, FILE *fp)
{
	long	key_val;
	char	key[MOTIF_ID_AND_LIST_KEY_SIZE+1];
	int	rc;
	int	*p;
	int	j, oneint;
	int	chunks = sizeof(MotifID)/sizeof(int);
	char	*hyph;
	MotifID id;
	char	*prog="motif_list_from_file";

#if	DEBUG_TRACE >= 0
	printf("%s: entered\n", prog);
#endif

	if (MOTIF_ID_AND_LIST_KEY_SIZE != sizeof(MotifID)) {
		printf ("%s cannot handle motifs of size different from VERYLONGINT %d %d\n", 
		prog, MOTIF_ID_AND_LIST_KEY_SIZE, sizeof(MotifID));
		exit (-1);
	}

	list_ini(L, LIST_KEY_GEN);
	p = (int *)&id;

	while ( (rc = fscanf(fp,"%s\n", &key) != EOF) ) {
		if (strlen(key)==0)
			continue;
//		printf ("%s %d\n", key, chunks);
		memset (&id, 0, sizeof(MotifID));
		hyph = strchr(key, '-');
		if (hyph) {
			*hyph = '\0';
			oneint = atoi(key);
			memcpy(p + chunks - 1, &oneint, sizeof(oneint));
			oneint = atoi(hyph+1);
			memcpy(p, &oneint, sizeof(oneint));
		} else {
			oneint = atoi(key);
//			memcpy(p + chunks - 1, &oneint, sizeof(oneint));
			memcpy(p, &oneint, sizeof(oneint));
		}
		list_ins ((*L), &id, NULL);
		motif_id_print (&id, stdout, "from motif_list_from_file:", "\n");
	}

//	list_dump (stdout, (*L));
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// routine performing the motif analysis
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int	motif_analysis (Network *RealN, int rnd_net_num)
{
	int	rc;
	int	i;
	Network	*N;
	list 	*final_res = NULL, *final_res_all = NULL;
	int	quiet_mode = arg_get_int("quiet_mode");
	int	mtf_sz = arg_get_int("mtf_sz");
	int	stat_bipartiate = arg_get_int("stat_bipartiate");
	FILE	*log_fp = arg_get_fp("log_fp");
	Runtime	rt;
	list	*mtf_lst_to_dump = NULL;

//	initialize motif analysis
	motif_analysis_init();

// create 'N' - a duplicate network of 'RealN'
	rc|=network_duplicate(RealN, &N, "real_network", RealN->number);
	if(rc==RC_ERR)
		exit(-1);
#ifdef AUTO_CHECK
	if (! network_check(stdout, N))
		printf ("N has a fault\n");
#endif

//  bipartiate analysis of the real networl (one analysis for each color)
	if (stat_bipartiate) {
		for (i=0; i<1+COLORS; i++) 
			bipartiate_analysis(N, log_fp, i, NULL, NULL);
		fprintf (log_fp, "bipartiate analysis completed ----------------------\n");
	}

//  if required to dump occurences of specifically indicated motifs - read the required motifs
	if(strlen (arg_get_char("required_motifs_fname")))	{
		arg_put_fp("required_motifs_fp", myfopen (arg_get_char("required_motifs_fname"), "r"));
		motif_list_from_file(&mtf_lst_to_dump, arg_get_fp("required_motifs_fp"));
		fclose(arg_get_fp("required_motifs_fp"));
	}

//  search motifs (of size n and n-1) in the real network
	if(!quiet_mode)
		printf("Searching motifs size %d on Real network...\n", mtf_sz);
	if(!arg_get_int("dont_search_real")) {
		rc |= motifs_search_real(N, &(RES_TBL.real), &(RES_TBL_SUB.real), mtf_lst_to_dump);
		if(rc==RC_ERR)
			exit(-1);
#ifdef AUTO_CHECK
		// check the motif results of the real network
		if (list_check (RES_TBL.real) > 0)
			printf ("RES_TBL.real has an error\n");	
		if (list_check (RES_TBL_SUB.real) > 0) {
			printf ("RES_TBL_SUB.real has an error\n");
			list_dump (stdout, RES_TBL_SUB.real);
		}
#endif
	}

// create random networks with the same characterisitcs as the input network and process them
	if (rnd_net_num) {

		// inform the user about searching motifs in random networks
		if(!quiet_mode)
			printf("Searching motifs on Random networks\n");

#ifdef METROAPPROACH
		if(arg_get_int("use_metropolis")) {
			/* metropolis check - compute the 13 element vec on real network */
			fprintf(arg_get_fp("mat_metrop_fp"),"%d",RealN->vertices_num);
			fprintf(arg_get_fp("mat_metrop_fp"),"\nThe real network :\n");
			for (i=1;i<=RealN->edges_num;i++)
				fprintf(arg_get_fp("mat_metrop_fp"),"%d %d %d\n",RealN->e_arr[i].t,RealN->e_arr[i].s,1);
			fprintf(arg_get_fp("mat_metrop_fp"),"End of real network\n");
		}
#endif

		rc|=process_rand_networks(RealN, &RES_TBL, &RES_TBL_SUB, mtf_sz, &final_res, &final_res_all, mtf_lst_to_dump);
		if(rc==RC_ERR)
			exit(-1);
	} else 
		calc_final_results(&RES_TBL, TRUE, NULL, &final_res, NULL, rnd_net_num, RealN->colors);

// outout results of motif analysis
	if(!quiet_mode)
		printf("Output results Results...\n");
	time_measure_stop("total_time", &rt);
	rc|=output_results(arg_get_fp("out_fp"), RealN, final_res, final_res_all);
	if(rc==RC_ERR)
		exit(-1);

// cleanup resources used for motif analysis (close files, free memory, etc.)
	motif_analysis_close();
	if (mtf_lst_to_dump) list_free_mem(mtf_lst_to_dump);	// free list of motifs to be dumped
	final_res_free(final_res);				// the memory that has been allocated by process_rand_networks
	final_res_free(final_res_all);
	res_tbl_mem_free(&RES_TBL);				// miscellaneous	
	res_tbl_mem_free(&RES_TBL_SUB);
	network_free(N); 													//	memory allocated from the main program

	return rc;
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//	termination that is relevant to all modes of operation
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
void	gnrl_close()
{
	Runtime	*rt;

//output time measure
	//random network elapsed time should be divided by random networks num
	rt = arg_get_rt("rand_net_time");
//	GNRL_ST.rand_net_time.elapsed /= (double)arg_get_int("rnd_net_num");
	rt->elapsed /= (double)arg_get_int("rnd_net_num");
	if(arg_get_int("quiet_mode")==FALSE) {
		dump_time_measure(stdout, "Application total runtime was:", arg_get_rt("total_time"));
		dump_time_measure(stdout, "Real network processing runtime was:", arg_get_rt("real_net_time"));
		dump_time_measure(stdout, "Single Random network processing runtime was:", arg_get_rt("rand_net_time"));
	}
	dump_time_measure(arg_get_fp("out_fp"), "Application total runtime was:", arg_get_rt("total_time"));
	dump_time_measure(arg_get_fp("out_fp"), "Real network processing runtime was:", arg_get_rt("real_net_time"));
	dump_time_measure(arg_get_fp("out_fp"), "Single Random network processing runtime was:", arg_get_rt("rand_net_time"));

//	close files
	fclose(arg_get_fp("out_fp"));
	fclose(arg_get_fp("log_fp"));
}

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
int	main(int argc, char *argv[])
{
	int 	rc;				//	return code
	Runtime	rt;
	FILE 	*log_fp;
	int	rnd_net_num;
	int	quiet_mode;
	char	*rnd_mode;
	Network *RealNet=NULL;
	int	mtf_sz;

//	initialization
//	--------------

//	setting memory tracing
	mymem_init (0, 0, "");
#ifdef AUTO_CHECK
	mymem_init (0, 1, "Running mfinder with memory control. this is very very slow and intended only for debugging");
	printf("Program runs in a slow AUTO-CHECK mode\n");
#endif

#ifdef ENABLE_PROFILE	
	calls_to_list_get=0;
	calls_to_list_insert=0;
	calls_to_check_hist_hash=0;
	calls_to_hash_insert=0;
	while_length_list_get=0;
	while_length_list_insert=0;
#endif

//	check types
	if (sizeof (MotifID) != sizeof(ListKey) || sizeof (MotifID) % sizeof(int) != 0) {
		printf ("size of motif-id (%d) and size of list key (%d) and size of int (%d) are incompatible - program aborts\n",
		sizeof (MotifID), sizeof(ListKey), sizeof(int));
		exit (-1);
	}

//	time measurement initialization
	time_measure_start("total_time", &rt);

//	process input arguments and set the global repository of command line arguments
	rc |= process_input_args(argc,argv);
	if(rc==RC_ERR)
		exit(-1);

//open out file
	myfopenw_using_arg ("out_fname", "out_fp");

//open log file
//	if (DEBUG_LEVEL > 0 || arg_get_int("quiet_mode")) 
	myfopenw_using_arg ("log_fname", "log_fp");

//	set the seed of the random number generator
	if (seed!=0)	
		seed_set(seed);
	else
		init_random_seed();
	
//set a local version of some run-time arguments
	log_fp = arg_get_fp("log_fp");
	quiet_mode = arg_get_int("quiet_mode");
	rnd_mode = arg_get_char ("rnd");
	rnd_net_num = arg_get_int("rnd_net_num");
	mtf_sz = arg_get_int("mtf_sz");

//	initialize memory required to calculate minimal isomorphic motif id
	mtf_id_min_iso_alloc(mtf_sz);

// load network (read it from an input file and construct from it 'RealNet')
	if(!quiet_mode)
		printf("Loading Network\n");
	network_load(&RealNet, arg_get_char("input_network_fname"), arg_get_int("undirected_flag"), arg_get_int("ts"), log_fp);
	if (! network_check(stdout, RealNet))
		printf ("RealNet has a fault\n");	//ss

//	analysis
//	--------
	if (rnd_mode[0]=='s')
		complementary_features_analysis (RealNet, log_fp, rnd_net_num);	// perform complementary features analyze
	else
		motif_analysis (RealNet, rnd_net_num);				// perform motifs analyse

//	finalization
//	------------

//	free memory
	network_free(RealNet);							// free memory allocated from the main program
	mtf_id_min_iso_free();							// free memory required to calculate minimal isomorphic motif id

//	close files and run-time statistics
	gnrl_close();

//	inform user of output files
	if(!quiet_mode) {
		if(arg_get_int("out_s_mat_flag"))
			printf("\nMatrix output file '%s' was generated\n", arg_get_char("mat_s_fname"));
		if(arg_get_int("out_l_mat_flag"))
			printf("Long Matrix output file '%s' was generated\n", arg_get_char("mat_l_fname"));
		if(arg_get_int("motif_occr_dump")) {
			printf("Motif occurence file '%s' was generated\n", arg_get_char("motif_occr_fname"));
			printf("  The file contains more then one instance of each vertex set of size > 2\n");
			printf("  to get a unique occurence on Unix run\n");
			printf("  sort -k1,%d -u %s > %s_unq\n", 
			mtf_sz < 4 ? 3 : 5, arg_get_char("motif_occr_fname"), arg_get_char("motif_occr_fname"));
		}
		printf("\nOutput File '%s' was generated\n", arg_get_char("out_fname"));
	}

#ifdef AUTO_CHECK
	mymemory_check(stdout, "at end", 1);
	printf("Program ran in a slow AUTO-CHECK mode\n");
#endif

#ifdef ENABLE_PROFILE
	printf("calls_to_list_get :%d\n",calls_to_list_get);
	printf("calls to hash_get :%d\n",calls_to_check_hist_hash);
	printf("while_length_list_get :%.2f\n",(double)while_length_list_get/(double)calls_to_list_get);
	printf("calls_to_list_insert :%d\n",calls_to_list_insert);
	printf("calls_to_hash_insert %d\n", calls_to_hash_insert);
	printf("while_length_list_insert :%.2f\n",(double)while_length_list_insert/(double)calls_to_list_insert);
#endif

#ifdef _DEBUG
	_CrtDumpMemoryLeaks( );
	SET_CRT_DEBUG_FIELD( _CRTDBG_LEAK_CHECK_DF );
#endif 
	return rc;
}


