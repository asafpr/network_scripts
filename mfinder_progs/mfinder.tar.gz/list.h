#ifndef __LIST_H
#define __LIST_H


#include <stdio.h>
#include "switches.h"

//	here we maintain two types of lists. one with an integer key (.val) and another with an abstruct key

#define LIST_KEY_INT	1
#define LIST_KEY_GEN 2

typedef struct {
	char	key[MOTIF_ID_AND_LIST_KEY_SIZE];
} ListKey;

typedef struct _list_item{
	union {
	int val;
	ListKey key;
	};
	void *p;
	struct _list_item *next;
}list_item;

typedef struct{
	int size;
	list_item *l;
	int type;
}list;

//void 		dump_list(list *L);
int*		list_2_array(list *org);
int 		list_check (list *L);
int		list_del(list *L, void* val);
int 		list_delete(list *L, int val);
void 		list_dump(FILE *fp, list *L);
void		list_dump_short(FILE *fp, list *L, char *before, char *after);
ListKey * list_element_key (list_item *li);
void		list_element_key_get (list_item *li, ListKey *key);
void 		list_free_mem(list *L);
void 		list_free_content(list *L);
list_item* list_get(list *L, int val);
list_item* list_get_by_key(list *L, void *val);
list_item* list_get_by_indx(list *L, int indx);
list_item* list_get_next(list *L, list_item *item);
int 		list_ini(list **L, int type);
void 		list_init(list **L);
void 		list_ins(list *L, void *val, void *p);
void 		list_insert(list *L, int val, void *p);
void		list_item_ins(list *L, list_item *item);
void		list_item_rmv(list *L, list_item *item);


#endif




