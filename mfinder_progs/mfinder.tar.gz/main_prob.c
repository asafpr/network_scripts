///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// probabilistic routines - those required for the probabilistic approach
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

//retrun degree of vertex (in + out)
int
get_deg(Network *N,int vertex)
{
	int deg=0;
	int i;
	if(N->mat->type==FULL) {
		for(i=1;i<=N->vertices_num;i++) {
			deg+=MatGet(N->mat,vertex,i);
			deg+=MatGet(N->mat,i,vertex);
		}
	}else{
		//sparse - just the sum of to and from lists
		if(N->mat->spr->m[vertex].to !=NULL)
			deg+=N->mat->spr->m[vertex].to->size;
		if(N->mat->spr->m[vertex].from !=NULL)
			deg+=N->mat->spr->m[vertex].from->size;
	}
	return deg;
}

//get effective degree of node
//this is done for the prob approach
//vertex set is the current set already chosen
int
get_eff_deg(Network *N, int vertex, list*vrtx_set)
{
	int e_deg;
	list_item *l_v;
	e_deg=get_deg(N,vertex);
	for(l_v=list_get_next(vrtx_set,NULL);l_v!=NULL;l_v=list_get_next(vrtx_set,l_v)) {
		e_deg-=MatGet(N->mat,vertex,l_v->val);
		e_deg-=MatGet(N->mat,l_v->val,vertex);
	}
	return e_deg;
}

//get_p_i_
//called by get_p_i in a recursive way in order to calculate p_i
double 
get_p_i_(Network *N, list *vrtx_set, list *cur_set)
{
	list_item *l_v,*c_v;
	int v;
	double p_i_=0;
	double cur_p_=0;
	int nom,dom;

	//if no more vertices to complete vrtx_set
	if(cur_set->size==vrtx_set->size)
		return 1;

	for(l_v=list_get_next(vrtx_set,NULL);l_v!=NULL;l_v=list_get_next(vrtx_set,l_v)) {
		// if not a vertex in cur_set
		if(list_get(cur_set,l_v->val)==NULL) {
			v=l_v->val;
			
			//denominator
			//sigma e_deg for all vertices in cur_set
			dom=0;
			for(c_v=list_get_next(cur_set,NULL);c_v!=NULL;c_v=list_get_next(cur_set,c_v)) {
				dom+=get_eff_deg(N,c_v->val,cur_set);
				}
			//nominator
			//all edges from cur_set to v
			nom=0;
			for(c_v=list_get_next(cur_set,NULL);c_v!=NULL;c_v=list_get_next(cur_set,c_v)) {
				nom+=MatGet(N->mat,c_v->val,v);
				nom+=MatGet(N->mat,v,c_v->val);
			}
			if(DEBUG_LEVEL >=5)
				fprintf(arg_get_fp("log_fp"),"nom = %f,dom = %f\n",(double)nom,(double)dom);
			list_insert(cur_set,v,NULL);
			cur_p_=(double)(((double)nom/(double)dom)*get_p_i_(N,vrtx_set,cur_set));
			list_delete(cur_set,v);
			p_i_+=cur_p_;
		}
	}
	return p_i_;
}

//get pi - the probablilty to reach this vertex_set
//in the probabilistic alg
double
get_p_i(Network *N, list *vrtx_set, Network *SN)
{
	Edge e;
	list_item *l_v;
	list *cur_set;
	int i,j;
	double p_i=0;
	double cur_p=0;

	//if motif size 2 then p_i is 1/#edges
	if(vrtx_set->size==2) {
		p_i = (double)1/(double)N->edges_num;
		return p_i;
	}

	//if motif size >=3
	for(i=1;i<=vrtx_set->size;i++) {
		for(j=1;j<=vrtx_set->size;j++) {
			//if there is an edge e(i,j)
			if(MatGet(SN->mat,i,j) != 0) {
				
				l_v=list_get_by_indx(vrtx_set,i);
				if( (l_v==NULL) )
					return RC_ERR;
				else
					e.s=l_v->val;
				l_v=list_get_by_indx(vrtx_set,j);
				if( (l_v==NULL) )
					return RC_ERR;
				else
					e.t=l_v->val;

				list_init(&cur_set);
				list_insert(cur_set,e.s,NULL);
				list_insert(cur_set,e.t,NULL);
				if(DEBUG_LEVEL >=5)
					fprintf(arg_get_fp("log_fp"),"s = %d,t= %d\n",e.s,e.t);		
				cur_p=(double)((double)1/(double)N->edges_num)*get_p_i_(N,vrtx_set,cur_set);
				list_free_mem(cur_set);
				
				p_i+=cur_p;
			}
		}
	}
	return p_i;
}


/********************************************************
* function : search_subset_prob
*   Recursive function, search for subsets connected to the current vewrtex set
*   if vertex set equals motif size then end of recursion
*	results are returned in res list
* arguments:
*	N: Network to be searched
*	vrtx_set: list of vertices already participate in this search tree
*   ngbr_edges : list of neigbored edges 
*   mtf_sz: motif size
*	res : list pointer of results
*	net_type : REAL_NET - if real network
*              RAND_NET - if random network
* return values:
*	RC_OK - if not error occured
*   RC_ERR - if error occured
*********************************************************/
int
search_subset_prob(Network *N, list *vrtx_set, int mtf_sz, list *res, int net_type)
{
	int i,k,val,rc=RC_OK;
	list *ngbr_edges;
	list_item *l_node,*l_edge,*l_res_id;
	Network *SN;
	Motif *mtf;
	MotifID mtf_id;
	int *mtf_vrtx_arr;  //array that store the motif vertices
	int unique;
	Edge *edge;
	int ngbr_node;
	double p_i;
	int	pcolors = (int)pow(2,N->colors);

	//number of vertices in set is equal to motif size
	//this is the recursive base
	if (mtf_sz == vrtx_set->size) {
		//printf("found motif\n");
		network_generate_from_subset(N, &SN, vrtx_set, mtf_sz);
		//dump_network(SN);
		//calculate motif id
		network_motif_id (&mtf_id, SN, N->colors, pcolors);
		//printf("motif id %d\n", (int)mtf_id);
		//update res tbl
		//at the moment list "val" field is int means 32 bit
		//therefore limited to motif size of 5
		//this can be changed in a manner similar to that done in 'search_subset'
		if ( (l_res_id=list_get(res,(int)mtf_id)) == NULL ){
			mtf=(Motif*)mycalloc(1,sizeof(Motif));
			mtf->id = mtf_id;
			mtf->count=1;
			p_i=get_p_i(N,vrtx_set,SN);
			if(DEBUG_LEVEL >=5)
				fprintf(arg_get_fp("log_fp"),"p_i is :%f\n",p_i);
			mtf->prob_count=(double)(1/p_i);
			list_init(&mtf->members);
			if((arg_get_int("calc_unique_flag") == TRUE) && (net_type == REAL_NET) ) {
				//alloc mtf_vrtx_arr copy to it the motif vertices from vrtx_set
				mtf_vrtx_arr = (int*)mycalloc(mtf_sz,sizeof(int));
				if (DEBUG_LEVEL >=9)
					fprintf(arg_get_fp("log_fp"),"function search_subset : mtf_vrtx_arr allocated at %x\n",mtf_vrtx_arr);
				for(i=0,l_node=list_get_next(vrtx_set,NULL);l_node!=NULL;
				i++,l_node=list_get_next(vrtx_set,l_node)) {
					mtf_vrtx_arr[i]=l_node->val;
				}
				list_insert(mtf->members,1,(void*)mtf_vrtx_arr);
				if (DEBUG_LEVEL >= 1) {
					fprintf(arg_get_fp("log_fp"), "search_subset: new id added to res list %d\n", mtf_id);
					fprintf(arg_get_fp("log_fp"),"inserting motif members: ");
					for (i=0;i<mtf_sz;i++)
						fprintf(arg_get_fp("log_fp"),"%d ",mtf_vrtx_arr[i]);
					fprintf(arg_get_fp("log_fp"),"\n");
				} 
			}
			//now after mtf is fixed insert it to res list (in the p field)
			list_insert(res,(int)mtf_id,(void*)mtf);
		}else {
			mtf=((Motif*)(l_res_id->p));
			//increase count by one
			mtf->count+=1;
			p_i=get_p_i(N,vrtx_set,SN);
			if(DEBUG_LEVEL >=5)
				fprintf(arg_get_fp("log_fp"),"p_i is :%f\n",p_i);
			mtf->prob_count+=(double)(1/p_i);
			//if calc unique option is on
			//just add to motif memebers list the new motif vertices group
			if( (arg_get_int("calc_unique_flag") == TRUE) && (net_type == REAL_NET) ) {
				//alloc mtf_vrtx_arr copy to it the motif vertices from vrtx_set
				mtf_vrtx_arr = (int*)mycalloc(mtf_sz,sizeof(int));
				if (DEBUG_LEVEL >=9)
					fprintf(arg_get_fp("log_fp"),"function search_subset : mtf_vrtx_arr allocated at %x\n",mtf_vrtx_arr);
				
				for(i=0,l_node=list_get_next(vrtx_set,NULL);l_node!=NULL;
				i++,l_node=list_get_next(vrtx_set,l_node)) {
					mtf_vrtx_arr[i]=l_node->val;
				}
				mtf=(Motif*)l_res_id->p;
				
				if (DEBUG_LEVEL >= 1) {
					fprintf(arg_get_fp("log_fp"), "search_subset: existing id %d\n", mtf_id);
					fprintf(arg_get_fp("log_fp"),"new motif members are: ");
					for (i=0;i<mtf_sz;i++)
						fprintf(arg_get_fp("log_fp"),"%d ",mtf_vrtx_arr[i]);
					fprintf(arg_get_fp("log_fp"), "\nExisting members for id %d\n",mtf_id);
				}
				//pass through list , if this vertices group is unique (no common vertices with 
				//same motif id that already found) then insert to list
				unique = motif_members_intersect_array(mtf,mtf_vrtx_arr,mtf_sz);
				if(unique==TRUE) {
					if (DEBUG_LEVEL >= 1) {
						fprintf(arg_get_fp("log_fp"),"Found unique motif members, going to insert them to list\n");
					}
					list_insert(mtf->members,(int)((Motif*)(l_res_id->p))->count,(void*)mtf_vrtx_arr);
				}
			}
		}
		//free subset matrix
		network_free(SN);
		return RC_OK;
	}
	
	//find neighbors off all vertices in vrtx_set
	//insert all edges to ngbr_edges list
	//then choose randomly an edge from this list
	list_init(&ngbr_edges);
	for(l_node=list_get_next(vrtx_set,NULL);l_node!=NULL;
	l_node=list_get_next(vrtx_set,l_node)) {
		
		//if full matrix then pass through row and column
		if(N->mat->type == FULL) {
			for(i=1;i<=N->vertices_num;i++) {
				//if a neighbor of the current vertices set
				if(MatGet(N->mat,l_node->val,i)==1) {
					//and not in vrtx_set already
					if(list_get(vrtx_set,i)==NULL) {
						//insert to ngbr_edges
						edge=(Edge*)mycalloc(1,sizeof(Edge));
						edge->s=l_node->val;
						edge->t=i;
						edge->color=1;
						
						list_insert(ngbr_edges,ngbr_edges->size+1,(void*)edge);
					}
				}
			}
			//pass through column
			for(i=1;i<=N->vertices_num;i++) {
				//if a neighbor of the current vertices set
				if(MatGet(N->mat,i,l_node->val)==1) {
					//and not in vrtx_set already
					if(list_get(vrtx_set,i)==NULL) {
						//insert to ngbr_edges
						edge=(Edge*)mycalloc(1,sizeof(Edge));
						edge->s=i;
						edge->t=l_node->val;
						edge->color=1;
						
						list_insert(ngbr_edges,ngbr_edges->size+1,(void*)edge);
					}
				}
			}
		} else {
			//sparse matrix
			//pass through row
			for(l_edge=list_get_next(N->mat->spr->m[l_node->val].to,NULL);l_edge!=NULL;
			l_edge=list_get_next(N->mat->spr->m[l_node->val].to,l_edge)) {
				//if a "to" neighbor of the current vertices set
				//and not in vrtx_set already
				if(list_get(vrtx_set,l_edge->val)==NULL) {
					//insert to ngbr_edges
					edge=(Edge*)mycalloc(1,sizeof(Edge));
					edge->s=l_node->val;
					edge->t=l_edge->val;
					edge->color=1;
					
					list_insert(ngbr_edges,ngbr_edges->size+1,(void*)edge);
				}
			}
			//pass through column
			for(l_edge=list_get_next(N->mat->spr->m[l_node->val].from,NULL);l_edge!=NULL;
			l_edge=list_get_next(N->mat->spr->m[l_node->val].from,l_edge)) {
				//if a "from" neighbor of the current vertices set
				//and not in vrtx_set already
				if(list_get(vrtx_set,l_edge->val)==NULL) {
					//insert to ngbr_edges
					edge=(Edge*)mycalloc(1,sizeof(Edge));
					edge->s=l_edge->val;
					edge->t=l_node->val;
					edge->color=1;		
					list_insert(ngbr_edges,ngbr_edges->size+1,(void*)edge);
				}
			}
		} //sparse matrix
	}//for loop on vrtx_set
	if(DEBUG_LEVEL >=6) {
		fprintf(arg_get_fp("log_fp"),"ngbr_edges :\t");
		for(l_edge=list_get_next(ngbr_edges,NULL);l_edge!=NULL;
			l_edge=list_get_next(ngbr_edges,l_edge)) {
			edge=(Edge*)l_edge->p;
			fprintf(arg_get_fp("log_fp"),"(%d,%d) ",edge->s,edge->t);
		}
		fprintf(arg_get_fp("log_fp"),"\n");
	}

	//if no neigbours then we didnt find motif - return
	//without updating any motif counter
	if(ngbr_edges->size == 0) {
		//printf("didnt reach a motif\t");
		return RC_ERR;
	}

	//remove from ngbr_edges all edges that now have both source and target in vrtx_set
	for(l_edge=list_get_next(ngbr_edges,NULL);l_edge!=NULL;) {
		edge=(Edge*)l_edge->p;
		if( (list_get(vrtx_set,edge->s)!=NULL) && (list_get(vrtx_set,edge->t)!=NULL) ) {
			val=l_edge->val;
			l_edge=l_edge->next;
			list_delete(ngbr_edges,val);
		} else {
			l_edge=l_edge->next;
		}
	}

	//get a random edge from ngbr_edges and recursively call search_subset_prob
	k=get_rand(ngbr_edges->size);
	//check who is the new neighbor and add it to vrtx_set
	l_edge=list_get_by_indx(ngbr_edges,k);
	edge=(Edge*)l_edge->p;
	if(DEBUG_LEVEL >=6)
				fprintf(arg_get_fp("log_fp"),"edge #:(%d,%d)\n",edge->s,edge->t);
	if( (list_get(vrtx_set,edge->s)==NULL) && (list_get(vrtx_set,edge->t)!=NULL))
		ngbr_node=edge->s;
	else if ( (list_get(vrtx_set,edge->t)==NULL) && (list_get(vrtx_set,edge->s)!=NULL))
		ngbr_node=edge->t;
	else
		printf ("Error: no leg in leg of this edge\n");
	list_free_mem(ngbr_edges);
	list_insert(vrtx_set,ngbr_node,NULL);
	
	rc = search_subset_prob(N, vrtx_set, mtf_sz, res, net_type);
	
	list_delete(vrtx_set,ngbr_node);

	return rc;
}

/********************************************************
* function : search motifs probabilistic approach
*	results are returned in res list
* arguments:
*	N: Network to be searched
*	mtf_sz: motif size
*	res : list pointer of results
*	net_type : REAL_NET - if real network
*              RAND_NET - if random network
* return values:
*	RC_OK - if not error occured
*   RC_ERR - if error occured
*********************************************************/
int
search_motifs_prob(Network *N, int mtf_sz, list *res, int net_type)
{
	int rc=RC_OK;
	int s,t,i,k;
	list *vrtx_set;

	list_init(&vrtx_set);
	
	
	//find random connected subgraph of size mtf_sz
	//do it num of prob_total_ops
	for(i=1;i<=arg_get_int("prob_app_samples_num");i++) {
		//get a random edge to start
			if(DEBUG_LEVEL >=5)
				fprintf(arg_get_fp("log_fp"),"sample #%d:\n",i);
			k=get_rand(N->edges_num);
			s=N->e_arr[k].s;
			t=N->e_arr[k].t;
			if(DEBUG_LEVEL >=6)
				fprintf(arg_get_fp("log_fp"),"edge #1: (%d,%d)\n",s,t);
			//list_init(&ngbr_edges);
			//insert the two vertices of the edge to vertices set and call search subset
			list_insert(vrtx_set, s, NULL);
			list_insert(vrtx_set, t, NULL);
			rc = search_subset_prob(N, vrtx_set, mtf_sz, res, net_type);
			//free hash history table
			//now remove these vertices from vertices set
			list_delete(vrtx_set, s);
			list_delete(vrtx_set, t);
			//list_free_mem(ngbr_edges);
			//if no big enough subset found then try again
			if (rc==RC_ERR)
				i--;
		}
	list_free_mem(vrtx_set);

	return RC_OK;
}
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// end of probabilistic routines
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////



